<html>
	<head>
		<title> FMDD </title>
		<style type="text/css">
			table{border-collapse:collapse; border: 1px solid #03476F;
	  			  font:normal 12px verdana, arial, helvetica, sans-serif;
				  color: #363636; 
				 }
			td{
				border: 1px solid #03476f;
				padding: .4em;
				color: #363636;
				text-align:center;
				vertical-align:top;
			   }
		</style>
	</head>
	<body>
	<table>
	<tr>
		<td>
<?php
	require('dbConnect.php');
	require('alleleVar.php');
	
	$query = "select * from profile where DNA_no='$DNA_no'";
	$result = mysql_query($query);
	$numRow=mysql_num_rows($result);
	for ($i=0; $i<$numRow; $i++){
		$row=mysql_fetch_array($result);
	
	echo '<table width="300">';
	echo '	<tr><td colspan=2> mixture </td></tr>';
	echo '	<tr><td> Amel </td><td>'.$row[amel].'</td></tr>';
	echo '	<tr><td> TH01 </td><td>'.$row[th01].'</td></tr>';
	echo '	<tr><td> TPOX </td><td>'.$row[tpox].'</td></tr>';
	echo '	<tr><td> CSF1PO </td><td>'.$row[csf1po].'</td></tr>';
	echo '	<tr><td> D3S1358 </td><td>'.$row[d3].'</td></tr>';
	echo '	<tr><td> vWA </td><td>'.$row[vwa].'</td></tr>';
	echo '	<tr><td> FGA </td><td>'.$row[fga].'</td></tr>';
	echo '	<tr><td> D5S818 </td><td>'.$row[d5].'</td></tr>';
	echo '	<tr><td> D13S317 </td><td>'.$row[d13].'</td></tr>';
	echo '	<tr><td> D7S820 </td><td>'.$row[d7].'</td></tr>';
	echo '	<tr><td> D16S539 </td><td>'.$row[d16].'</td></tr>';
	echo '	<tr><td> D8S1179 </td><td>'.$row[d8].'</td></tr>';
	echo '	<tr><td> D21S11 </td><td>'.$row[d21].'</td></tr>';
	echo '	<tr><td> D18S51 </td><td>'.$row[d18].'</td></tr>';
	echo '	<tr><td> D2S1338 </td><td>'.$row[d2].'</td></tr>';
	echo '	<tr><td> D19S433 </td><td>'.$row[d19].'</td></tr>';
	echo '	<tr><td> Penta E </td><td>'.$row[pentae].'</td></tr>';
	echo '	<tr><td> Penta D </td><td>'.$row[pentad].'</td></tr>';
	echo '</table>';
	}
?>
		</td>
		<td>
<?php
	if ($Yquery = "select * from ystr where DNA='$DNA_no' and kit='Y-Filer'"){
		$Yresult = mysql_query($Yquery);
		$YnumRow = mysql_num_rows($Yresult);
		for($j=0; $j<$YnumRow; $j++){
			$Yrow=mysql_fetch_array($Yresult);
			echo '<table width="300">';
			echo '	<tr><td colspan=2> Y-STR </td></tr>';
			echo '	<td> DYS456 </td><td>'.$Yrow[DYS456].'</td></tr>';
			echo '	<td> DYS389I </td><td>'.$Yrow[DYS389I].'</td></tr>';
			echo '	<td> DYS390 </td><td>'.$Yrow[DYS390].'</td></tr>';
			echo '	<td> DYS389II </td><td>'.$Yrow[DYS389II].'</td></tr>';
			echo '	<td> DYS458 </td><td>'.$Yrow[DYS458].'</td></tr>';
			echo '	<td> DYS19 </td><td>'.$Yrow[DYS19].'</td></tr>';
			echo '	<td> DYS385 </td><td>'.$Yrow[DYS385].'</td></tr>';
			echo '	<td> DYS393 </td><td>'.$Yrow[DYS393].'</td></tr>';
			echo '	<td> DYS391 </td><td>'.$Yrow[DYS391].'</td></tr>';
			echo '	<td> DYS439 </td><td>'.$Yrow[DYS439].'</td></tr>';
			echo '	<td> DYS635 </td><td>'.$Yrow[DYS635].'</td></tr>';
			echo '	<td> DYS392 </td><td>'.$Yrow[DYS392].'</td></tr>';
			echo '	<td> Y GATA H4 </td><td>'.$Yrow[YGATAH4].'</td></tr>';
			echo '	<td> DYS437 </td><td>'.$Yrow[DYS437].'</td></tr>';
			echo '	<td> DYS438 </td><td>'.$Yrow[DYS438].'</td></tr>';
			echo '	<td> DYS448 </td><td>'.$Yrow[DYS448].'</td></tr>';
			echo '	<td> Kit </td><td>'.$Yrow[kit].'</td></tr>';
			echo '</table>';
		}
	}if ($Yquery = "select * from ystr where DNA='$DNA_no' and kit='Powerplex Y23'"){
		$Yresult = mysql_query($Yquery);
		$YnumRow = mysql_num_rows($Yresult);
		for($j=0; $j<$YnumRow; $j++){
			$Yrow=mysql_fetch_array($Yresult);
			echo '<table width="300">';
			echo '	<tr><td colspan=2> Y-STR </td></tr>';
			echo '	<td> DYS576 </td><td>'.$Yrow[DYS576].'</td></tr>';
			echo '	<td> DYS389I </td><td>'.$Yrow[DYS389I].'</td></tr>';
			echo '	<td> DYS448 </td><td>'.$Yrow[DYS448].'</td></tr>';
			echo '	<td> DYS389II </td><td>'.$Yrow[DYS389II].'</td></tr>';
			echo '	<td> DYS19 </td><td>'.$Yrow[DYS19].'</td></tr>';
			echo '	<td> DYS391 </td><td>'.$Yrow[DYS391].'</td></tr>';
			echo '	<td> DYS481 </td><td>'.$Yrow[DYS481].'</td></tr>';
			echo '	<td> DYS549 </td><td>'.$Yrow[DYS549].'</td></tr>';
			echo '	<td> DYS533 </td><td>'.$Yrow[DYS533].'</td></tr>';
			echo '	<td> DYS438 </td><td>'.$Yrow[DYS438].'</td></tr>';
			echo '	<td> DYS437 </td><td>'.$Yrow[DYS437].'</td></tr>';
			echo '	<td> DYS570 </td><td>'.$Yrow[DYS570].'</td></tr>';
			echo '	<td> DYS635 </td><td>'.$Yrow[DYS635].'</td></tr>';
			echo '	<td> DYS390 </td><td>'.$Yrow[DYS390].'</td></tr>';
			echo '	<td> DYS439 </td><td>'.$Yrow[DYS439].'</td></tr>';
			echo '	<td> DYS392 </td><td>'.$Yrow[DYS392].'</td></tr>';
			echo '	<td> DYS643 </td><td>'.$Yrow[DYS643].'</td></tr>';
			echo '	<td> DYS393 </td><td>'.$Yrow[DYS393].'</td></tr>';
			echo '	<td> DYS458 </td><td>'.$Yrow[DYS458].'</td></tr>';
			echo '	<td> DYS385 </td><td>'.$Yrow[DYS385].'</td></tr>';
			echo '	<td> DYS456 </td><td>'.$Yrow[DYS456].'</td></tr>';			
			echo '	<td> Y GATA H4 </td><td>'.$Yrow[YGATAH4].'</td></tr>';
			echo '	<td> Kit </td><td>'.$Yrow[kit].'</td></tr>';
			echo '</table>';
		}
	}

?>
		</td>
	</tr>
	</table>
	
	</body>
</html>

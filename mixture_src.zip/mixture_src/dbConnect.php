<?php
	$conn=mysql_connect('localhost','root','apmsetup') || die ("db���� �ȵ�");
	
	mysql_select_db('mixture') or die ("fail to connect the mixture database");

?>
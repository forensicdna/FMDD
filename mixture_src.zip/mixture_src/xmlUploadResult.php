<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=EUC-KR"/>
		<title> FMDD </title>
		<style type="text/css">
		body {
			font-family : sans-serif;
		/*	font-size : 10 px; */
		}
		table {
			border : thin solid black;
			border-collapse : collapse; 
			font-family : sans-serif;
			font-size : 11 px;
			border-spacing: 0px;
			table-layout: fixed; 
		}
		th {
			border: 1px solid gray;
			text-align: center;
			vertical-align: center;
			padding-right: 1px;
			height: auto;
			background-color: #fcba7a;
		}
		td {
			border: 1px solid gray;
			text-align: center;
			vertical-align: center;
			padding-bottom: 15px;
			word-break: break-all;
			height: auto;
		}
		</style>
	</head>
<body>
<?php 
	include "dbConnect.php";
	include "XMLparse.php";
	require ('head.php');
?>

<div id="pagecell1"> 
  <!--pagecell1--> 
	  <img alt="" src="tl_curve_white.gif" height="6" width="6" id="tl" /> 
	  <img alt="" src="tr_curve_white.gif" height="6" width="6" id="tr" /> 
	  <div> 
		&nbsp;
	  </div> 
	  <div id="pageName"> 
		<h2>File Upload Results </h2> 
	  </div> 
	  <input type="button" value="Go Submit" title="Go back to Submit Page" onclick="window.location='refSubmit.php'">
	  <div class="story">

 
 <?
// Submit�� ���� ���� �˻�
		if ($_FILES['xmlSubmitFile']['error'] > 0){
			echo 'Problem: ';
			switch ($_FILES['xmlSubmitFile']['error']){
				case 1: echo 'File exceeded upload_max_filesize'; break;
				case 2: echo 'File exceeded max_file_size'; break;
				case 3: echo 'File only partially upload'; break;
				case 4: echo 'No File upload'; break;
			}
			exit;
		}
// Submit�� ���� upload������ �Űܼ� ���� �۾� ����
	$file ='./xmlUpload/'.$_FILES['xmlSubmitFile']['name'];

	if (is_uploaded_file($_FILES['xmlSubmitFile']['tmp_name'])){
		if (!move_uploaded_file($_FILES['xmlSubmitFile']['tmp_name'],$file)){
			echo 'Problem: Could not move file to destination directory';
			exit;
		}
	}

	if (!$file) {
		echo '<p><strong> No file. Please try again.</strong></p>';
	} elseif ($file) {
	$dom = new DOMDocument;
	$dom -> load($file);
	$specimens = $dom->getElementsByTagName('SPECIMEN');
	$count = $specimens->length;

	$xml= file_get_contents($file);
	$parser = new XMLParser($xml);
	$parser -> Parse();
	$test = $parser->document;
	
	
	// locus ���� �˻�
	for ($a=0; $a<$count ; $a++){
		for($b=0;$b<16;$b++){
			if($test->specimen[$a]->locus[$b]->locusname[0]->tagData){
				$cnt = $b;
			}
		}if ($cnt<15){ 
			echo $test->specimen[$a]->specimenid[0]->tagData." does not contain 15 locus","<br>";
			echo "Please check your xml file","<br>";
		}
	}



	for ($i=0; $i<$count ; $i++){
		// D8�� ó��
		if ($test->specimen[$i]->locus[0]->locusname[0]->tagData == 'D8S1179' and
			$test->specimen[$i]->locus[1]->locusname[0]->tagData == 'D21S11' and
			$test->specimen[$i]->locus[2]->locusname[0]->tagData == 'D7S820' and
			$test->specimen[$i]->locus[3]->locusname[0]->tagData == 'CSF1PO' and
			$test->specimen[$i]->locus[4]->locusname[0]->tagData == 'D3S1358' and
			$test->specimen[$i]->locus[5]->locusname[0]->tagData == 'TH01' and
			$test->specimen[$i]->locus[6]->locusname[0]->tagData == 'D13S317' and
			$test->specimen[$i]->locus[7]->locusname[0]->tagData == 'D16S539' and
			$test->specimen[$i]->locus[8]->locusname[0]->tagData == 'D2S1338' and
			$test->specimen[$i]->locus[9]->locusname[0]->tagData == 'D19S433' and
			$test->specimen[$i]->locus[10]->locusname[0]->tagData == 'vWA' and
			$test->specimen[$i]->locus[11]->locusname[0]->tagData == 'TPOX' and
			$test->specimen[$i]->locus[12]->locusname[0]->tagData == 'D18S51' and
			$test->specimen[$i]->locus[13]->locusname[0]->tagData == 'AMEL' and
			$test->specimen[$i]->locus[14]->locusname[0]->tagData == 'D5S818' and
			$test->specimen[$i]->locus[15]->locusname[0]->tagData == 'FGA')
			{
				
						$sql = "insert into reference (dna, D8S1179_1,D8S1179_2,
														    D21S11_1,D21S11_2,
															D7S820_1,D7S820_2,
															CSF1PO_1,CSF1PO_2,
															D3S1358_1,D3S1358_2,
															TH01_1,TH01_2,
															D13S317_1,D13S317_2,
															D16S539_1,D16S539_2,
															D2S1338_1,D2S1338_2,
															D19S433_1,D19S433_2,
															VWA_1,VWA_2,
															TPOX_1,TPOX_2,
															D18S51_1,D18S51_2,
															AMEL_1,AMEL_2,
															D5S818_1,D5S818_2,
															FGA_1,FGA_2,
															sDate
															) values ('"
							      .$test->specimen[$i]->specimenid[0]->tagData."'";
								  for($j=0;$j<16;$j++){
									 $sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
									 if(!$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData){
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
										}else{
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData."'"; 
										}
								  }
					    $sql.=",'".date("Y-m-d")."');";
					$result = mysql_query($sql);
					
			}
			
			//D21�� ó��
			elseif ($test->specimen[$i]->locus[0]->locusname[0]->tagData == 'D21S11' and
			$test->specimen[$i]->locus[1]->locusname[0]->tagData == 'D7S820' and
			$test->specimen[$i]->locus[2]->locusname[0]->tagData == 'CSF1PO' and
			$test->specimen[$i]->locus[3]->locusname[0]->tagData == 'D3S1358' and
			$test->specimen[$i]->locus[4]->locusname[0]->tagData == 'TH01' and
			$test->specimen[$i]->locus[5]->locusname[0]->tagData == 'D13S317' and
			$test->specimen[$i]->locus[6]->locusname[0]->tagData == 'D16S539' and
			$test->specimen[$i]->locus[7]->locusname[0]->tagData == 'D2S1338' and
			$test->specimen[$i]->locus[8]->locusname[0]->tagData == 'D19S433' and
			$test->specimen[$i]->locus[9]->locusname[0]->tagData == 'vWA' and
			$test->specimen[$i]->locus[10]->locusname[0]->tagData == 'TPOX' and
			$test->specimen[$i]->locus[11]->locusname[0]->tagData == 'D18S51' and
			$test->specimen[$i]->locus[12]->locusname[0]->tagData == 'AMEL' and
			$test->specimen[$i]->locus[13]->locusname[0]->tagData == 'D5S818' and
			$test->specimen[$i]->locus[14]->locusname[0]->tagData == 'FGA' and
			$test->specimen[$i]->locus[15]->locusname[0]->tagData == 'D8S1179')
			{
				
						$sql = "insert into reference (dna, D21S11_1,D21S11_2,
															D7S820_1,D7S820_2,
															CSF1PO_1,CSF1PO_2,
															D3S1358_1,D3S1358_2,
															TH01_1,TH01_2,
															D13S317_1,D13S317_2,
															D16S539_1,D16S539_2,
															D2S1338_1,D2S1338_2,
															D19S433_1,D19S433_2,
															VWA_1,VWA_2,
															TPOX_1,TPOX_2,
															D18S51_1,D18S51_2,
															AMEL_1,AMEL_2,
															D5S818_1,D5S818_2,
															FGA_1,FGA_2,
															D8S1179_1,D8S1179_2,
															sDate
															) values ('"
							      .$test->specimen[$i]->specimenid[0]->tagData."'";
								  for($j=0;$j<16;$j++){
									 $sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
									 if(!$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData){
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
										}else{
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData."'"; 
										}
								  }
					    $sql.=",'".date("Y-m-d")."');";
					$result = mysql_query($sql);
					
			}//D21 ��
			//D7 ó��
			elseif ($test->specimen[$i]->locus[0]->locusname[0]->tagData == 'D7S820' and
			$test->specimen[$i]->locus[1]->locusname[0]->tagData == 'CSF1PO' and
			$test->specimen[$i]->locus[2]->locusname[0]->tagData == 'D3S1358' and
			$test->specimen[$i]->locus[3]->locusname[0]->tagData == 'TH01' and
			$test->specimen[$i]->locus[4]->locusname[0]->tagData == 'D13S317' and
			$test->specimen[$i]->locus[5]->locusname[0]->tagData == 'D16S539' and
			$test->specimen[$i]->locus[6]->locusname[0]->tagData == 'D2S1338' and
			$test->specimen[$i]->locus[7]->locusname[0]->tagData == 'D19S433' and
			$test->specimen[$i]->locus[8]->locusname[0]->tagData == 'vWA' and
			$test->specimen[$i]->locus[9]->locusname[0]->tagData == 'TPOX' and
			$test->specimen[$i]->locus[10]->locusname[0]->tagData == 'D18S51' and
			$test->specimen[$i]->locus[11]->locusname[0]->tagData == 'AMEL' and
			$test->specimen[$i]->locus[12]->locusname[0]->tagData == 'D5S818' and
			$test->specimen[$i]->locus[13]->locusname[0]->tagData == 'FGA' and
			$test->specimen[$i]->locus[14]->locusname[0]->tagData == 'D8S1179' and
			$test->specimen[$i]->locus[15]->locusname[0]->tagData == 'D21S11')
			{
				
						$sql = "insert into reference (dna, D7S820_1,D7S820_2,
															CSF1PO_1,CSF1PO_2,
															D3S1358_1,D3S1358_2,
															TH01_1,TH01_2,
															D13S317_1,D13S317_2,
															D16S539_1,D16S539_2,
															D2S1338_1,D2S1338_2,
															D19S433_1,D19S433_2,
															VWA_1,VWA_2,
															TPOX_1,TPOX_2,
															D18S51_1,D18S51_2,
															AMEL_1,AMEL_2,
															D5S818_1,D5S818_2,
															FGA_1,FGA_2,
															D8S1179_1,D8S1179_2,
															D21S11_1,D21S11_2,
															sDate) values ('"
							      .$test->specimen[$i]->specimenid[0]->tagData."'";
								  for($j=0;$j<16;$j++){
									 $sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
									 if(!$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData){
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
										}else{
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData."'"; 
										}
								  }
					    $sql.=",'".date("Y-m-d")."');";
					$result = mysql_query($sql);
					
			}//D7 ��
			//CSF1PO ó��
			elseif ($test->specimen[$i]->locus[0]->locusname[0]->tagData == 'CSF1PO' and
			$test->specimen[$i]->locus[1]->locusname[0]->tagData == 'D3S1358' and
			$test->specimen[$i]->locus[2]->locusname[0]->tagData == 'TH01' and
			$test->specimen[$i]->locus[3]->locusname[0]->tagData == 'D13S317' and
			$test->specimen[$i]->locus[4]->locusname[0]->tagData == 'D16S539' and
			$test->specimen[$i]->locus[5]->locusname[0]->tagData == 'D2S1338' and
			$test->specimen[$i]->locus[6]->locusname[0]->tagData == 'D19S433' and
			$test->specimen[$i]->locus[7]->locusname[0]->tagData == 'vWA' and
			$test->specimen[$i]->locus[8]->locusname[0]->tagData == 'TPOX' and
			$test->specimen[$i]->locus[9]->locusname[0]->tagData == 'D18S51' and
			$test->specimen[$i]->locus[10]->locusname[0]->tagData == 'AMEL' and
			$test->specimen[$i]->locus[11]->locusname[0]->tagData == 'D5S818' and
			$test->specimen[$i]->locus[12]->locusname[0]->tagData == 'FGA' and
			$test->specimen[$i]->locus[13]->locusname[0]->tagData == 'D8S1179' and
			$test->specimen[$i]->locus[14]->locusname[0]->tagData == 'D21S11' and
			$test->specimen[$i]->locus[15]->locusname[0]->tagData == 'D7S820')
			{
				
						$sql = "insert into reference (dna, CSF1PO_1,CSF1PO_2,
															D3S1358_1,D3S1358_2,
															TH01_1,TH01_2,
															D13S317_1,D13S317_2,
															D16S539_1,D16S539_2,
															D2S1338_1,D2S1338_2,
															D19S433_1,D19S433_2,
															VWA_1,VWA_2,
															TPOX_1,TPOX_2,
															D18S51_1,D18S51_2,
															AMEL_1,AMEL_2,
															D5S818_1,D5S818_2,
															FGA_1,FGA_2,
															D8S1179_1,D8S1179_2,
															D21S11_1,D21S11_2,
															D7S820_1,D7S820_2,
															sDate) values ('"
							      .$test->specimen[$i]->specimenid[0]->tagData."'";
								  for($j=0;$j<16;$j++){
									 $sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
									 if(!$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData){
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
										}else{
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData."'"; 
										}
								  }
					   $sql.=",'".date("Y-m-d")."');";
					$result = mysql_query($sql);
					
			} //CSF1PO ��
			//D3 ó��
			elseif ($test->specimen[$i]->locus[0]->locusname[0]->tagData == 'D3S1358' and
			$test->specimen[$i]->locus[1]->locusname[0]->tagData == 'TH01' and
			$test->specimen[$i]->locus[2]->locusname[0]->tagData == 'D13S317' and
			$test->specimen[$i]->locus[3]->locusname[0]->tagData == 'D16S539' and
			$test->specimen[$i]->locus[4]->locusname[0]->tagData == 'D2S1338' and
			$test->specimen[$i]->locus[5]->locusname[0]->tagData == 'D19S433' and
			$test->specimen[$i]->locus[6]->locusname[0]->tagData == 'vWA' and
			$test->specimen[$i]->locus[7]->locusname[0]->tagData == 'TPOX' and
			$test->specimen[$i]->locus[8]->locusname[0]->tagData == 'D18S51' and
			$test->specimen[$i]->locus[9]->locusname[0]->tagData == 'AMEL' and
			$test->specimen[$i]->locus[10]->locusname[0]->tagData == 'D5S818' and
			$test->specimen[$i]->locus[11]->locusname[0]->tagData == 'FGA' and
			$test->specimen[$i]->locus[12]->locusname[0]->tagData == 'D8S1179' and
			$test->specimen[$i]->locus[13]->locusname[0]->tagData == 'D21S11' and
			$test->specimen[$i]->locus[14]->locusname[0]->tagData == 'D7S820' and
			$test->specimen[$i]->locus[15]->locusname[0]->tagData == 'CSF1PO')
			{
				
						$sql = "insert into reference (dna, D3S1358_1,D3S1358_2,
															TH01_1,TH01_2,
															D13S317_1,D13S317_2,
															D16S539_1,D16S539_2,
															D2S1338_1,D2S1338_2,
															D19S433_1,D19S433_2,
															VWA_1,VWA_2,
															TPOX_1,TPOX_2,
															D18S51_1,D18S51_2,
															AMEL_1,AMEL_2,
															D5S818_1,D5S818_2,
															FGA_1,FGA_2,
															D8S1179_1,D8S1179_2,
															D21S11_1,D21S11_2,
															D7S820_1,D7S820_2,
															CSF1PO_1,CSF1PO_2,
															sDate) values ('"
							      .$test->specimen[$i]->specimenid[0]->tagData."'";
								  for($j=0;$j<16;$j++){
									 $sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
									 if(!$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData){
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
										}else{
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData."'"; 
										}
								  }
					    $sql.=",'".date("Y-m-d")."');";
					$result = mysql_query($sql);
					
			} //D3 ��
			//TH01
			if ($test->specimen[$i]->locus[0]->locusname[0]->tagData == 'TH01' and
			$test->specimen[$i]->locus[1]->locusname[0]->tagData == 'D13S317' and
			$test->specimen[$i]->locus[2]->locusname[0]->tagData == 'D16S539' and
			$test->specimen[$i]->locus[3]->locusname[0]->tagData == 'D2S1338' and
			$test->specimen[$i]->locus[4]->locusname[0]->tagData == 'D19S433' and
			$test->specimen[$i]->locus[5]->locusname[0]->tagData == 'vWA' and
			$test->specimen[$i]->locus[6]->locusname[0]->tagData == 'TPOX' and
			$test->specimen[$i]->locus[7]->locusname[0]->tagData == 'D18S51' and
			$test->specimen[$i]->locus[8]->locusname[0]->tagData == 'AMEL' and
			$test->specimen[$i]->locus[9]->locusname[0]->tagData == 'D5S818' and
			$test->specimen[$i]->locus[10]->locusname[0]->tagData == 'FGA' and
			$test->specimen[$i]->locus[11]->locusname[0]->tagData == 'D8S1179' and
			$test->specimen[$i]->locus[12]->locusname[0]->tagData == 'D21S11' and
			$test->specimen[$i]->locus[13]->locusname[0]->tagData == 'D7S820' and
			$test->specimen[$i]->locus[14]->locusname[0]->tagData == 'CSF1PO' and
			$test->specimen[$i]->locus[15]->locusname[0]->tagData == 'D3S1358')
			{
				
						$sql = "insert into reference (dna, TH01_1,TH01_2,
															D13S317_1,D13S317_2,
															D16S539_1,D16S539_2,
															D2S1338_1,D2S1338_2,
															D19S433_1,D19S433_2,
															VWA_1,VWA_2,
															TPOX_1,TPOX_2,
															D18S51_1,D18S51_2,
															AMEL_1,AMEL_2,
															D5S818_1,D5S818_2,
															FGA_1,FGA_2,
															D8S1179_1,D8S1179_2,
															D21S11_1,D21S11_2,
															D7S820_1,D7S820_2,
															CSF1PO_1,CSF1PO_2,
															D3S1358_1,D3S1358_2,
															sDate) values ('"
							      .$test->specimen[$i]->specimenid[0]->tagData."'";
								  for($j=0;$j<16;$j++){
									 $sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
									 if(!$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData){
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
										}else{
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData."'"; 
										}
								  }
					   $sql.=",'".date("Y-m-d")."');";
					  $result = mysql_query($sql);
					
			} //TH01 ��
			//D13 ����
			elseif ($test->specimen[$i]->locus[0]->locusname[0]->tagData == 'D13S317' and
			$test->specimen[$i]->locus[1]->locusname[0]->tagData == 'D16S539' and
			$test->specimen[$i]->locus[2]->locusname[0]->tagData == 'D2S1338' and
			$test->specimen[$i]->locus[3]->locusname[0]->tagData == 'D19S433' and
			$test->specimen[$i]->locus[4]->locusname[0]->tagData == 'vWA' and
			$test->specimen[$i]->locus[5]->locusname[0]->tagData == 'TPOX' and
			$test->specimen[$i]->locus[6]->locusname[0]->tagData == 'D18S51' and
			$test->specimen[$i]->locus[7]->locusname[0]->tagData == 'AMEL' and
			$test->specimen[$i]->locus[8]->locusname[0]->tagData == 'D5S818' and
			$test->specimen[$i]->locus[9]->locusname[0]->tagData == 'FGA' and
			$test->specimen[$i]->locus[10]->locusname[0]->tagData == 'D8S1179' and
			$test->specimen[$i]->locus[11]->locusname[0]->tagData == 'D21S11' and
			$test->specimen[$i]->locus[12]->locusname[0]->tagData == 'D7S820' and
			$test->specimen[$i]->locus[13]->locusname[0]->tagData == 'CSF1PO' and
			$test->specimen[$i]->locus[14]->locusname[0]->tagData == 'D3S1358' and
			$test->specimen[$i]->locus[15]->locusname[0]->tagData == 'TH01')
			{
				
						$sql = "insert into reference (dna, D13S317_1,D13S317_2,
															D16S539_1,D16S539_2,
															D2S1338_1,D2S1338_2,
															D19S433_1,D19S433_2,
															VWA_1,VWA_2,
															TPOX_1,TPOX_2,
															D18S51_1,D18S51_2,
															AMEL_1,AMEL_2,
															D5S818_1,D5S818_2,
															FGA_1,FGA_2,
															D8S1179_1,D8S1179_2,
															D21S11_1,D21S11_2,
															D7S820_1,D7S820_2,
															CSF1PO_1,CSF1PO_2,
															D3S1358_1,D3S1358_2,
															TH01_1,TH01_2,
															sDate) values ('"
							      .$test->specimen[$i]->specimenid[0]->tagData."'";
								  for($j=0;$j<16;$j++){
									 $sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
									 if(!$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData){
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
										}else{
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData."'"; 
										}
								  }
					   $sql.=",'".date("Y-m-d")."');";
					$result = mysql_query($sql);
					
			} //D13 ��
			//D16 ����
			elseif ($test->specimen[$i]->locus[0]->locusname[0]->tagData == 'D16S539' and
			$test->specimen[$i]->locus[1]->locusname[0]->tagData == 'D2S1338' and
			$test->specimen[$i]->locus[2]->locusname[0]->tagData == 'D19S433' and
			$test->specimen[$i]->locus[3]->locusname[0]->tagData == 'vWA' and
			$test->specimen[$i]->locus[4]->locusname[0]->tagData == 'TPOX' and
			$test->specimen[$i]->locus[5]->locusname[0]->tagData == 'D18S51' and
			$test->specimen[$i]->locus[6]->locusname[0]->tagData == 'AMEL' and
			$test->specimen[$i]->locus[7]->locusname[0]->tagData == 'D5S818' and
			$test->specimen[$i]->locus[8]->locusname[0]->tagData == 'FGA' and
			$test->specimen[$i]->locus[9]->locusname[0]->tagData == 'D8S1179' and
			$test->specimen[$i]->locus[10]->locusname[0]->tagData == 'D21S11' and
			$test->specimen[$i]->locus[11]->locusname[0]->tagData == 'D7S820' and
			$test->specimen[$i]->locus[12]->locusname[0]->tagData == 'CSF1PO' and
			$test->specimen[$i]->locus[13]->locusname[0]->tagData == 'D3S1358' and
			$test->specimen[$i]->locus[14]->locusname[0]->tagData == 'TH01' and
			$test->specimen[$i]->locus[15]->locusname[0]->tagData == 'D13S317')
			{
				
						$sql = "insert into reference (dna, D16S539_1,D16S539_2,
															D2S1338_1,D2S1338_2,
															D19S433_1,D19S433_2,
															VWA_1,VWA_2,
															TPOX_1,TPOX_2,
															D18S51_1,D18S51_2,
															AMEL_1,AMEL_2,
															D5S818_1,D5S818_2,
															FGA_1,FGA_2,
															D8S1179_1,D8S1179_2,
															D21S11_1,D21S11_2,
															D7S820_1,D7S820_2,
															CSF1PO_1,CSF1PO_2,
															D3S1358_1,D3S1358_2,
															TH01_1,TH01_2,
															D13S317_1,D13S317_2,
															sDate) values ('"
							      .$test->specimen[$i]->specimenid[0]->tagData."'";
								  for($j=0;$j<16;$j++){
									 $sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
									 if(!$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData){
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
										}else{
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData."'"; 
										}
								  }
					   $sql.=",'".date("Y-m-d")."');";
					$result = mysql_query($sql);
					
			} //D16 ��
			//D2 ����
			elseif ($test->specimen[$i]->locus[0]->locusname[0]->tagData == 'D2S1338' and
			$test->specimen[$i]->locus[1]->locusname[0]->tagData == 'D19S433' and
			$test->specimen[$i]->locus[2]->locusname[0]->tagData == 'vWA' and
			$test->specimen[$i]->locus[3]->locusname[0]->tagData == 'TPOX' and
			$test->specimen[$i]->locus[4]->locusname[0]->tagData == 'D18S51' and
			$test->specimen[$i]->locus[5]->locusname[0]->tagData == 'AMEL' and
			$test->specimen[$i]->locus[6]->locusname[0]->tagData == 'D5S818' and
			$test->specimen[$i]->locus[7]->locusname[0]->tagData == 'FGA' and
			$test->specimen[$i]->locus[8]->locusname[0]->tagData == 'D8S1179' and
			$test->specimen[$i]->locus[9]->locusname[0]->tagData == 'D21S11' and
			$test->specimen[$i]->locus[10]->locusname[0]->tagData == 'D7S820' and
			$test->specimen[$i]->locus[11]->locusname[0]->tagData == 'CSF1PO' and
			$test->specimen[$i]->locus[12]->locusname[0]->tagData == 'D3S1358' and
			$test->specimen[$i]->locus[13]->locusname[0]->tagData == 'TH01' and
			$test->specimen[$i]->locus[14]->locusname[0]->tagData == 'D13S317' and
			$test->specimen[$i]->locus[15]->locusname[0]->tagData == 'D16S539')
			{
				
						$sql = "insert into reference (dna, D2S1338_1,D2S1338_2,
															D19S433_1,D19S433_2,
															VWA_1,VWA_2,
															TPOX_1,TPOX_2,
															D18S51_1,D18S51_2,
															AMEL_1,AMEL_2,
															D5S818_1,D5S818_2,
															FGA_1,FGA_2,
															D8S1179_1,D8S1179_2,
															D21S11_1,D21S11_2,
															D7S820_1,D7S820_2,
															CSF1PO_1,CSF1PO_2,
															D3S1358_1,D3S1358_2,
															TH01_1,TH01_2,
															D13S317_1,D13S317_2,
															D16S539_1,D16S539_2,
															sDate) values ('"
							      .$test->specimen[$i]->specimenid[0]->tagData."'";
								  for($j=0;$j<16;$j++){
									 $sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
									 if(!$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData){
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
										}else{
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData."'"; 
										}
								  }
					   $sql.=",'".date("Y-m-d")."');";
					$result = mysql_query($sql);
					
			} //D2 ��
			//D19 ����
			elseif ($test->specimen[$i]->locus[0]->locusname[0]->tagData == 'D19S433' and
			$test->specimen[$i]->locus[1]->locusname[0]->tagData == 'vWA' and
			$test->specimen[$i]->locus[2]->locusname[0]->tagData == 'TPOX' and
			$test->specimen[$i]->locus[3]->locusname[0]->tagData == 'D18S51' and
			$test->specimen[$i]->locus[4]->locusname[0]->tagData == 'AMEL' and
			$test->specimen[$i]->locus[5]->locusname[0]->tagData == 'D5S818' and
			$test->specimen[$i]->locus[6]->locusname[0]->tagData == 'FGA' and
			$test->specimen[$i]->locus[7]->locusname[0]->tagData == 'D8S1179' and
			$test->specimen[$i]->locus[8]->locusname[0]->tagData == 'D21S11' and
			$test->specimen[$i]->locus[9]->locusname[0]->tagData == 'D7S820' and
			$test->specimen[$i]->locus[10]->locusname[0]->tagData == 'CSF1PO' and
			$test->specimen[$i]->locus[11]->locusname[0]->tagData == 'D3S1358' and
			$test->specimen[$i]->locus[12]->locusname[0]->tagData == 'TH01' and
			$test->specimen[$i]->locus[13]->locusname[0]->tagData == 'D13S317' and
			$test->specimen[$i]->locus[14]->locusname[0]->tagData == 'D16S539' and
			$test->specimen[$i]->locus[15]->locusname[0]->tagData == 'D2S1338')
			{
				
						$sql = "insert into reference (dna, D19S433_1,D19S433_2,
															VWA_1,VWA_2,
															TPOX_1,TPOX_2,
															D18S51_1,D18S51_2,
															AMEL_1,AMEL_2,
															D5S818_1,D5S818_2,
															FGA_1,FGA_2,
															D8S1179_1,D8S1179_2,
															D21S11_1,D21S11_2,
															D7S820_1,D7S820_2,
															CSF1PO_1,CSF1PO_2,
															D3S1358_1,D3S1358_2,
															TH01_1,TH01_2,
															D13S317_1,D13S317_2,
															D16S539_1,D16S539_2,
															D2S1338_1,D2S1338_2,
															sDate) values ('"
							      .$test->specimen[$i]->specimenid[0]->tagData."'";
								  for($j=0;$j<16;$j++){
									 $sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
									 if(!$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData){
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
										}else{
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData."'"; 
										}
								  }
					   $sql.=",'".date("Y-m-d")."');";
					$result = mysql_query($sql);
					
			} //D19 ��
			//vwa ����
			elseif ($test->specimen[$i]->locus[0]->locusname[0]->tagData == 'vWA' and
			$test->specimen[$i]->locus[1]->locusname[0]->tagData == 'TPOX' and
			$test->specimen[$i]->locus[2]->locusname[0]->tagData == 'D18S51' and
			$test->specimen[$i]->locus[3]->locusname[0]->tagData == 'AMEL' and
			$test->specimen[$i]->locus[4]->locusname[0]->tagData == 'D5S818' and
			$test->specimen[$i]->locus[5]->locusname[0]->tagData == 'FGA' and
			$test->specimen[$i]->locus[6]->locusname[0]->tagData == 'D8S1179' and
			$test->specimen[$i]->locus[7]->locusname[0]->tagData == 'D21S11' and
			$test->specimen[$i]->locus[8]->locusname[0]->tagData == 'D7S820' and
			$test->specimen[$i]->locus[9]->locusname[0]->tagData == 'CSF1PO' and
			$test->specimen[$i]->locus[10]->locusname[0]->tagData == 'D3S1358' and
			$test->specimen[$i]->locus[11]->locusname[0]->tagData == 'TH01' and
			$test->specimen[$i]->locus[12]->locusname[0]->tagData == 'D13S317' and
			$test->specimen[$i]->locus[13]->locusname[0]->tagData == 'D16S539' and
			$test->specimen[$i]->locus[14]->locusname[0]->tagData == 'D2S1338' and
			$test->specimen[$i]->locus[15]->locusname[0]->tagData == 'D19S433')
			{
				
						$sql = "insert into reference (dna, VWA_1,VWA_2,
															TPOX_1,TPOX_2,
															D18S51_1,D18S51_2,
															AMEL_1,AMEL_2,
															D5S818_1,D5S818_2,
															FGA_1,FGA_2,
															D8S1179_1,D8S1179_2,
															D21S11_1,D21S11_2,
															D7S820_1,D7S820_2,
															CSF1PO_1,CSF1PO_2,
															D3S1358_1,D3S1358_2,
															TH01_1,TH01_2,
															D13S317_1,D13S317_2,
															D16S539_1,D16S539_2,
															D2S1338_1,D2S1338_2,
															D19S433_1,D19S433_2,
															sDate) values ('"
							      .$test->specimen[$i]->specimenid[0]->tagData."'";
								  for($j=0;$j<16;$j++){
									 $sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
									 if(!$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData){
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
										}else{
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData."'"; 
										}
								  }
					   $sql.=",'".date("Y-m-d")."');";
					$result = mysql_query($sql);
					
			} //vwa ��
			//tpox ����
			elseif ($test->specimen[$i]->locus[0]->locusname[0]->tagData == 'TPOX' and
			$test->specimen[$i]->locus[1]->locusname[0]->tagData == 'D18S51' and
			$test->specimen[$i]->locus[2]->locusname[0]->tagData == 'AMEL' and
			$test->specimen[$i]->locus[3]->locusname[0]->tagData == 'D5S818' and
			$test->specimen[$i]->locus[4]->locusname[0]->tagData == 'FGA' and
			$test->specimen[$i]->locus[5]->locusname[0]->tagData == 'D8S1179' and
			$test->specimen[$i]->locus[6]->locusname[0]->tagData == 'D21S11' and
			$test->specimen[$i]->locus[7]->locusname[0]->tagData == 'D7S820' and
			$test->specimen[$i]->locus[8]->locusname[0]->tagData == 'CSF1PO' and
			$test->specimen[$i]->locus[9]->locusname[0]->tagData == 'D3S1358' and
			$test->specimen[$i]->locus[10]->locusname[0]->tagData == 'TH01' and
			$test->specimen[$i]->locus[11]->locusname[0]->tagData == 'D13S317' and
			$test->specimen[$i]->locus[12]->locusname[0]->tagData == 'D16S539' and
			$test->specimen[$i]->locus[13]->locusname[0]->tagData == 'D2S1338' and
			$test->specimen[$i]->locus[14]->locusname[0]->tagData == 'D19S433' and
			$test->specimen[$i]->locus[15]->locusname[0]->tagData == 'vWA')
			{
				
						$sql = "insert into reference (dna, TPOX_1,TPOX_2,
															D18S51_1,D18S51_2,
															AMEL_1,AMEL_2,
															D5S818_1,D5S818_2,
															FGA_1,FGA_2,
															D8S1179_1,D8S1179_2,
															D21S11_1,D21S11_2,
															D7S820_1,D7S820_2,
															CSF1PO_1,CSF1PO_2,
															D3S1358_1,D3S1358_2,
															TH01_1,TH01_2,
															D13S317_1,D13S317_2,
															D16S539_1,D16S539_2,
															D2S1338_1,D2S1338_2,
															D19S433_1,D19S433_2,
															VWA_1,VWA_2,
															sDate) values ('"
							      .$test->specimen[$i]->specimenid[0]->tagData."'";
								  for($j=0;$j<16;$j++){
									 $sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
									 if(!$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData){
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
										}else{
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData."'"; 
										}
								  }
					   $sql.=",'".date("Y-m-d")."');";
					$result = mysql_query($sql);
					
			} //tpox ��
			//D18 ����
			elseif ($test->specimen[$i]->locus[0]->locusname[0]->tagData == 'D18S51' and
			$test->specimen[$i]->locus[1]->locusname[0]->tagData == 'AMEL' and
			$test->specimen[$i]->locus[2]->locusname[0]->tagData == 'D5S818' and
			$test->specimen[$i]->locus[3]->locusname[0]->tagData == 'FGA' and
			$test->specimen[$i]->locus[4]->locusname[0]->tagData == 'D8S1179' and
			$test->specimen[$i]->locus[5]->locusname[0]->tagData == 'D21S11' and
			$test->specimen[$i]->locus[6]->locusname[0]->tagData == 'D7S820' and
			$test->specimen[$i]->locus[7]->locusname[0]->tagData == 'CSF1PO' and
			$test->specimen[$i]->locus[8]->locusname[0]->tagData == 'D3S1358' and
			$test->specimen[$i]->locus[9]->locusname[0]->tagData == 'TH01' and
			$test->specimen[$i]->locus[10]->locusname[0]->tagData == 'D13S317' and
			$test->specimen[$i]->locus[11]->locusname[0]->tagData == 'D16S539' and
			$test->specimen[$i]->locus[12]->locusname[0]->tagData == 'D2S1338' and
			$test->specimen[$i]->locus[13]->locusname[0]->tagData == 'D19S433' and
			$test->specimen[$i]->locus[14]->locusname[0]->tagData == 'vWA' and
			$test->specimen[$i]->locus[15]->locusname[0]->tagData == 'TPOX')
			{
				
						$sql = "insert into reference (dna, D18S51_1,D18S51_2,
															AMEL_1,AMEL_2,
															D5S818_1,D5S818_2,
															FGA_1,FGA_2,
															D8S1179_1,D8S1179_2,
															D21S11_1,D21S11_2,
															D7S820_1,D7S820_2,
															CSF1PO_1,CSF1PO_2,
															D3S1358_1,D3S1358_2,
															TH01_1,TH01_2,
															D13S317_1,D13S317_2,
															D16S539_1,D16S539_2,
															D2S1338_1,D2S1338_2,
															D19S433_1,D19S433_2,
															VWA_1,VWA_2,
															TPOX_1,TPOX_2,
															sDate) values ('"
							      .$test->specimen[$i]->specimenid[0]->tagData."'";
								  for($j=0;$j<16;$j++){
									 $sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
									 if(!$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData){
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
										}else{
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData."'"; 
										}
								  }
					   $sql.=",'".date("Y-m-d")."');";
					$result = mysql_query($sql);
					
			} //D18 ��
			//AMEL ����
			elseif ($test->specimen[$i]->locus[0]->locusname[0]->tagData == 'AMEL' and
			$test->specimen[$i]->locus[1]->locusname[0]->tagData == 'D5S818' and
			$test->specimen[$i]->locus[2]->locusname[0]->tagData == 'FGA' and
			$test->specimen[$i]->locus[3]->locusname[0]->tagData == 'D8S1179' and
			$test->specimen[$i]->locus[4]->locusname[0]->tagData == 'D21S11' and
			$test->specimen[$i]->locus[5]->locusname[0]->tagData == 'D7S820' and
			$test->specimen[$i]->locus[6]->locusname[0]->tagData == 'CSF1PO' and
			$test->specimen[$i]->locus[7]->locusname[0]->tagData == 'D3S1358' and
			$test->specimen[$i]->locus[8]->locusname[0]->tagData == 'TH01' and
			$test->specimen[$i]->locus[9]->locusname[0]->tagData == 'D13S317' and
			$test->specimen[$i]->locus[10]->locusname[0]->tagData == 'D16S539' and
			$test->specimen[$i]->locus[11]->locusname[0]->tagData == 'D2S1338' and
			$test->specimen[$i]->locus[12]->locusname[0]->tagData == 'D19S433' and
			$test->specimen[$i]->locus[13]->locusname[0]->tagData == 'vWA' and
			$test->specimen[$i]->locus[14]->locusname[0]->tagData == 'TPOX' and
			$test->specimen[$i]->locus[15]->locusname[0]->tagData == 'D18S51')
			{
				
						$sql = "insert into reference (dna, AMEL_1,AMEL_2,
															D5S818_1,D5S818_2,
															FGA_1,FGA_2,
															D8S1179_1,D8S1179_2,
															D21S11_1,D21S11_2,
															D7S820_1,D7S820_2,
															CSF1PO_1,CSF1PO_2,
															D3S1358_1,D3S1358_2,
															TH01_1,TH01_2,
															D13S317_1,D13S317_2,
															D16S539_1,D16S539_2,
															D2S1338_1,D2S1338_2,
															D19S433_1,D19S433_2,
															VWA_1,VWA_2,
															TPOX_1,TPOX_2,
															D18S51_1,D18S51_2,
															sDate) values ('"
							      .$test->specimen[$i]->specimenid[0]->tagData."'";
								  for($j=0;$j<16;$j++){
									 $sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
									 if(!$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData){
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
										}else{
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData."'"; 
										}
								  }
					   $sql.=",'".date("Y-m-d")."');";
					$result = mysql_query($sql);
					
			} //AMEL ��
			//D5 ����
			elseif ($test->specimen[$i]->locus[0]->locusname[0]->tagData == 'D5S818' and
			$test->specimen[$i]->locus[1]->locusname[0]->tagData == 'FGA' and
			$test->specimen[$i]->locus[2]->locusname[0]->tagData == 'D8S1179' and
			$test->specimen[$i]->locus[3]->locusname[0]->tagData == 'D21S11' and
			$test->specimen[$i]->locus[4]->locusname[0]->tagData == 'D7S820' and
			$test->specimen[$i]->locus[5]->locusname[0]->tagData == 'CSF1PO' and
			$test->specimen[$i]->locus[6]->locusname[0]->tagData == 'D3S1358' and
			$test->specimen[$i]->locus[7]->locusname[0]->tagData == 'TH01' and
			$test->specimen[$i]->locus[8]->locusname[0]->tagData == 'D13S317' and
			$test->specimen[$i]->locus[9]->locusname[0]->tagData == 'D16S539' and
			$test->specimen[$i]->locus[10]->locusname[0]->tagData == 'D2S1338' and
			$test->specimen[$i]->locus[11]->locusname[0]->tagData == 'D19S433' and
			$test->specimen[$i]->locus[12]->locusname[0]->tagData == 'vWA' and
			$test->specimen[$i]->locus[13]->locusname[0]->tagData == 'TPOX' and
			$test->specimen[$i]->locus[14]->locusname[0]->tagData == 'D18S51' and
			$test->specimen[$i]->locus[15]->locusname[0]->tagData == 'AMEL')
			{
				
						$sql = "insert into reference (dna, D5S818_1,D5S818_2,
															FGA_1,FGA_2,
															D8S1179_1,D8S1179_2,
															D21S11_1,D21S11_2,
															D7S820_1,D7S820_2,
															CSF1PO_1,CSF1PO_2,
															D3S1358_1,D3S1358_2,
															TH01_1,TH01_2,
															D13S317_1,D13S317_2,
															D16S539_1,D16S539_2,
															D2S1338_1,D2S1338_2,
															D19S433_1,D19S433_2,
															VWA_1,VWA_2,
															TPOX_1,TPOX_2,
															D18S51_1,D18S51_2,
															AMEL_1,AMEL_2,
															sDate) values ('"
							      .$test->specimen[$i]->specimenid[0]->tagData."'";
								  for($j=0;$j<16;$j++){
									 $sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
									 if(!$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData){
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
										}else{
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData."'"; 
										}
								  }
					   $sql.=",'".date("Y-m-d")."');";
					$result = mysql_query($sql);
					
			} //D5 ��
			//FGA ����
			elseif ($test->specimen[$i]->locus[0]->locusname[0]->tagData == 'FGA' and
			$test->specimen[$i]->locus[1]->locusname[0]->tagData == 'D8S1179' and
			$test->specimen[$i]->locus[2]->locusname[0]->tagData == 'D21S11' and
			$test->specimen[$i]->locus[3]->locusname[0]->tagData == 'D7S820' and
			$test->specimen[$i]->locus[4]->locusname[0]->tagData == 'CSF1PO' and
			$test->specimen[$i]->locus[5]->locusname[0]->tagData == 'D3S1358' and
			$test->specimen[$i]->locus[6]->locusname[0]->tagData == 'TH01' and
			$test->specimen[$i]->locus[7]->locusname[0]->tagData == 'D13S317' and
			$test->specimen[$i]->locus[8]->locusname[0]->tagData == 'D16S539' and
			$test->specimen[$i]->locus[9]->locusname[0]->tagData == 'D2S1338' and
			$test->specimen[$i]->locus[10]->locusname[0]->tagData == 'D19S433' and
			$test->specimen[$i]->locus[11]->locusname[0]->tagData == 'vWA' and
			$test->specimen[$i]->locus[12]->locusname[0]->tagData == 'TPOX' and
			$test->specimen[$i]->locus[13]->locusname[0]->tagData == 'D18S51' and
			$test->specimen[$i]->locus[14]->locusname[0]->tagData == 'AMEL' and
			$test->specimen[$i]->locus[15]->locusname[0]->tagData == 'D5S818')
			{
				
						$sql = "insert into reference (dna, FGA_1,FGA_2,
															D8S1179_1,D8S1179_2,
															D21S11_1,D21S11_2,
															D7S820_1,D7S820_2,
															CSF1PO_1,CSF1PO_2,
															D3S1358_1,D3S1358_2,
															TH01_1,TH01_2,
															D13S317_1,D13S317_2,
															D16S539_1,D16S539_2,
															D2S1338_1,D2S1338_2,
															D19S433_1,D19S433_2,
															VWA_1,VWA_2,
															TPOX_1,TPOX_2,
															D18S51_1,D18S51_2,
															AMEL_1,AMEL_2,
															D5S818_1,D5S818_2,
															sDate) values ('"
							      .$test->specimen[$i]->specimenid[0]->tagData."'";
								  for($j=0;$j<16;$j++){
									 $sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
									 if(!$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData){
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[0]->allelevalue[0]->tagData."'";
										}else{
										$sql.=",'".$test->specimen[$i]->locus[$j]->allele[1]->allelevalue[0]->tagData."'"; 
										}
								  }
					   $sql.=",'".date("Y-m-d")."');";
					$result = mysql_query($sql);
					
			} //FGA ��
	} // for
	echo $count." profiles are uploaded to the reference database";
}
?>
</body>
</html>
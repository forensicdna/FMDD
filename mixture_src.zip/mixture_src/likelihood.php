<?php
	require('statisticVar.php');
	require('frequency.php');
	// Th01 �ڸ� LR ======================================================================================
	if ($th01a && $th01b && $th01c && $th01d){
		$th01_LR = 1 / (2*$arr['th01'][$sus_th01a]*$arr['th01'][$sus_th01b]);
	}
	elseif ($th01a && $th01b && $th01c){
		if ($vic_th01a && $vic_th01b){
			if (($vic_th01a == $th01a)&&($vic_th01b == $th01b)) {
				$th01_LR = 1 / $arr['th01'][$th01c]*(2*$arr['th01'][$th01a] + 2*$arr['th01'][$th01b] + $arr['th01'][$th01c]);
			}elseif (($vic_th01a == $th01b)&&($vic_th01b == $th01c)){
				$th01_LR = 1 / $arr['th01'][$th01a]*(2*$arr['th01'][$th01b] + 2*$arr['th01'][$th01c] + $arr['th01'][$th01a]);
			}elseif (($vic_th01a == $th01c)&&($vic_th01b == $th01a)){
				$th01_LR = 1 / $arr['th01'][$th01b]*(2*$arr['th01'][$th01c] + 2*$arr['th01'][$th01a] + $arr['th01'][$th01b]);
			}
		}
	}elseif ($vic_th01a){
			if ($vic_th01a != ($sus_th01a && $sus_th01b)){
				$th01_LR = 1 / 2*$arr['th01'][$sus_th01a] * $arr['th01'][$sus_th01b];
			}
	}elseif ($th01a && $th01b){
		if ($vic_th01a && $vic_th01b){
			$th01_LR = 1 / ($arr['th01'][$th01a] + $arr['th01'][$th01b])*($arr['th01'][$th01a] + $arr['th01'][$th01b]);
		}elseif ($vic_th01a) {
			if($vic_th01a == $th01a){
				$th01_LR = 1/ $arr['th01'][$th01b]*(2*$arr['th01'][$th01a]+$arr['th01'][$th01b]);
			}elseif ($vic_th01a == $th01b){
				$th01_LR = 1/ $arr['th01'][$th01a]*(2*$arr['th01'][$th01a]+$arr['th01'][$th01b]);
			}
		}
	}
	elseif ($th01a && $vic_th01a && $sus_th01a){
		$th01_LR = 1 / $arr['th01'][$th01a] * $arr['th01'][$th01a];
	}

	// TPOX �ڸ� LR ======================================================================================

	if ($tpoxa && $tpoxb && $tpoxc && $tpoxd){
		$tpox_LR = 1 / (2*$arr['tpox'][$sus_tpoxa]*$arr['tpox'][$sus_tpoxb]);
	}
	elseif ($tpoxa && $tpoxb && $tpoxc){
		if ($vic_tpoxa && $vic_tpoxb){
			if (($vic_tpoxa == $tpoxa)&&($vic_tpoxb == $tpoxb)) {
				$tpox_LR = 1 / $arr['tpox'][$tpoxc]*(2*$arr['tpox'][$tpoxa] + 2*$arr['tpox'][$tpoxb] + $arr['tpox'][$tpoxc]);
			}elseif (($vic_tpoxa == $tpoxb)&&($vic_tpoxb == $tpoxc)){
				$tpox_LR = 1 / $arr['tpox'][$tpoxa]*(2*$arr['tpox'][$tpoxb] + 2*$arr['tpox'][$tpoxc] + $arr['tpox'][$tpoxa]);
			}elseif (($vic_tpoxa == $tpoxc)&&($vic_tpoxb == $tpoxa)){
				$tpox_LR = 1 / $arr['tpox'][$tpoxb]*(2*$arr['tpox'][$tpoxc] + 2*$arr['tpox'][$tpoxa] + $arr['tpox'][$tpoxb]);
			}
		}
	}elseif ($vic_tpoxa){
			if ($vic_tpoxa != ($sus_tpoxa && $sus_tpoxb)){
				$tpox_LR = 1 / 2*$arr['tpox'][$sus_tpoxa] * $arr['tpox'][$sus_tpoxb];
			}
	}elseif ($tpoxa && $tpoxb){
		if ($vic_tpoxa && $vic_tpoxb){
			$tpox_LR = 1 / ($arr['tpox'][$tpoxa] + $arr['tpox'][$tpoxb])*($arr['tpox'][$tpoxa] + $arr['tpox'][$tpoxb]);
		}elseif ($vic_tpoxa) {
			if($vic_tpoxa == $tpoxa){
				$tpox_LR = 1/ $arr['tpox'][$tpoxb]*(2*$arr['tpox'][$tpoxa]+$arr['tpox'][$tpoxb]);
			}elseif ($vic_tpoxa == $tpoxb){
				$tpox_LR = 1/ $arr['tpox'][$tpoxa]*(2*$arr['tpox'][$tpoxa]+$arr['tpox'][$tpoxb]);
			}
		}
	}
	elseif ($tpoxa && $vic_tpoxa && $sus_tpoxa){
		$tpox_LR = 1 / $arr['tpox'][$tpoxa] * $arr['tpox'][$tpoxa];
	}

	// CSF1PO �ڸ� LR ======================================================================================

	if ($csf1poa && $csf1pob && $csf1poc && $csf1pod){
		$csf1po_LR = 1 / (2*$arr['csf1po'][$sus_csf1poa]*$arr['csf1po'][$sus_csf1pob]);
	}
	elseif ($csf1poa && $csf1pob && $csf1poc){
		if ($vic_csf1poa && $vic_csf1pob){
			if (($vic_csf1poa == $csf1poa)&&($vic_csf1pob == $csf1pob)) {
				$csf1po_LR = 1 / $arr['csf1po'][$csf1poc]*(2*$arr['csf1po'][$csf1poa] + 2*$arr['csf1po'][$csf1pob] + $arr['csf1po'][$csf1poc]);
			}elseif (($vic_csf1poa == $csf1pob)&&($vic_csf1pob == $csf1poc)){
				$csf1po_LR = 1 / $arr['csf1po'][$csf1poa]*(2*$arr['csf1po'][$csf1pob] + 2*$arr['csf1po'][$csf1poc] + $arr['csf1po'][$csf1poa]);
			}elseif (($vic_csf1poa == $csf1poc)&&($vic_csf1pob == $csf1poa)){
				$csf1po_LR = 1 / $arr['csf1po'][$csf1pob]*(2*$arr['csf1po'][$csf1poc] + 2*$arr['csf1po'][$csf1poa] + $arr['csf1po'][$csf1pob]);
			}
		}
	}elseif ($vic_csf1poa){
			if ($vic_csf1poa != ($sus_csf1poa && $sus_csf1pob)){
				$csf1po_LR = 1 / 2*$arr['csf1po'][$sus_csf1poa] * $arr['csf1po'][$sus_csf1pob];
			}
	}elseif ($csf1poa && $csf1pob){
		if ($vic_csf1poa && $vic_csf1pob){
			$csf1po_LR = 1 / ($arr['csf1po'][$csf1poa] + $arr['csf1po'][$csf1pob])*($arr['csf1po'][$csf1poa] + $arr['csf1po'][$csf1pob]);
		}elseif ($vic_csf1poa) {
			if($vic_csf1poa == $csf1poa){
				$csf1po_LR = 1/ $arr['csf1po'][$csf1pob]*(2*$arr['csf1po'][$csf1poa]+$arr['csf1po'][$csf1pob]);
			}elseif ($vic_csf1poa == $csf1pob){
				$csf1po_LR = 1/ $arr['csf1po'][$csf1poa]*(2*$arr['csf1po'][$csf1poa]+$arr['csf1po'][$csf1pob]);
			}
		}
	}
	elseif ($csf1poa && $vic_csf1poa && $sus_csf1poa){
		$csf1po_LR = 1 / $arr['csf1po'][$csf1poa] * $arr['csf1po'][$csf1poa];
	}
	// d3 �ڸ� LR ======================================================================================
	if ($d3a && $d3b && $d3c && $d3d){
		$d3_LR = 1 / (2*$arr['d3'][$sus_d3a]*$arr['d3'][$sus_d3b]);
	}
	elseif ($d3a && $d3b && $d3c){
		if ($vic_d3a && $vic_d3b){
			if (($vic_d3a == $d3a)&&($vic_d3b == $d3b)) {
				$d3_LR = 1 / $arr['d3'][$d3c]*(2*$arr['d3'][$d3a] + 2*$arr['d3'][$d3b] + $arr['d3'][$d3c]);
			}elseif (($vic_d3a == $d3b)&&($vic_d3b == $d3c)){
				$d3_LR = 1 / $arr['d3'][$d3a]*(2*$arr['d3'][$d3b] + 2*$arr['d3'][$d3c] + $arr['d3'][$d3a]);
			}elseif (($vic_d3a == $d3c)&&($vic_d3b == $d3a)){
				$d3_LR = 1 / $arr['d3'][$d3b]*(2*$arr['d3'][$d3c] + 2*$arr['d3'][$d3a] + $arr['d3'][$d3b]);
			}
		}
	}elseif ($vic_d3a){
			if ($vic_d3a != ($sus_d3a && $sus_d3b)){
				$d3_LR = 1 / 2*$arr['d3'][$sus_d3a] * $arr['d3'][$sus_d3b];
			}
	}elseif ($d3a && $d3b){
		if ($vic_d3a && $vic_d3b){
			$d3_LR = 1 / ($arr['d3'][$d3a] + $arr['d3'][$d3b])*($arr['d3'][$d3a] + $arr['d3'][$d3b]);
		}elseif ($vic_d3a) {
			if($vic_d3a == $d3a){
				$d3_LR = 1/ $arr['d3'][$d3b]*(2*$arr['d3'][$d3a]+$arr['d3'][$d3b]);
			}elseif ($vic_d3a == $d3b){
				$d3_LR = 1/ $arr['d3'][$d3a]*(2*$arr['d3'][$d3a]+$arr['d3'][$d3b]);
			}
		}
	}
	elseif ($d3a && $vic_d3a && $sus_d3a){
		$d3_LR = 1 / $arr['d3'][$d3a] * $arr['d3'][$d3a];
	}
	// vwa �ڸ� LR ======================================================================================

	if ($vwaa && $vwab && $vwac && $vwad){
		$vwa_LR = 1 / (2*$arr['vwa'][$sus_vwaa]*$arr['vwa'][$sus_vwab]);
	}
	elseif ($vwaa && $vwab && $vwac){
		if ($vic_vwaa && $vic_vwab){
			if (($vic_vwaa == $vwaa)&&($vic_vwab == $vwab)) {
				$vwa_LR = 1 / $arr['vwa'][$vwac]*(2*$arr['vwa'][$vwaa] + 2*$arr['vwa'][$vwab] + $arr['vwa'][$vwac]);
			}elseif (($vic_vwaa == $vwab)&&($vic_vwab == $vwac)){
				$vwa_LR = 1 / $arr['vwa'][$vwaa]*(2*$arr['vwa'][$vwab] + 2*$arr['vwa'][$vwac] + $arr['vwa'][$vwaa]);
			}elseif (($vic_vwaa == $vwac)&&($vic_vwab == $vwaa)){
				$vwa_LR = 1 / $arr['vwa'][$vwab]*(2*$arr['vwa'][$vwac] + 2*$arr['vwa'][$vwaa] + $arr['vwa'][$vwab]);
			}
		}
	}elseif ($vic_vwaa){
			if ($vic_vwaa != ($sus_vwaa && $sus_vwab)){
				$vwa_LR = 1 / 2*$arr['vwa'][$sus_vwaa] * $arr['vwa'][$sus_vwab];
			}
	}elseif ($vwaa && $vwab){
		if ($vic_vwaa && $vic_vwab){
			$vwa_LR = 1 / ($arr['vwa'][$vwaa] + $arr['vwa'][$vwab])*($arr['vwa'][$vwaa] + $arr['vwa'][$vwab]);
		}elseif ($vic_vwaa) {
			if($vic_vwaa == $vwaa){
				$vwa_LR = 1/ $arr['vwa'][$vwab]*(2*$arr['vwa'][$vwaa]+$arr['vwa'][$vwab]);
			}elseif ($vic_vwaa == $vwab){
				$vwa_LR = 1/ $arr['vwa'][$vwaa]*(2*$arr['vwa'][$vwaa]+$arr['vwa'][$vwab]);
			}
		}
	}
	elseif ($vwaa && $vic_vwaa && $sus_vwaa){
		$vwa_LR = 1 / $arr['vwa'][$vwaa] * $arr['vwa'][$vwaa];
	}
	// fga �ڸ� LR ======================================================================================

	if ($fgaa && $fgab && $fgac && $fgad){
		$fga_LR = 1 / (2*$arr['fga'][$sus_fgaa]*$arr['fga'][$sus_fgab]);
	}
	elseif ($fgaa && $fgab && $fgac){
		if ($vic_fgaa && $vic_fgab){
			if (($vic_fgaa == $fgaa)&&($vic_fgab == $fgab)) {
				$fga_LR = 1 / $arr['fga'][$fgac]*(2*$arr['fga'][$fgaa] + 2*$arr['fga'][$fgab] + $arr['fga'][$fgac]);
			}elseif (($vic_fgaa == $fgab)&&($vic_fgab == $fgac)){
				$fga_LR = 1 / $arr['fga'][$fgaa]*(2*$arr['fga'][$fgab] + 2*$arr['fga'][$fgac] + $arr['fga'][$fgaa]);
			}elseif (($vic_fgaa == $fgac)&&($vic_fgab == $fgaa)){
				$fga_LR = 1 / $arr['fga'][$fgab]*(2*$arr['fga'][$fgac] + 2*$arr['fga'][$fgaa] + $arr['fga'][$fgab]);
			}
		}
	}elseif ($vic_fgaa){
			if ($vic_fgaa != ($sus_fgaa && $sus_fgab)){
				$fga_LR = 1 / 2*$arr['fga'][$sus_fgaa] * $arr['fga'][$sus_fgab];
			}
	}elseif ($fgaa && $fgab){
		if ($vic_fgaa && $vic_fgab){
			$fga_LR = 1 / ($arr['fga'][$fgaa] + $arr['fga'][$fgab])*($arr['fga'][$fgaa] + $arr['fga'][$fgab]);
		}elseif ($vic_fgaa) {
			if($vic_fgaa == $fgaa){
				$fga_LR = 1/ $arr['fga'][$fgab]*(2*$arr['fga'][$fgaa]+$arr['fga'][$fgab]);
			}elseif ($vic_fgaa == $fgab){
				$fga_LR = 1/ $arr['fga'][$fgaa]*(2*$arr['fga'][$fgaa]+$arr['fga'][$fgab]);
			}
		}
	}
	elseif ($fgaa && $vic_fgaa && $sus_fgaa){
		$fga_LR = 1 / $arr['fga'][$fgaa] * $arr['fga'][$fgaa];
	}


	// d5 �ڸ� LR ======================================================================================
	if ($d5a && $d5b && $d5c && $d5d){
		$d5_LR = 1 / (2*$arr['d5'][$sus_d5a]*$arr['d5'][$sus_d5b]);
	}
	elseif ($d5a && $d5b && $d5c){
		if ($vic_d5a && $vic_d5b){
			if (($vic_d5a == $d5a)&&($vic_d5b == $d5b)) {
				$d5_LR = 1 / $arr['d5'][$d5c]*(2*$arr['d5'][$d5a] + 2*$arr['d5'][$d5b] + $arr['d5'][$d5c]);
			}elseif (($vic_d5a == $d5b)&&($vic_d5b == $d5c)){
				$d5_LR = 1 / $arr['d5'][$d5a]*(2*$arr['d5'][$d5b] + 2*$arr['d5'][$d5c] + $arr['d5'][$d5a]);
			}elseif (($vic_d5a == $d5c)&&($vic_d5b == $d5a)){
				$d5_LR = 1 / $arr['d5'][$d5b]*(2*$arr['d5'][$d5c] + 2*$arr['d5'][$d5a] + $arr['d5'][$d5b]);
			}
		}
	}elseif ($vic_d5a){
			if ($vic_d5a != ($sus_d5a && $sus_d5b)){
				$d5_LR = 1 / 2*$arr['d5'][$sus_d5a] * $arr['d5'][$sus_d5b];
			}
	}elseif ($d5a && $d5b){
		if ($vic_d5a && $vic_d5b){
			$d5_LR = 1 / ($arr['d5'][$d5a] + $arr['d5'][$d5b])*($arr['d5'][$d5a] + $arr['d5'][$d5b]);
		}elseif ($vic_d5a) {
			if($vic_d5a == $d5a){
				$d5_LR = 1/ $arr['d5'][$d5b]*(2*$arr['d5'][$d5a]+$arr['d5'][$d5b]);
			}elseif ($vic_d5a == $d5b){
				$d5_LR = 1/ $arr['d5'][$d5a]*(2*$arr['d5'][$d5a]+$arr['d5'][$d5b]);
			}
		}
	}
	elseif ($d5a && $vic_d5a && $sus_d5a){
		$d5_LR = 1 / $arr['d5'][$d5a] * $arr['d5'][$d5a];
	}

	// d13 �ڸ� LR ======================================================================================

	if ($d13a && $d13b && $d13c && $d13d){
		$d13_LR = 1 / (2*$arr['d13'][$sus_d13a]*$arr['d13'][$sus_d13b]);
	}
	elseif ($d13a && $d13b && $d13c){
		if ($vic_d13a && $vic_d13b){
			if (($vic_d13a == $d13a)&&($vic_d13b == $d13b)) {
				$d13_LR = 1 / $arr['d13'][$d13c]*(2*$arr['d13'][$d13a] + 2*$arr['d13'][$d13b] + $arr['d13'][$d13c]);
			}elseif (($vic_d13a == $d13b)&&($vic_d13b == $d13c)){
				$d13_LR = 1 / $arr['d13'][$d13a]*(2*$arr['d13'][$d13b] + 2*$arr['d13'][$d13c] + $arr['d13'][$d13a]);
			}elseif (($vic_d13a == $d13c)&&($vic_d13b == $d13a)){
				$d13_LR = 1 / $arr['d13'][$d13b]*(2*$arr['d13'][$d13c] + 2*$arr['d13'][$d13a] + $arr['d13'][$d13b]);
			}
		}
	}elseif ($vic_d13a){
			if ($vic_d13a != ($sus_d13a && $sus_d13b)){
				$d13_LR = 1 / 2*$arr['d13'][$sus_d13a] * $arr['d13'][$sus_d13b];
			}
	}elseif ($d13a && $d13b){
		if ($vic_d13a && $vic_d13b){
			$d13_LR = 1 / ($arr['d13'][$d13a] + $arr['d13'][$d13b])*($arr['d13'][$d13a] + $arr['d13'][$d13b]);
		}elseif ($vic_d13a) {
			if($vic_d13a == $d13a){
				$d13_LR = 1/ $arr['d13'][$d13b]*(2*$arr['d13'][$d13a]+$arr['d13'][$d13b]);
			}elseif ($vic_d13a == $d13b){
				$d13_LR = 1/ $arr['d13'][$d13a]*(2*$arr['d13'][$d13a]+$arr['d13'][$d13b]);
			}
		}
	}
	elseif ($d13a && $vic_d13a && $sus_d13a){
		$d13_LR = 1 / $arr['d13'][$d13a] * $arr['d13'][$d13a];
	}

	// d7 �ڸ� LR ======================================================================================

	if ($d7a && $d7b && $d7c && $d7d){
		$d7_LR = 1 / (2*$arr['d7'][$sus_d7a]*$arr['d7'][$sus_d7b]);
	}
	elseif ($d7a && $d7b && $d7c){
		if ($vic_d7a && $vic_d7b){
			if (($vic_d7a == $d7a)&&($vic_d7b == $d7b)) {
				$d7_LR = 1 / $arr['d7'][$d7c]*(2*$arr['d7'][$d7a] + 2*$arr['d7'][$d7b] + $arr['d7'][$d7c]);
			}elseif (($vic_d7a == $d7b)&&($vic_d7b == $d7c)){
				$d7_LR = 1 / $arr['d7'][$d7a]*(2*$arr['d7'][$d7b] + 2*$arr['d7'][$d7c] + $arr['d7'][$d7a]);
			}elseif (($vic_d7a == $d7c)&&($vic_d7b == $d7a)){
				$d7_LR = 1 / $arr['d7'][$d7b]*(2*$arr['d7'][$d7c] + 2*$arr['d7'][$d7a] + $arr['d7'][$d7b]);
			}
		}
	}elseif ($vic_d7a){
			if ($vic_d7a != ($sus_d7a && $sus_d7b)){
				$d7_LR = 1 / 2*$arr['d7'][$sus_d7a] * $arr['d7'][$sus_d7b];
			}
	}elseif ($d7a && $d7b){
		if ($vic_d7a && $vic_d7b){
			$d7_LR = 1 / ($arr['d7'][$d7a] + $arr['d7'][$d7b])*($arr['d7'][$d7a] + $arr['d7'][$d7b]);
		}elseif ($vic_d7a) {
			if($vic_d7a == $d7a){
				$d7_LR = 1/ $arr['d7'][$d7b]*(2*$arr['d7'][$d7a]+$arr['d7'][$d7b]);
			}elseif ($vic_d7a == $d7b){
				$d7_LR = 1/ $arr['d7'][$d7a]*(2*$arr['d7'][$d7a]+$arr['d7'][$d7b]);
			}
		}
	}
	elseif ($d7a && $vic_d7a && $sus_d7a){
		$d7_LR = 1 / $arr['d7'][$d7a] * $arr['d7'][$d7a];
	}

	// d16 �ڸ� LR ======================================================================================

	if ($d16a && $d16b && $d16c && $d16d){
		$d16_LR = 1 / (2*$arr['d16'][$sus_d16a]*$arr['d16'][$sus_d16b]);
	}
	elseif ($d16a && $d16b && $d16c){
		if ($vic_d16a && $vic_d16b){
			if (($vic_d16a == $d16a)&&($vic_d16b == $d16b)) {
				$d16_LR = 1 / $arr['d16'][$d16c]*(2*$arr['d16'][$d16a] + 2*$arr['d16'][$d16b] + $arr['d16'][$d16c]);
			}elseif (($vic_d16a == $d16b)&&($vic_d16b == $d16c)){
				$d16_LR = 1 / $arr['d16'][$d16a]*(2*$arr['d16'][$d16b] + 2*$arr['d16'][$d16c] + $arr['d16'][$d16a]);
			}elseif (($vic_d16a == $d16c)&&($vic_d16b == $d16a)){
				$d16_LR = 1 / $arr['d16'][$d16b]*(2*$arr['d16'][$d16c] + 2*$arr['d16'][$d16a] + $arr['d16'][$d16b]);
			}
		}
	}elseif ($vic_d16a){
			if ($vic_d16a != ($sus_d16a && $sus_d16b)){
				$d16_LR = 1 / 2*$arr['d16'][$sus_d16a] * $arr['d16'][$sus_d16b];
			}
	}elseif ($d16a && $d16b){
		if ($vic_d16a && $vic_d16b){
			$d16_LR = 1 / ($arr['d16'][$d16a] + $arr['d16'][$d16b])*($arr['d16'][$d16a] + $arr['d16'][$d16b]);
		}elseif ($vic_d16a) {
			if($vic_d16a == $d16a){
				$d16_LR = 1/ $arr['d16'][$d16b]*(2*$arr['d16'][$d16a]+$arr['d16'][$d16b]);
			}elseif ($vic_d16a == $d16b){
				$d16_LR = 1/ $arr['d16'][$d16a]*(2*$arr['d16'][$d16a]+$arr['d16'][$d16b]);
			}
		}
	}
	elseif ($d16a && $vic_d16a && $sus_d16a){
		$d16_LR = 1 / $arr['d16'][$d16a] * $arr['d16'][$d16a];
	}

	// d8 �ڸ� LR ======================================================================================

	if ($d8a && $d8b && $d8c && $d8d){
		$d8_LR = 1 / (2*$arr['d8'][$sus_d8a]*$arr['d8'][$sus_d8b]);
	}
	elseif ($d8a && $d8b && $d8c){
		if ($vic_d8a && $vic_d8b){
			if (($vic_d8a == $d8a)&&($vic_d8b == $d8b)) {
				$d8_LR = 1 / $arr['d8'][$d8c]*(2*$arr['d8'][$d8a] + 2*$arr['d8'][$d8b] + $arr['d8'][$d8c]);
			}elseif (($vic_d8a == $d8b)&&($vic_d8b == $d8c)){
				$d8_LR = 1 / $arr['d8'][$d8a]*(2*$arr['d8'][$d8b] + 2*$arr['d8'][$d8c] + $arr['d8'][$d8a]);
			}elseif (($vic_d8a == $d8c)&&($vic_d8b == $d8a)){
				$d8_LR = 1 / $arr['d8'][$d8b]*(2*$arr['d8'][$d8c] + 2*$arr['d8'][$d8a] + $arr['d8'][$d8b]);
			}
		}
	}elseif ($vic_d8a){
			if ($vic_d8a != ($sus_d8a && $sus_d8b)){
				$d8_LR = 1 / 2*$arr['d8'][$sus_d8a] * $arr['d8'][$sus_d8b];
			}
	}elseif ($d8a && $d8b){
		if ($vic_d8a && $vic_d8b){
			$d8_LR = 1 / ($arr['d8'][$d8a] + $arr['d8'][$d8b])*($arr['d8'][$d8a] + $arr['d8'][$d8b]);
		}elseif ($vic_d8a) {
			if($vic_d8a == $d8a){
				$d8_LR = 1/ $arr['d8'][$d8b]*(2*$arr['d8'][$d8a]+$arr['d8'][$d8b]);
			}elseif ($vic_d8a == $d8b){
				$d8_LR = 1/ $arr['d8'][$d8a]*(2*$arr['d8'][$d8a]+$arr['d8'][$d8b]);
			}
		}
	}
	elseif ($d8a && $vic_d8a && $sus_d8a){
		$d8_LR = 1 / $arr['d8'][$d8a] * $arr['d8'][$d8a];
	}

	// d21 �ڸ� LR ======================================================================================
	if ($d21a && $d21b && $d21c && $d21d){
		$d21_LR = 1 / (2*$arr['d21'][$sus_d21a]*$arr['d21'][$sus_d21b]);
	}
	elseif ($d21a && $d21b && $d21c){
		if ($vic_d21a && $vic_d21b){
			if (($vic_d21a == $d21a)&&($vic_d21b == $d21b)) {
				$d21_LR = 1 / $arr['d21'][$d21c]*(2*$arr['d21'][$d21a] + 2*$arr['d21'][$d21b] + $arr['d21'][$d21c]);
			}elseif (($vic_d21a == $d21b)&&($vic_d21b == $d21c)){
				$d21_LR = 1 / $arr['d21'][$d21a]*(2*$arr['d21'][$d21b] + 2*$arr['d21'][$d21c] + $arr['d21'][$d21a]);
			}elseif (($vic_d21a == $d21c)&&($vic_d21b == $d21a)){
				$d21_LR = 1 / $arr['d21'][$d21b]*(2*$arr['d21'][$d21c] + 2*$arr['d21'][$d21a] + $arr['d21'][$d21b]);
			}
		}
	}elseif ($vic_d21a){
			if ($vic_d21a != ($sus_d21a && $sus_d21b)){
				$d21_LR = 1 / 2*$arr['d21'][$sus_d21a] * $arr['d21'][$sus_d21b];
			}
	}elseif ($d21a && $d21b){
		if ($vic_d21a && $vic_d21b){
			$d21_LR = 1 / ($arr['d21'][$d21a] + $arr['d21'][$d21b])*($arr['d21'][$d21a] + $arr['d21'][$d21b]);
		}elseif ($vic_d21a) {
			if($vic_d21a == $d21a){
				$d21_LR = 1/ $arr['d21'][$d21b]*(2*$arr['d21'][$d21a]+$arr['d21'][$d21b]);
			}elseif ($vic_d21a == $d21b){
				$d21_LR = 1/ $arr['d21'][$d21a]*(2*$arr['d21'][$d21a]+$arr['d21'][$d21b]);
			}
		}
	}
	elseif ($d21a && $vic_d21a && $sus_d21a){
		$d21_LR = 1 / $arr['d21'][$d21a] * $arr['d21'][$d21a];
	}

	// d18 �ڸ� LR ======================================================================================
	if ($d18a && $d18b && $d18c && $d18d){
		$d18_LR = 1 / (2*$arr['d18'][$sus_d18a]*$arr['d18'][$sus_d18b]);
	}
	elseif ($d18a && $d18b && $d18c){
		if ($vic_d18a && $vic_d18b){
			if (($vic_d18a == $d18a)&&($vic_d18b == $d18b)) {
				$d18_LR = 1 / $arr['d18'][$d18c]*(2*$arr['d18'][$d18a] + 2*$arr['d18'][$d18b] + $arr['d18'][$d18c]);
			}elseif (($vic_d18a == $d18b)&&($vic_d18b == $d18c)){
				$d18_LR = 1 / $arr['d18'][$d18a]*(2*$arr['d18'][$d18b] + 2*$arr['d18'][$d18c] + $arr['d18'][$d18a]);
			}elseif (($vic_d18a == $d18c)&&($vic_d18b == $d18a)){
				$d18_LR = 1 / $arr['d18'][$d18b]*(2*$arr['d18'][$d18c] + 2*$arr['d18'][$d18a] + $arr['d18'][$d18b]);
			}
		}
	}elseif ($vic_d18a){
			if ($vic_d18a != ($sus_d18a && $sus_d18b)){
				$d18_LR = 1 / 2*$arr['d18'][$sus_d18a] * $arr['d18'][$sus_d18b];
			}
	}elseif ($d18a && $d18b){
		if ($vic_d18a && $vic_d18b){
			$d18_LR = 1 / ($arr['d18'][$d18a] + $arr['d18'][$d18b])*($arr['d18'][$d18a] + $arr['d18'][$d18b]);
		}elseif ($vic_d18a) {
			if($vic_d18a == $d18a){
				$d18_LR = 1/ $arr['d18'][$d18b]*(2*$arr['d18'][$d18a]+$arr['d18'][$d18b]);
			}elseif ($vic_d18a == $d18b){
				$d18_LR = 1/ $arr['d18'][$d18a]*(2*$arr['d18'][$d18a]+$arr['d18'][$d18b]);
			}
		}
	}
	elseif ($d18a && $vic_d18a && $sus_d18a){
		$d18_LR = 1 / $arr['d18'][$d18a] * $arr['d18'][$d18a];
	}

	// d2 �ڸ� LR ======================================================================================
	if ($d2a && $d2b && $d2c && $d2d){
		$d2_LR = 1 / (2*$arr['d2'][$sus_d2a]*$arr['d2'][$sus_d2b]);
	}
	elseif ($d2a && $d2b && $d2c){
		if ($vic_d2a && $vic_d2b){
			if (($vic_d2a == $d2a)&&($vic_d2b == $d2b)) {
				$d2_LR = 1 / $arr['d2'][$d2c]*(2*$arr['d2'][$d2a] + 2*$arr['d2'][$d2b] + $arr['d2'][$d2c]);
			}elseif (($vic_d2a == $d2b)&&($vic_d2b == $d2c)){
				$d2_LR = 1 / $arr['d2'][$d2a]*(2*$arr['d2'][$d2b] + 2*$arr['d2'][$d2c] + $arr['d2'][$d2a]);
			}elseif (($vic_d2a == $d2c)&&($vic_d2b == $d2a)){
				$d2_LR = 1 / $arr['d2'][$d2b]*(2*$arr['d2'][$d2c] + 2*$arr['d2'][$d2a] + $arr['d2'][$d2b]);
			}
		}
	}elseif ($vic_d2a){
			if ($vic_d2a != ($sus_d2a && $sus_d2b)){
				$d2_LR = 1 / 2*$arr['d2'][$sus_d2a] * $arr['d2'][$sus_d2b];
			}
	}elseif ($d2a && $d2b){
		if ($vic_d2a && $vic_d2b){
			$d2_LR = 1 / ($arr['d2'][$d2a] + $arr['d2'][$d2b])*($arr['d2'][$d2a] + $arr['d2'][$d2b]);
		}elseif ($vic_d2a) {
			if($vic_d2a == $d2a){
				$d2_LR = 1/ $arr['d2'][$d2b]*(2*$arr['d2'][$d2a]+$arr['d2'][$d2b]);
			}elseif ($vic_d2a == $d2b){
				$d2_LR = 1/ $arr['d2'][$d2a]*(2*$arr['d2'][$d2a]+$arr['d2'][$d2b]);
			}
		}
	}
	elseif ($d2a && $vic_d2a && $sus_d2a){
		$d2_LR = 1 / $arr['d2'][$d2a] * $arr['d2'][$d2a];
	}


	// d19 �ڸ� LR ======================================================================================
	if ($d19a && $d19b && $d19c && $d19d){
		$d19_LR = 1 / (2*$arr['d19'][$sus_d19a]*$arr['d19'][$sus_d19b]);
	}
	elseif ($d19a && $d19b && $d19c){
		if ($vic_d19a && $vic_d19b){
			if (($vic_d19a == $d19a)&&($vic_d19b == $d19b)) {
				$d19_LR = 1 / $arr['d19'][$d19c]*(2*$arr['d19'][$d19a] + 2*$arr['d19'][$d19b] + $arr['d19'][$d19c]);
			}elseif (($vic_d19a == $d19b)&&($vic_d19b == $d19c)){
				$d19_LR = 1 / $arr['d19'][$d19a]*(2*$arr['d19'][$d19b] + 2*$arr['d19'][$d19c] + $arr['d19'][$d19a]);
			}elseif (($vic_d19a == $d19c)&&($vic_d19b == $d19a)){
				$d19_LR = 1 / $arr['d19'][$d19b]*(2*$arr['d19'][$d19c] + 2*$arr['d19'][$d19a] + $arr['d19'][$d19b]);
			}
		}
	}elseif ($vic_d19a){
			if ($vic_d19a != ($sus_d19a && $sus_d19b)){
				$d19_LR = 1 / 2*$arr['d19'][$sus_d19a] * $arr['d19'][$sus_d19b];
			}
	}elseif ($d19a && $d19b){
		if ($vic_d19a && $vic_d19b){
			$d19_LR = 1 / ($arr['d19'][$d19a] + $arr['d19'][$d19b])*($arr['d19'][$d19a] + $arr['d19'][$d19b]);
		}elseif ($vic_d19a) {
			if($vic_d19a == $d19a){
				$d19_LR = 1/ $arr['d19'][$d19b]*(2*$arr['d19'][$d19a]+$arr['d19'][$d19b]);
			}elseif ($vic_d19a == $d19b){
				$d19_LR = 1/ $arr['d19'][$d19a]*(2*$arr['d19'][$d19a]+$arr['d19'][$d19b]);
			}
		}
	}
	elseif ($d19a && $vic_d19a && $sus_d19a){
		$d19_LR = 1 / $arr['d19'][$d19a] * $arr['d19'][$d19a];
	}
?>
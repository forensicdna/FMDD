<html>
<head>
	<title> FMDD </title>
	<style type="text/css">
	body {
		font-family : sans-serif;
	/*	font-size : 10 px; */
	}
	table {
		border : thin solid black;
		border-collapse : collapse; 
		font-family : sans-serif;
		font-size : 12 px;
		border-spacing: 0px;
		table-layout: fixed; 
	}
	th {
		border: 1px solid gray;
		text-align: center;
		vertical-align: center;
		padding-right: 1px;
		height: auto;
		background-color: #fcba7a;
	}
	td {
		border: 1px solid gray;
		text-align: center;
		vertical-align: center;
		padding-bottom: 15px;
		word-break: break-all;
		height: auto;
	}

	tr {
		text-align: center;
		vertical-align: center;
		height: 30px;
	}
	
	</style>
</head>
<body>

<?php
	require('dbConnect.php');
	require('head.php');
	require('ystrVar.php');
?>
<div id="pagecell1"> 
  <!--pagecell1--> 
	  <img alt="" src="tl_curve_white.gif" height="6" width="6" id="tl" /> 
	  <img alt="" src="tr_curve_white.gif" height="6" width="6" id="tr" /> 
	  <div> 
		&nbsp;
	  </div> 
	  <div id="pageName"> 
		<h2>File Upload Results </h2> 
	  </div> 
	  <input type="button" value="Go Submit" title="Go back to Search Page" onclick="window.location='submit.php'">
	  <div class="story">
<?php
//Y-filer �Է½� ���
	if ($YstrKit == 1){
		if (!$ystrdna && !$y456 && !$y389i && !$y390 && !$y389ii && !$y458 && !$y19 && !$y385 && !$y393 && !$y391 && !$y439 && !$y635 && !$y392 && !$ygata && !$y437 && !$y438 && !$y448 && !$comment) {
			echo "No profiles. Go Back and try again";
		}
	else
	$sql = "insert into ystr (DNA,DYS456, DYS389I, DYS390, DYS389II, DYS458, DYS19, DYS385, DYS393, DYS391, DYS439, DYS635, DYS392, YGATAH4, DYS437, DYS438, DYS448, kit, comment) values ('".$ystrdna."','".$y456."','".$y389i."','".$y390."','".$y389ii."','".$y458."','".$y19."','".$y385."','".$y393."','".$y391."','".$y439."','".$y635."','".$y392."','".$ygata."','".$y437."','".$y438."','".$y448."','Y-Filer','".$comment."')";	

	$result = mysql_query($sql);
	if ($result) {
		echo '<p>';
		echo '<b>'.' Your profile ,<em>'.$ystrdna.'</em>, is inserted into database.';
		echo '<table width="450px">';
		echo '<tr> <th> DNA </th> <td>'.$ystrdna.'</td></tr>';
		echo '<tr> <th> DYS456 </th> <td>'.$y456.'</td></tr>';
		echo '<tr> <th> DYS389I </th> <td>'.$y389i.'</td></tr>';
		echo '<tr> <th> DYS390 </th> <td>'.$y390.'</td></tr>';
		echo '<tr> <th> DYS389II </th> <td>'.$y389ii.'</td></tr>';
		echo '<tr> <th> DYS458 </th> <td>'.$y458.'</td></tr>';
		echo '<tr> <th> DYS19 </th> <td>'.$y19.'</td></tr>';
		echo '<tr> <th> DYS385 </th> <td>'.$y385.'</td></tr>';
		echo '<tr> <th> DYS393 </th> <td>'.$y393.'</td></tr>';
		echo '<tr> <th> DYS391 </th> <td>'.$y391.'</td></tr>';
		echo '<tr> <th> DYS439 </th> <td>'.$y439.'</td></tr>';
		echo '<tr> <th> DYS635 </th> <td>'.$y635.'</td></tr>';
		echo '<tr> <th> DYS392 </th> <td>'.$y392.'</td></tr>';
		echo '<tr> <th> Y_GATA_H4 </th> <td>'.$ygata.'</td></tr>';
		echo '<tr> <th> DYS437 </th> <td>'.$y437.'</td></tr>';
		echo '<tr> <th> DYS438 </th> <td>'.$y438.'</td></tr>';
		echo '<tr> <th> DYS448 </th> <td>'.$y448.'</td></tr>';
		echo '<tr> <th> Kit </th> <td> Y-Filer</td></tr>';
		echo '<tr> <th> Comment </th> <td>'.$comment.'</td></tr>';
		echo '</table>';
		}

	}
 
 //Y23 �Է½� ���
	if ($YstrKit == 2){
		if (!$y23_ystrdna && !$y23_y576 && !$y23_y481&& !$y23_y549 && !$y23_y533 && !$y23_y570 && !$y23_y456 && !$y23_y389i && !$y23_y390 && !$y23_y389ii && !$y23_y458 && !$y23_y19 && !$y23_y385 && !$y23_y393 && !$y23_y391 && !$y23_y439 && !$y23_y635 && !$y23_y392 && !$y23_ygata && !$y23_y437 && !$y23_y438 && !$y23_y448 && !$y23_y643 && !$y23_comment ) {
			echo "No profiles. Go Back and try again";
		}
	else
	$sql = "insert into ystr (DNA,DYS576, DYS389I, DYS448, DYS389II, DYS19, DYS391, DYS481, DYS549, DYS533, DYS438, DYS437, DYS570, DYS635, DYS390, DYS439, DYS392, DYS643, DYS393, DYS458, DYS385, DYS456, YGATAH4, kit, comment) values ('".$y23_ystrdna."','".$y23_y576."','".$y23_y389i."','".$y23_y448."','".$y23_y389ii."','".$y23_y19."','".$y23_y391."','".$y23_y481."','".$y23_y549."','".$y23_y533."','".$y23_y438."','".$y23_y437."','".$y23_y570."','".$y23_y635."','".$y23_y390."','".$y23_y439."','".$y23_y392."','".$y23_y643."','".$y23_y393."','".$y23_y458."','".$y23_y385."','".$y23_y456."','".$y23_ygata."','Powerplex Y23','".$y23_comment."')";	

	$result1 = mysql_query($sql);
	if ($result1) {
		echo '<p>';
		echo '<b>'.' your profile ,<em>'.$y23_ystrdna.'</em>, is inserted into database.';
		echo '<table width="450px">';
		echo '<tr> <th> DNA </th> <td>'.$y23_ystrdna.'</td></tr>';
		echo '<tr> <th> DYS576 </th> <td>'.$y23_y576.'</td></tr>';
		echo '<tr> <th> DYS389I </th> <td>'.$y23_y389i.'</td></tr>';
		echo '<tr> <th> DYS448 </th> <td>'.$y23_y448.'</td></tr>';
		echo '<tr> <th> DYS389II </th> <td>'.$y23_y389ii.'</td></tr>';
		echo '<tr> <th> DYS19 </th> <td>'.$y23_y19.'</td></tr>';
		echo '<tr> <th> DYS391 </th> <td>'.$y23_y391.'</td></tr>';
		echo '<tr> <th> DYS481 </th> <td>'.$y23_y481.'</td></tr>';
		echo '<tr> <th> DYS549 </th> <td>'.$y23_y549.'</td></tr>';
		echo '<tr> <th> DYS533 </th> <td>'.$y23_y533.'</td></tr>';
		echo '<tr> <th> DYS438 </th> <td>'.$y23_y438.'</td></tr>';
		echo '<tr> <th> DYS437 </th> <td>'.$y23_y437.'</td></tr>';
		echo '<tr> <th> DYS570 </th> <td>'.$y23_y570.'</td></tr>';
		echo '<tr> <th> DYS635 </th> <td>'.$y23_y635.'</td></tr>';
		echo '<tr> <th> DYS390 </th> <td>'.$y23_y390.'</td></tr>';
		echo '<tr> <th> DYS439 </th> <td>'.$y23_y439.'</td></tr>';
		echo '<tr> <th> DYS392 </th> <td>'.$y23_y392.'</td></tr>';
		echo '<tr> <th> DYS643 </th> <td>'.$y23_y643.'</td></tr>';
		echo '<tr> <th> DYS393 </th> <td>'.$y23_y393.'</td></tr>';
		echo '<tr> <th> DYS458 </th> <td>'.$y23_y458.'</td></tr>';
		echo '<tr> <th> DYS385 </th> <td>'.$y23_y385.'</td></tr>';
		echo '<tr> <th> DYS456 </th> <td>'.$y23_y456.'</td></tr>';
		echo '<tr> <th> Y_GATA_H4 </th> <td>'.$y23_ygata.'</td></tr>';
		echo '<tr> <th> Kit </th> <td> Powerplex Y23</td></tr>';
		echo '<tr> <th> Comment </th> <td>'.$y23_comment.'</td></tr>';
		echo '</table>';
		}
	}
 ?>
	</div>
	<div>
		  <p>&nbsp;</p>
		  <p>&nbsp;</p>
		  <p>&nbsp;</p>
		  <p>&nbsp;</p>
	</div>
<?php
	require ('footer.php');
?>
</div>
	
</body>
</html>
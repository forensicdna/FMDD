<html>
<head>
	<title> FMDD </title>
	<style type="text/css">
	body {
		font-family : sans-serif;
	/*	font-size : 10 px; */
	}
	table {
		border : thin solid black;
		border-collapse : collapse; 
		font-family : sans-serif;
		font-size : 11 px;
		border-spacing: 0px;
		table-layout: fixed; 
	}
	th {
		border: 1px solid gray;
		text-align: center;
		vertical-align: center;
		padding-right: 1px;
		height: auto;
		background-color: #fcba7a;
	}
	td {
		border: 1px solid gray;
		text-align: center;
		vertical-align: center;
		padding-bottom: 15px;
		word-break: break-all;
		height: auto;
	}
	tr {
		text-align: center;
		vertical-align: center;
		height: 30px;
	}
	</style>
</head>
<body>

<?php
	require('dbConnect.php');
	require('head.php');
	require('uploadVar.php');
?>
<div id="pagecell1"> 
  <!--pagecell1--> 
	  <img alt="" src="tl_curve_white.gif" height="6" width="6" id="tl" /> 
	  <img alt="" src="tr_curve_white.gif" height="6" width="6" id="tr" /> 
	  <div> 
		&nbsp;
	  </div> 
	  <div id="pageName"> 
		<h2>File Upload Results </h2> 
	  </div> 
	  <input type="button" value="Go Submit" title="Go back to Search Page" onclick="window.location='submit.php'">
	  <div class="story">
<?php
	if (!$dna && !$amelo && !$th01 && !$tpox && !$csf1po && !$d3 && !$vwa && !$fga && !$d5 && !$d13 && !$d7 && !$d16 && !$d8 && !$d21 && !$d18 && !$d2 && !$d19 && !$penE && !$penD) {
		echo "No profiles. Go Back and try again";
	}
	else

	$sql = "insert into profile (DNA_no,amel, th01,tpox,csf1po,d3,vwa,fga,d5,d13,d7,d16,d8,d21,d18,d2,d19,pentae, pentad,inputDate) values ('".$dna."','".$amelo."','".$th01."','".$tpox."','".$csf1po."','".$d3."','".$vwa."','".$fga."','".$d5."','".$d13."','".$d7."','".$d16."','".$d8."','".$d21."','".$d18."','".$d2."','".$d19."','".$penE."','".$penD."','".date("Y-m-d")."')";	

	$result = mysql_query($sql);
?>
<?php 
	if ($result) {
		echo '<p>';
		echo '<b>'.' Your profile ,<em>'.$dna.'</em>, is inserted into database.';
		echo '<table width="450px">';
		echo '<tr> <th> DNA </th> <td>'.$dna.'</td></tr>';
		echo '<tr> <th> Amelogenin </th> <td>'.$amelo.'</td></tr>';
		echo '<tr> <th> TH01 </th> <td>'.$th01.'</td></tr>';
		echo '<tr> <th> TPOX </th> <td>'.$tpox.'</td></tr>';
		echo '<tr> <th> CSF1PO </th> <td>'.$csf1po.'</td></tr>';
		echo '<tr> <th> D3S1358 </th> <td>'.$d3.'</td></tr>';
		echo '<tr> <th> vWA </th> <td>'.$vwa.'</td></tr>';
		echo '<tr> <th> FGA </th> <td>'.$fga.'</td></tr>';
		echo '<tr> <th> D5S818 </th> <td>'.$d5.'</td></tr>';
		echo '<tr> <th> D13S317 </th> <td>'.$d13.'</td></tr>';
		echo '<tr> <th> D7S820 </th> <td>'.$d7.'</td></tr>';
		echo '<tr> <th> D16S539 </th> <td>'.$d16.'</td></tr>';
		echo '<tr> <th> D8S1179 </th> <td>'.$d8.'</td></tr>';
		echo '<tr> <th> D21S11 </th> <td>'.$d21.'</td></tr>';
		echo '<tr> <th> D18S51 </th> <td>'.$d18.'</td></tr>';
		echo '<tr> <th> D2S1338 </th> <td>'.$d2.'</td></tr>';
		echo '<tr> <th> D19S433 </th> <td>'.$d19.'</td></tr>';
		echo '<tr> <th> PentaE </th> <td>'.$penE.'</td></tr>';
		echo '<tr> <th> PentaD </th> <td>'.$penD.'</td></tr>';
		echo '</table>';
		}
 ?>
	</div>
	<div>
		  <p>&nbsp;</p>
		  <p>&nbsp;</p>
		  <p>&nbsp;</p>
		  <p>&nbsp;</p>
	</div>
<?php
	require ('footer.php');
?>
</div>
	
</body>
</html>
		 

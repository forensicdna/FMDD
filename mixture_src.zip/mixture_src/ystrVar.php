<?php
$ystrdna=$_POST['ystrdna'];
$y23_ystrdna=$_POST['y23_ystrdna'];
$YstrKit=$_POST['YstrKit'];
$comment=$_POST['comment'];
$y23_comment=$_POST['y23_comment'];
// y-filer ����

$y456=$_POST['y456'];
$y389i=$_POST['y389i'];
$y390=$_POST['y390'];
$y389ii=$_POST['y389ii'];
$y458=$_POST['y458'];
$y19=$_POST['y19'];
$y385=$_POST['y385'];
$y393=$_POST['y393'];
$y391=$_POST['y391'];
$y439=$_POST['y439'];
$y635=$_POST['y635'];
$y392=$_POST['y392'];
$ygata=$_POST['ygata'];
$y437=$_POST['y437'];
$y438=$_POST['y438'];
$y448=$_POST['y448'];
$comment=$_POST['comment'];

//y23 ����
$y23_y576=$_POST['y23_y576'];
$y23_y389i=$_POST['y23_y389i'];
$y23_y448=$_POST['y23_y448'];
$y23_y389ii=$_POST['y23_y389ii'];
$y23_y19=$_POST['y23_y19'];
$y23_y391=$_POST['y23_y391'];
$y23_y481=$_POST['y23_y481'];
$y23_y549=$_POST['y23_y549'];
$y23_y533=$_POST['y23_y533'];
$y23_y438=$_POST['y23_y438'];
$y23_y437=$_POST['y23_y437'];
$y23_y570=$_POST['y23_y570'];
$y23_y635=$_POST['y23_y635'];
$y23_y390=$_POST['y23_y390'];
$y23_y439=$_POST['y23_y439'];
$y23_y392=$_POST['y23_y392'];
$y23_y643=$_POST['y23_y643'];
$y23_y393=$_POST['y23_y393'];
$y23_y458=$_POST['y23_y458'];
$y23_y385=$_POST['y23_y385'];
$y23_y456=$_POST['y23_y456'];
$y23_ygata=$_POST['y23_ygata'];
$y23_comment=$_POST['y23_comment'];


// y-filer ����
$ystrdna=trim($ystrdna);
$y456=trim($y456);
$y389i=trim($y389i);
$y390=trim($y390);
$y389ii=trim($y389ii);
$y458=trim($y458);
$y19=trim($y19);
$y385=trim($y385);
$y393=trim($y393);
$y391=trim($y391);
$y439=trim($y439);
$y635=trim($y635);
$y392=trim($y392);
$ygata=trim($ygata);
$y437=trim($y437);
$y438=trim($y438);
$y448=trim($y448);
$comment=trim($comment);
//y23 ����
$y23_y576=trim($y23_y576);
$y23_y389i=trim($y23_y389i);
$y23_y448=trim($y23_y448);
$y23_y389ii=trim($y23_y389ii);
$y23_y19=trim($y23_y19);
$y23_y391=trim($y23_y391);
$y23_y481=trim($y23_y481);
$y23_y549=trim($y23_y549);
$y23_y533=trim($y23_y533);
$y23_y438=trim($y23_y438);
$y23_y437=trim($y23_y437);
$y23_y570=trim($y23_y570);
$y23_y635=trim($y23_y635);
$y23_y390=trim($y23_y390);
$y23_y439=trim($y23_y439);
$y23_y392=trim($y23_y392);
$y23_y643=trim($y23_y643);
$y23_y393=trim($y23_y393);
$y23_y458=trim($y23_y458);
$y23_y385=trim($y23_y385);
$y23_y456=trim($y23_y456);
$y23_ygata=trim($y23_ygata);
$y23_comment=trim($y23_comment);

$ystrdna=trim($ystrdna);
$y23_ystrdna=trim($y23_ystrdna);

if (!get_magic_quotes_gpc()){
	$ystrdna=addslashes($ystrdna);
	$y23_ystrdna=addslashes($y23_ystrdna);
	$comment=addslashes($comment);
	$y23_comment=addslashes($y23_comment);

}
?>








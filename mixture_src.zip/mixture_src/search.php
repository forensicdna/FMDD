<html>
<head>
	<title> FMDD </title>
	<style type="text/css">
	body {
		font-family : sans-serif;
		
	/*	font-size : 10 px; */
	}
	table {
		border : thin solid black;
		border-collapse : collapse; 
		font-family : sans-serif;
		font-size : 12 px;
		color: white;
		border-spacing: 0px;
		table-layout: fixed; 
	}
	th {
		border: 1px solid gray;
		text-align: center;
		vertical-align: top;
		padding-right: 10px;
		background-color: #3c5087;
	}
	td {
		border: 1px solid gray;
		vertical-align: top;
		padding-bottom: 5px;
		padding-top: 5px;
	}

	
	</style>
</head>
<body>

<?php 
require('head.php');
?>

<div id="pagecell1"> 
  <!--pagecell1--> 
	  <img alt="" src="tl_curve_white.gif" height="6" width="6" id="tl" /> 
	  <img alt="" src="tr_curve_white.gif" height="6" width="6" id="tr" /> 
	  
	  <div id="pageName"> 
	    &nbsp;
		<h2>Reference Search </h2> 
	  </div> 
	  <div id="col2"> 
		<div class="feature"> 
			<h3>Enter the reference DNA profile </h3> (Input your profile. e.g. heterozygote : 7,9 | homozygote : 9 (9-9))
				<form method="POST" action="searchResult.php">
				<table align="center">
					<tr>
						<th> Amelogenin </th>
						<th> TH01 </th>
						<th> TPOX </th>
						<th> CSF1PO </th>
						<th> D3S1358 </th>
						<th> vWA </th>
						<th> FGA </th>
						<th> D5S818 </th>
						<th> D13S317 </th>
					</tr>
					<tr>
						<td align="center"> <input type="text" name="amelo_a" size='3'> <input type="text" name="amelo_b" size='3'></td>
						<td align="center"> <input type="text" name="th01_a" size='3'> <input type="text" name="th01_b" size='3'></td>
						<td align="center"> <input type="text" name="tpox_a" size='3'> <input type="text" name="tpox_b" size='3'></td>
						<td align="center"> <input type="text" name="csf1po_a" size='3'> <input type="text" name="csf1po_b" size='3'></td>
						<td align="center"> <input type="text" name="d3_a" size='3'> <input type="text" name="d3_b" size='3'></td>
						<td align="center"> <input type="text" name="vwa_a" size='3'> <input type="text" name="vwa_b" size='3'></td>
						<td align="center"> <input type="text" name="fga_a" size='3'> <input type="text" name="fga_b" size='3'></td>
						<td align="center"> <input type="text" name="d5_a" size='3'> <input type="text" name="d5_b" size='3'></td>
						<td align="center"> <input type="text" name="d13_a" size='3'> <input type="text" name="d13_b" size='3'></td>
					</tr>
					<tr>
						<th> D7S820 </th>
						<th> D16S539 </th>
						<th> D8S1179 </th>
						<th> D21S11 </th>
						<th> D18S51 </th>
						<th> D2S1338 </th>
						<th> D19S433 </th>
						<th> Penta E </th>
						<th> Penta D </th>
					</tr>
					<tr>
						<td align="center"> <input type="text" name="d7_a" size='3'> <input type="text" name="d7_b" size='3'></td>
						<td align="center"> <input type="text" name="d16_a" size='3'> <input type="text" name="d16_b" size='3'></td>
						<td align="center"> <input type="text" name="d8_a" size='3'> <input type="text" name="d8_b" size='3'></td>
						<td align="center"> <input type="text" name="d21_a" size='3'> <input type="text" name="d21_b" size='3'></td>
						<td align="center"> <input type="text" name="d18_a" size='3'> <input type="text" name="d18_b" size='3'></td>
						<td align="center"> <input type="text" name="d2_a" size='3'> <input type="text" name="d2_b" size='3'></td>
						<td align="center"> <input type="text" name="d19_a" size='3'> <input type="text" name="d19_b" size='3'></td>
						<td align="center"> <input type="text" name="penE_a" size='3'> <input type="text" name="penE_b" size='3'></td>
						<td align="center"> <input type="text" name="penD_a" size='3'> <input type="text" name="penD_b" size='3'></td>
					</tr>
					<tr>
						<td colspan= '9'><input type="submit" value="Search and Calculate"></td>
					</tr>
				</table>
				</form>
			<hr>
		</div> 
		<div class="story"> 
		 <h3>Search from CSV file </h3> (Please upload .csv file)
		    <a href = "search_sample.txt" title="sample format"> Sample .CSV File </a>
			<a href = "./sample.xls">
				<img src = "image/excelimg.jpg" alt="download a file" width="20" height="20" border="0">
			</a>
			<form method="POST" action="fileSearchResult.php" enctype="multipart/form-data">
			<p><input type="file" name="FileName">  <input type="submit" value="Search"></p>
		    </form>
		 <h3>Search from XML file </h3> (Please upload CODIS Export file)
		    <a href = "xmlSample.xml" title="sample format"> Sample .XML File </a>
			<form method="POST" action="xmlSearchResult.php" enctype="multipart/form-data">
			<p><input type="file" name="xmlFileName">  <input type="submit" value="Search"></p>	
			</form>
		
	</div> 
	  <!--end col2 --> 
		<?php
			require ('left.php')
		?>
	  <!--end col1 div --> 
		<?php
			require ('footer.php')
		?>
	</div> 
	<!--end pagecell1--> 
	<br /> 
</body>
</html>

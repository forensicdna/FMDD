<?php
	function D3all($D3S_a,$D3S_b,$D3S_c,$D3S_d){
		$sql = " ((D3S1358_1='$D3S_a' AND D3S1358_2='$D3S_b') or
				 (D3S1358_1='$D3S_a' AND D3S1358_2='$D3S_c') or
				 (D3S1358_1='$D3S_a' AND D3S1358_2='$D3S_d') or
				 (D3S1358_1='$D3S_b' AND D3S1358_2='$D3S_c') or 
				 (D3S1358_1='$D3S_b' AND D3S1358_2='$D3S_d') or
				 (D3S1358_1='$D3S_c' AND D3S1358_2='$D3S_d'))";
		return($sql);
	}
	
	function D3three($D3S_a,$D3S_b,$D3S_c){
		$sql = " ((D3S1358_1='$D3S_a' AND D3S1358_2='$D3S_b') or
				 (D3S1358_1='$D3S_a' AND D3S1358_2='$D3S_c') or
				 (D3S1358_1='$D3S_b' AND D3S1358_2='$D3S_c') or 
				 (D3S1358_1='$D3S_a' AND D3S1358_2='$D3S_a') or
				 (D3S1358_1='$D3S_b' AND D3S1358_2='$D3S_b') or
				 (D3S1358_1='$D3S_c' AND D3S1358_2='$D3S_c'))";
		return($sql);
	}
	
	function D3two($D3S_a,$D3S_b){
		$sql = " ((D3S1358_1='$D3S_a' AND D3S1358_2='$D3S_b') or
				 (D3S1358_1='$D3S_a' AND D3S1358_2='$D3S_a') or
				 (D3S1358_1='$D3S_b' AND D3S1358_2='$D3S_b'))";
    	return($sql);
	}

	function D3one($D3S_a){
		$sql = " ((D3S1358_1='$D3S_a' AND D3S1358_2='$D3S_a'))";
		return($sql);
	}
?>
<?php
	function D7all($D7S_a,$D7S_b,$D7S_c,$D7S_d){
		$sql = " ((D7S820_1='$D7S_a' AND D7S820_2='$D7S_b') or
				 (D7S820_1='$D7S_a' AND D7S820_2='$D7S_c') or
				 (D7S820_1='$D7S_a' AND D7S820_2='$D7S_d') or
				 (D7S820_1='$D7S_b' AND D7S820_2='$D7S_c') or 
				 (D7S820_1='$D7S_b' AND D7S820_2='$D7S_d') or
				 (D7S820_1='$D7S_c' AND D7S820_2='$D7S_d'))";
		return($sql);
	}
	
	function D7three($D7S_a,$D7S_b,$D7S_c){
		$sql = " ((D7S820_1='$D7S_a' AND D7S820_2='$D7S_b') or
				 (D7S820_1='$D7S_a' AND D7S820_2='$D7S_c') or
				 (D7S820_1='$D7S_b' AND D7S820_2='$D7S_c') or 
				 (D7S820_1='$D7S_a' AND D7S820_2='$D7S_a') or
				 (D7S820_1='$D7S_b' AND D7S820_2='$D7S_b') or
				 (D7S820_1='$D7S_c' AND D7S820_2='$D7S_c'))";
		return($sql);
	}
	
	function D7two($D7S_a,$D7S_b){
		$sql = " ((D7S820_1='$D7S_a' AND D7S820_2='$D7S_b') or
				 (D7S820_1='$D7S_a' AND D7S820_2='$D7S_a') or
				 (D7S820_1='$D7S_b' AND D7S820_2='$D7S_b'))";
    	return($sql);
	}

	function D7one($D7S_a){
		$sql = " ((D7S820_1='$D7S_a' AND D7S820_2='$D7S_a'))";
		return($sql);
	}
?>
<?php
	function D8all($D8S_a,$D8S_b,$D8S_c,$D8S_d){
		$sql = " ((D8S1179_1='$D8S_a' AND D8S1179_2='$D8S_b') or
				 (D8S1179_1='$D8S_a' AND D8S1179_2='$D8S_c') or
				 (D8S1179_1='$D8S_a' AND D8S1179_2='$D8S_d') or
				 (D8S1179_1='$D8S_b' AND D8S1179_2='$D8S_c') or 
				 (D8S1179_1='$D8S_b' AND D8S1179_2='$D8S_d') or
				 (D8S1179_1='$D8S_c' AND D8S1179_2='$D8S_d'))";
		return($sql);
	}
	
	function D8three($D8S_a,$D8S_b,$D8S_c){
		$sql = " ((D8S1179_1='$D8S_a' AND D8S1179_2='$D8S_b') or
				 (D8S1179_1='$D8S_a' AND D8S1179_2='$D8S_c') or
				 (D8S1179_1='$D8S_b' AND D8S1179_2='$D8S_c') or 
				 (D8S1179_1='$D8S_a' AND D8S1179_2='$D8S_a') or
				 (D8S1179_1='$D8S_b' AND D8S1179_2='$D8S_b') or
				 (D8S1179_1='$D8S_c' AND D8S1179_2='$D8S_c'))";
		return($sql);
	}
	
	function D8two($D8S_a,$D8S_b){
		$sql = " ((D8S1179_1='$D8S_a' AND D8S1179_2='$D8S_b') or
				 (D8S1179_1='$D8S_a' AND D8S1179_2='$D8S_a') or
				 (D8S1179_1='$D8S_b' AND D8S1179_2='$D8S_b'))";
    	return($sql);
	}

	function D8one($D8S_a){
		$sql = " ((D8S1179_1='$D8S_a' AND D8S1179_2='$D8S_a'))";
		return($sql);
	}
?>

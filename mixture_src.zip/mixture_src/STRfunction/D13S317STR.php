<?php
	function D13all($D13S_a,$D13S_b,$D13S_c,$D13S_d){
		$sql = " ((D13S317_1='$D13S_a' AND D13S317_2='$D13S_b') or
				 (D13S317_1='$D13S_a' AND D13S317_2='$D13S_c') or
				 (D13S317_1='$D13S_a' AND D13S317_2='$D13S_d') or
				 (D13S317_1='$D13S_b' AND D13S317_2='$D13S_c') or 
				 (D13S317_1='$D13S_b' AND D13S317_2='$D13S_d') or
				 (D13S317_1='$D13S_c' AND D13S317_2='$D13S_d'))";
		return($sql);
	}
	
	function D13three($D13S_a,$D13S_b,$D13S_c){
		$sql = " ((D13S317_1='$D13S_a' AND D13S317_2='$D13S_b') or
				 (D13S317_1='$D13S_a' AND D13S317_2='$D13S_c') or
				 (D13S317_1='$D13S_b' AND D13S317_2='$D13S_c') or 
				 (D13S317_1='$D13S_a' AND D13S317_2='$D13S_a') or
				 (D13S317_1='$D13S_b' AND D13S317_2='$D13S_b') or
				 (D13S317_1='$D13S_c' AND D13S317_2='$D13S_c'))";
		return($sql);
	}
	
	function D13two($D13S_a,$D13S_b){
		$sql = " ((D13S317_1='$D13S_a' AND D13S317_2='$D13S_b') or
				 (D13S317_1='$D13S_a' AND D13S317_2='$D13S_a') or
				 (D13S317_1='$D13S_b' AND D13S317_2='$D13S_b'))";
    	return($sql);
	}

	function D13one($D13S_a){
		$sql = " ((D13S317_1='$D13S_a' AND D13S317_2='$D13S_a'))";
		return($sql);
	}
?>
<?php
	function D21all($D21S_a,$D21S_b,$D21S_c,$D21S_d){
		$sql = " ((D21S11_1='$D21S_a' AND D21S11_2='$D21S_b') or
				 (D21S11_1='$D21S_a' AND D21S11_2='$D21S_c') or
				 (D21S11_1='$D21S_a' AND D21S11_2='$D21S_d') or
				 (D21S11_1='$D21S_b' AND D21S11_2='$D21S_c') or 
				 (D21S11_1='$D21S_b' AND D21S11_2='$D21S_d') or
				 (D21S11_1='$D21S_c' AND D21S11_2='$D21S_d'))";
		return($sql);
	}
	
	function D21three($D21S_a,$D21S_b,$D21S_c){
		$sql = " ((D21S11_1='$D21S_a' AND D21S11_2='$D21S_b') or
				 (D21S11_1='$D21S_a' AND D21S11_2='$D21S_c') or
				 (D21S11_1='$D21S_b' AND D21S11_2='$D21S_c') or 
				 (D21S11_1='$D21S_a' AND D21S11_2='$D21S_a') or
				 (D21S11_1='$D21S_b' AND D21S11_2='$D21S_b') or
				 (D21S11_1='$D21S_c' AND D21S11_2='$D21S_c'))";
		return($sql);
	}
	
	function D21two($D21S_a,$D21S_b){
		$sql = " ((D21S11_1='$D21S_a' AND D21S11_2='$D21S_b') or
				 (D21S11_1='$D21S_a' AND D21S11_2='$D21S_a') or
				 (D21S11_1='$D21S_b' AND D21S11_2='$D21S_b'))";

		return($sql);
	}

	function D21one($D21S_a){
		$sql = " ((D21S11_1='$D21S_a' AND D21S11_2='$D21S_a'))";
		return($sql);
	}
?>
<?php
	function D19all($D19S_a,$D19S_b,$D19S_c,$D19S_d){
		$sql = " ((D19S433_1='$D19S_a' AND D19S433_2='$D19S_b') or
				 (D19S433_1='$D19S_a' AND D19S433_2='$D19S_c') or
				 (D19S433_1='$D19S_a' AND D19S433_2='$D19S_d') or
				 (D19S433_1='$D19S_b' AND D19S433_2='$D19S_c') or 
				 (D19S433_1='$D19S_b' AND D19S433_2='$D19S_d') or
				 (D19S433_1='$D19S_c' AND D19S433_2='$D19S_d'))";
		return($sql);
	}
	
	function D19three($D19S_a,$D19S_b,$D19S_c){
		$sql = " ((D19S433_1='$D19S_a' AND D19S433_2='$D19S_b') or
				 (D19S433_1='$D19S_a' AND D19S433_2='$D19S_c') or
				 (D19S433_1='$D19S_b' AND D19S433_2='$D19S_c') or 
				 (D19S433_1='$D19S_a' AND D19S433_2='$D19S_a') or
				 (D19S433_1='$D19S_b' AND D19S433_2='$D19S_b') or
				 (D19S433_1='$D19S_c' AND D19S433_2='$D19S_c'))";
		return($sql);
	}
	
	function D19two($D19S_a,$D19S_b){
		$sql = " ((D19S433_1='$D19S_a' AND D19S433_2='$D19S_b') or
				 (D19S433_1='$D19S_a' AND D19S433_2='$D19S_a') or
				 (D19S433_1='$D19S_b' AND D19S433_2='$D19S_b'))";
    	return($sql);
	}

	function D19one($D19S_a){
		$sql = " ((D19S433_1='$D19S_a' AND D19S433_2='$D19S_a'))";
		return($sql);
	}
?>
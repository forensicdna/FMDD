<?php
	function FGAall($FGA_a,$FGA_b,$FGA_c,$FGA_d){
		$sql = " ((FGA_1='$FGA_a' AND FGA_2='$FGA_b') or
				 (FGA_1='$FGA_a' AND FGA_2='$FGA_c') or
				 (FGA_1='$FGA_a' AND FGA_2='$FGA_d') or
				 (FGA_1='$FGA_b' AND FGA_2='$FGA_c') or 
				 (FGA_1='$FGA_b' AND FGA_2='$FGA_d') or
				 (FGA_1='$FGA_c' AND FGA_2='$FGA_d'))";
		return($sql);
	}
	
	function FGAthree($FGA_a,$FGA_b,$FGA_c){
		$sql = " ((FGA_1='$FGA_a' AND FGA_2='$FGA_b') or
				 (FGA_1='$FGA_a' AND FGA_2='$FGA_c') or
				 (FGA_1='$FGA_b' AND FGA_2='$FGA_c') or 
				 (FGA_1='$FGA_a' AND FGA_2='$FGA_a') or
				 (FGA_1='$FGA_b' AND FGA_2='$FGA_b') or
				 (FGA_1='$FGA_c' AND FGA_2='$FGA_c'))";
		return($sql);
	}
	
	function FGAtwo($FGA_a,$FGA_b){
		$sql = " ((FGA_1='$FGA_a' AND FGA_2='$FGA_b') or
				 (FGA_1='$FGA_a' AND FGA_2='$FGA_a') or
				 (FGA_1='$FGA_b' AND FGA_2='$FGA_b'))";
    	return($sql);
	}

	function FGAone($FGA_a){
		$sql = " ((FGA_1='$FGA_a' AND FGA_2='$FGA_a'))";
		return($sql);
	}
?>
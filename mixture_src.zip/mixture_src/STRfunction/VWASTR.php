<?php
	function vWAall($vWA_a,$vWA_b,$vWA_c,$vWA_d){
		$sql = " ((VWA_1='$vWA_a' AND VWA_2='$vWA_b') or
				 (VWA_1='$vWA_a' AND VWA_2='$vWA_c') or
				 (VWA_1='$vWA_a' AND VWA_2='$vWA_d') or
				 (VWA_1='$vWA_b' AND VWA_2='$vWA_c') or 
				 (VWA_1='$vWA_b' AND VWA_2='$vWA_d') or
				 (VWA_1='$vWA_c' AND VWA_2='$vWA_d'))";
		return($sql);
	}
	
	function vWAthree($vWA_a,$vWA_b,$vWA_c){
		$sql = " ((VWA_1='$vWA_a' AND VWA_2='$vWA_b') or
				 (VWA_1='$vWA_a' AND VWA_2='$vWA_c') or
				 (VWA_1='$vWA_b' AND VWA_2='$vWA_c') or 
				 (VWA_1='$vWA_a' AND VWA_2='$vWA_a') or
				 (VWA_1='$vWA_b' AND VWA_2='$vWA_b') or
				 (VWA_1='$vWA_c' AND VWA_2='$vWA_c'))";
		return($sql);
	}
	
	function vWAtwo($vWA_a,$vWA_b){
		$sql = " ((VWA_1='$vWA_a' AND VWA_2='$vWA_b') or
				 (VWA_1='$vWA_a' AND VWA_2='$vWA_a') or
				 (VWA_1='$vWA_b' AND VWA_2='$vWA_b'))";
    	return($sql);
	}

	function vWAone($vWA_a){
		$sql = " ((VWA_1='$vWA_a' AND VWA_2='$vWA_a'))";
		return($sql);
	}
?>
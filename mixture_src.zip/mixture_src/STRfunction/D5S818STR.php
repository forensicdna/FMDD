<?php
	function D5all($D5S_a,$D5S_b,$D5S_c,$D5S_d){
		$sql = " ((D5S818_1='$D5S_a' AND D5S818_2='$D5S_b') or
				 (D5S818_1='$D5S_a' AND D5S818_2='$D5S_c') or
				 (D5S818_1='$D5S_a' AND D5S818_2='$D5S_d') or
				 (D5S818_1='$D5S_b' AND D5S818_2='$D5S_c') or 
				 (D5S818_1='$D5S_b' AND D5S818_2='$D5S_d') or
				 (D5S818_1='$D5S_c' AND D5S818_2='$D5S_d'))";
		return($sql);
	}
	
	function D5three($D5S_a,$D5S_b,$D5S_c){
		$sql = " ((D5S818_1='$D5S_a' AND D5S818_2='$D5S_b') or
				 (D5S818_1='$D5S_a' AND D5S818_2='$D5S_c') or
				 (D5S818_1='$D5S_b' AND D5S818_2='$D5S_c') or 
				 (D5S818_1='$D5S_a' AND D5S818_2='$D5S_a') or
				 (D5S818_1='$D5S_b' AND D5S818_2='$D5S_b') or
				 (D5S818_1='$D5S_c' AND D5S818_2='$D5S_c'))";
		return($sql);
	}
	
	function D5two($D5S_a,$D5S_b){
		$sql = " ((D5S818_1='$D5S_a' AND D5S818_2='$D5S_b') or
				 (D5S818_1='$D5S_a' AND D5S818_2='$D5S_a') or
				 (D5S818_1='$D5S_b' AND D5S818_2='$D5S_b'))";
    	return($sql);
	}

	function D5one($D5S_a){
		$sql = " ((D5S818_1='$D5S_a' AND D5S818_2='$D5S_a'))";
		return($sql);
	}
?>
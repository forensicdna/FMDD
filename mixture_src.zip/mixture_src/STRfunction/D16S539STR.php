<?php
	function D16all($D16S_a,$D16S_b,$D16S_c,$D16S_d){
		$sql = " ((D16S539_1='$D16S_a' AND D16S539_2='$D16S_b') or
				 (D16S539_1='$D16S_a' AND D16S539_2='$D16S_c') or
				 (D16S539_1='$D16S_a' AND D16S539_2='$D16S_d') or
				 (D16S539_1='$D16S_b' AND D16S539_2='$D16S_c') or 
				 (D16S539_1='$D16S_b' AND D16S539_2='$D16S_d') or
				 (D16S539_1='$D16S_c' AND D16S539_2='$D16S_d'))";
		return($sql);
	}
	
	function D16three($D16S_a,$D16S_b,$D16S_c){
		$sql = " ((D16S539_1='$D16S_a' AND D16S539_2='$D16S_b') or
				 (D16S539_1='$D16S_a' AND D16S539_2='$D16S_c') or
				 (D16S539_1='$D16S_b' AND D16S539_2='$D16S_c') or 
				 (D16S539_1='$D16S_a' AND D16S539_2='$D16S_a') or
				 (D16S539_1='$D16S_b' AND D16S539_2='$D16S_b') or
				 (D16S539_1='$D16S_c' AND D16S539_2='$D16S_c'))";
		return($sql);
	}
	
	function D16two($D16S_a,$D16S_b){
		$sql = " ((D16S539_1='$D16S_a' AND D16S539_2='$D16S_b') or
				 (D16S539_1='$D16S_a' AND D16S539_2='$D16S_a') or
				 (D16S539_1='$D16S_b' AND D16S539_2='$D16S_b'))";
    	return($sql);
	}

	function D16one($D16S_a){
		$sql = " ((D16S539_1='$D16S_a' AND D16S539_2='$D16S_a'))";
		return($sql);
	}
?>
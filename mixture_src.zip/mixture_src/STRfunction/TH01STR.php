<?php
	function TH01all($TH01_a,$TH01_b,$TH01_c,$TH01_d){
		$sql = " ((TH01_1='$TH01_a' AND TH01_2='$TH01_b') or
				 (TH01_1='$TH01_a' AND TH01_2='$TH01_c') or
				 (TH01_1='$TH01_a' AND TH01_2='$TH01_d') or
				 (TH01_1='$TH01_b' AND TH01_2='$TH01_c') or 
				 (TH01_1='$TH01_b' AND TH01_2='$TH01_d') or
				 (TH01_1='$TH01_c' AND TH01_2='$TH01_d') or
			     (TH01_1='$TH01_a' AND TH01_2='$TH01_a') or
				 (TH01_1='$TH01_b' AND TH01_2='$TH01_b') or
				 (TH01_1='$TH01_c' AND TH01_2='$TH01_c') or
				 (TH01_1='$TH01_d' AND TH01_2='$TH01_d'))";
		return($sql);
	}
	
	function TH01three($TH01_a,$TH01_b,$TH01_c){
		$sql = " ((TH01_1='$TH01_a' AND TH01_2='$TH01_b') or
				 (TH01_1='$TH01_a' AND TH01_2='$TH01_c') or
				 (TH01_1='$TH01_b' AND TH01_2='$TH01_c') or 
				 (TH01_1='$TH01_a' AND TH01_2='$TH01_a') or
				 (TH01_1='$TH01_b' AND TH01_2='$TH01_b') or
				 (TH01_1='$TH01_c' AND TH01_2='$TH01_c'))";
		return($sql);
	}
	
	function TH01two($TH01_a,$TH01_b){
		$sql = " ((TH01_1='$TH01_a' AND TH01_2='$TH01_b') or
				 (TH01_1='$TH01_a' AND TH01_2='$TH01_a') or
				 (TH01_1='$TH01_b' AND TH01_2='$TH01_b'))";
    	return($sql);
	}

	function TH01one($TH01_a){
		$sql = " ((TH01_1='$TH01_a' AND TH01_2='$TH01_a'))";
		return($sql);
	}
?>
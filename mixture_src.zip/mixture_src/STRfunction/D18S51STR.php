<?php
	function D18all($D18S_a,$D18S_b,$D18S_c,$D18S_d){
		$sql = " ((D18S51_1='$D18S_a' AND D18S51_2='$D18S_b') or
				 (D18S51_1='$D18S_a' AND D18S51_2='$D18S_c') or
				 (D18S51_1='$D18S_a' AND D18S51_2='$D18S_d') or
				 (D18S51_1='$D18S_b' AND D18S51_2='$D18S_c') or 
				 (D18S51_1='$D18S_b' AND D18S51_2='$D18S_d') or
				 (D18S51_1='$D18S_c' AND D18S51_2='$D18S_d'))";
		return($sql);
	}
	
	function D18three($D18S_a,$D18S_b,$D18S_c){
		$sql = " ((D18S51_1='$D18S_a' AND D18S51_2='$D18S_b') or
				 (D18S51_1='$D18S_a' AND D18S51_2='$D18S_c') or
				 (D18S51_1='$D18S_b' AND D18S51_2='$D18S_c') or 
				 (D18S51_1='$D18S_a' AND D18S51_2='$D18S_a') or
				 (D18S51_1='$D18S_b' AND D18S51_2='$D18S_b') or
				 (D18S51_1='$D18S_c' AND D18S51_2='$D18S_c'))";
		return($sql);
	}
	
	function D18two($D18S_a,$D18S_b){
		$sql = " ((D18S51_1='$D18S_a' AND D18S51_2='$D18S_b') or
				 (D18S51_1='$D18S_a' AND D18S51_2='$D18S_a') or
				 (D18S51_1='$D18S_b' AND D18S51_2='$D18S_b'))";
    	return($sql);
	}

	function D18one($D18S_a){
		$sql = " ((D18S51_1='$D18S_a' AND D18S51_2='$D18S_a'))";
		return($sql);
	}
?>
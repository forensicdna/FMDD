<?php
	function D2all($D2S_a,$D2S_b,$D2S_c,$D2S_d){
		$sql = " ((D2S1338_1='$D2S_a' AND D2S1338_2='$D2S_b') or
				 (D2S1338_1='$D2S_a' AND D2S1338_2='$D2S_c') or
				 (D2S1338_1='$D2S_a' AND D2S1338_2='$D2S_d') or
				 (D2S1338_1='$D2S_b' AND D2S1338_2='$D2S_c') or 
				 (D2S1338_1='$D2S_b' AND D2S1338_2='$D2S_d') or
				 (D2S1338_1='$D2S_c' AND D2S1338_2='$D2S_d'))";
		return($sql);
	}
	
	function D2three($D2S_a,$D2S_b,$D2S_c){
		$sql = " ((D2S1338_1='$D2S_a' AND D2S1338_2='$D2S_b') or
				 (D2S1338_1='$D2S_a' AND D2S1338_2='$D2S_c') or
				 (D2S1338_1='$D2S_b' AND D2S1338_2='$D2S_c') or 
				 (D2S1338_1='$D2S_a' AND D2S1338_2='$D2S_a') or
				 (D2S1338_1='$D2S_b' AND D2S1338_2='$D2S_b') or
				 (D2S1338_1='$D2S_c' AND D2S1338_2='$D2S_c'))";
		return($sql);
	}
	
	function D2two($D2S_a,$D2S_b){
		$sql = " ((D2S1338_1='$D2S_a' AND D2S1338_2='$D2S_b') or
				 (D2S1338_1='$D2S_a' AND D2S1338_2='$D2S_a') or
				 (D2S1338_1='$D2S_b' AND D2S1338_2='$D2S_b'))";
    	return($sql);
	}

	function D2one($D2S_a){
		$sql = " ((D2S1338_1='$D2S_a' AND D2S1338_2='$D2S_a'))";
		return($sql);
	}
?>
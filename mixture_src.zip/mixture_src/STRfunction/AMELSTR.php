<?php
	function AMELall($AMEL_a,$AMEL_b,$AMEL_c,$AMEL_d){
		$sql = " ((AMEL_1='$AMEL_a' AND AMEL_2='$AMEL_b') or
				 (AMEL_1='$AMEL_a' AND AMEL_2='$AMEL_c') or
				 (AMEL_1='$AMEL_a' AND AMEL_2='$AMEL_d') or
				 (AMEL_1='$AMEL_b' AND AMEL_2='$AMEL_c') or 
				 (AMEL_1='$AMEL_b' AND AMEL_2='$AMEL_d') or
				 (AMEL_1='$AMEL_c' AND AMEL_2='$AMEL_d'))";
		return($sql);
	}
	
	function AMELthree($AMEL_a,$AMEL_b,$AMEL_c){
		$sql = " ((AMEL_1='$AMEL_a' AND AMEL_2='$AMEL_b') or
				 (AMEL_1='$AMEL_a' AND AMEL_2='$AMEL_c') or
				 (AMEL_1='$AMEL_b' AND AMEL_2='$AMEL_c') or 
				 (AMEL_1='$AMEL_a' AND AMEL_2='$AMEL_a') or
				 (AMEL_1='$AMEL_b' AND AMEL_2='$AMEL_b') or
				 (AMEL_1='$AMEL_c' AND AMEL_2='$AMEL_c'))";
		return($sql);
	}
	
	function AMELtwo($AMEL_a,$AMEL_b){
		$sql = " ((AMEL_1='$AMEL_a' AND AMEL_2='$AMEL_b') or
				 (AMEL_1='$AMEL_a' AND AMEL_2='$AMEL_a') or
				 (AMEL_1='$AMEL_b' AND AMEL_2='$AMEL_b'))";
    	return($sql);
	}

	function AMELone($AMEL_a){
		$sql = " ((AMEL_1='$AMEL_a' AND AMEL_2='$AMEL_a'))";
		return($sql);
	}
?>
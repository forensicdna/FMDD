<?php
	function CSF1POall($CSF1PO_a,$CSF1PO_b,$CSF1PO_c,$CSF1PO_d){
		$sql = " ((CSF1PO_1='$CSF1PO_a' AND CSF1PO_2='$CSF1PO_b') or
				 (CSF1PO_1='$CSF1PO_a' AND CSF1PO_2='$CSF1PO_c') or
				 (CSF1PO_1='$CSF1PO_a' AND CSF1PO_2='$CSF1PO_d') or
				 (CSF1PO_1='$CSF1PO_b' AND CSF1PO_2='$CSF1PO_c') or 
				 (CSF1PO_1='$CSF1PO_b' AND CSF1PO_2='$CSF1PO_d') or
				 (CSF1PO_1='$CSF1PO_c' AND CSF1PO_2='$CSF1PO_d'))";
		return($sql);
	}
	
	function CSF1POthree($CSF1PO_a,$CSF1PO_b,$CSF1PO_c){
		$sql = " ((CSF1PO_1='$CSF1PO_a' AND CSF1PO_2='$CSF1PO_b') or
				 (CSF1PO_1='$CSF1PO_a' AND CSF1PO_2='$CSF1PO_c') or
				 (CSF1PO_1='$CSF1PO_b' AND CSF1PO_2='$CSF1PO_c') or 
				 (CSF1PO_1='$CSF1PO_a' AND CSF1PO_2='$CSF1PO_a') or
				 (CSF1PO_1='$CSF1PO_b' AND CSF1PO_2='$CSF1PO_b') or
				 (CSF1PO_1='$CSF1PO_c' AND CSF1PO_2='$CSF1PO_c'))";
		return($sql);
	}
	
	function CSF1POtwo($CSF1PO_a,$CSF1PO_b){
		$sql = " ((CSF1PO_1='$CSF1PO_a' AND CSF1PO_2='$CSF1PO_b') or
				 (CSF1PO_1='$CSF1PO_a' AND CSF1PO_2='$CSF1PO_a') or
				 (CSF1PO_1='$CSF1PO_b' AND CSF1PO_2='$CSF1PO_b'))";
    	return($sql);
	}

	function CSF1POone($CSF1PO_a){
		$sql = " ((CSF1PO_1='$CSF1PO_a' AND CSF1PO_2='$CSF1PO_a'))";
		return($sql);
	}
?>
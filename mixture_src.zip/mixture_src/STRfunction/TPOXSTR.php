<?php
	function TPOXall($TPOX_a,$TPOX_b,$TPOX_c,$TPOX_d){
		$sql = " ((TPOX_1='$TPOX_a' AND TPOX_2='$TPOX_b') or
				 (TPOX_1='$TPOX_a' AND TPOX_2='$TPOX_c') or
				 (TPOX_1='$TPOX_a' AND TPOX_2='$TPOX_d') or
				 (TPOX_1='$TPOX_b' AND TPOX_2='$TPOX_c') or 
				 (TPOX_1='$TPOX_b' AND TPOX_2='$TPOX_d') or
				 (TPOX_1='$TPOX_c' AND TPOX_2='$TPOX_d'))";
		return($sql);
	}
	
	function TPOXthree($TPOX_a,$TPOX_b,$TPOX_c){
		$sql = " ((TPOX_1='$TPOX_a' AND TPOX_2='$TPOX_b') or
				 (TPOX_1='$TPOX_a' AND TPOX_2='$TPOX_c') or
				 (TPOX_1='$TPOX_b' AND TPOX_2='$TPOX_c') or 
				 (TPOX_1='$TPOX_a' AND TPOX_2='$TPOX_a') or
				 (TPOX_1='$TPOX_b' AND TPOX_2='$TPOX_b') or
				 (TPOX_1='$TPOX_c' AND TPOX_2='$TPOX_c'))";
		return($sql);
	}
	
	function TPOXtwo($TPOX_a,$TPOX_b){
		$sql = " ((TPOX_1='$TPOX_a' AND TPOX_2='$TPOX_b') or
				 (TPOX_1='$TPOX_a' AND TPOX_2='$TPOX_a') or
				 (TPOX_1='$TPOX_b' AND TPOX_2='$TPOX_b'))";
    	return($sql);
	}

	function TPOXone($TPOX_a){
		$sql = " ((TPOX_1='$TPOX_a' AND TPOX_2='$TPOX_a'))";
		return($sql);
	}
?>
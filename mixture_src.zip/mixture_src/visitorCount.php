
<?php
	require('dbConnect.php');
	
	$sum=0;
	$todayc=date("Y-m-d"); // today 
	//$time=date("h:m:s");
	$ip = $_SERVER[REMOTE_ADDR];
	$sql="select * from counter where ip='$ip'";
	$result = mysql_query($sql);
	$row=mysql_fetch_array($result);
	if(!$row){
		$sql0="insert into counter(date,count,ip) values ('$todayc',1,'$ip')";
		$result0=mysql_query($sql0);
	}
	else {
		$sql1="insert into counter(date,count,ip) values ('$todayc',1,'$ip')";
		//$sql1="update counter set count=count+1,date='$todayc' where date='$todayc'";
		$result1=mysql_query($sql1);
	}
	
    $sql="select num from counter where date like '$todayc%'";
	$result=mysql_query($sql);
	$row=mysql_fetch_array($result);
	$numRow=mysql_num_rows($result);
	
	$sqlt="select * from counter";
	$resultt=mysql_query($sqlt);
	while ($rowt=mysql_fetch_array($resultt)){
		$sum +=$rowt[count];
	
	}
?>



<html>
<head>
	<title> FMDD </title>
	<style type="text/css">
		body {
		font-family : sans-serif;
	/*	font-size : 10 px; */
	}
	table {
		border : thin solid black;
		border-collapse : collapse; 
		font-family : Arial,sans-serif;
		font-size : 12 px;
		border-spacing: 0px;
		table-layout: fixed;  
	}
	th.mix {
		border: 1px solid gray;
		text-align: center;
		vertical-align: top;
		padding-right: 10px;
		background-color: tan;
		color: darkslategreen;
	}
	th.y {
		border: 1px solid gray;
		text-align: center;
		vertical-align: top;
		padding-right: 10px;
		background-color: yellow;
		color: darkslategreen;
	}
	td {
		border: 1px solid gray;
		vertical-align: top;
		padding-bottom: 5px;
		padding-top: 5px;
		padding-right: 3px;
		padding-left: 3px;
	}

	A:link {text-decoration:none;
		    color:black;
	}
	A:visited {text-decoration:none;
		    color:black;
	}
	A:hover {text-decoration:none;
		    color:black;
	}
	</style>
	<script language="javascript">

	
	function fnLayer()
	{
		var YstrKit_val=0;
		
		for (var i=0; i< sfrm.YstrKit.length; i++)
		{
			
			if(sfrm.YstrKit[i].checked==true)
			{
				
				YstrKit_val = sfrm.YstrKit[i].value;
				break;
			}
		}
	
		if(YstrKit_val=="1")
		{
				document.getElementById("yfiler").style.display = "block";
				document.getElementById("y23").style.display = "none";
		}
		else if(YstrKit_val=="2")
		{	
				document.getElementById("yfiler").style.display = "none";
				document.getElementById("y23").style.display = "block";
		}
	}
	</script>
</head>

<body>
<?php 
require('head.php');
?>

<div id="pagecell1"> 
  <!--pagecell1--> 
	  <img alt="" src="tl_curve_white.gif" height="6" width="6" id="tl" /> 
	  <img alt="" src="tr_curve_white.gif" height="6" width="6" id="tr" /> 
	 
	  <div id="pageName"> 
	  &nbsp;
		<h2>Submit (Mixed DNA & Y-STR) </h2> 
	  </div> 
	  <div id="col2"> 
		<div class="feature"> 
			<h3>Register your mixture profile </h3> (Input your profile. e.g. 7,9,10)
		      <form method="POST" action="uploadResult.php" name="frm">
				<table>
					<tr>
						<td colspan='9'><b>DNA_number : </b> <input type="text" name="dna" size='40'></td>
					</tr>
					<tr>
						<th class='mix'> Amelogenin </th>
						<th class='mix'> TH01 </th>
						<th class='mix'> TPOX </th>
						<th class='mix'> CSF1PO </th>
						<th class='mix'> D3S1358 </th>
						<th class='mix'> vWA </th>
						<th class='mix'> FGA </th>
						<th class='mix'> D5S818 </th>
						<th class='mix'> D13S317 </th>
					</tr>
					<tr>
						<td align="center"> <input type="text" name="amelo" size="7"> </td>
						<td align="center"> <input type="text" name="th01" size="7"> </td>
						<td align="center"> <input type="text" name="tpox" size="7"> </td>
						<td align="center"> <input type="text" name="csf1po" size="7"> </td>
						<td align="center"> <input type="text" name="d3" size="7"> </td>
						<td align="center"> <input type="text" name="vwa" size="7"> </td>
						<td align="center"> <input type="text" name="fga" size="7"> </td>
						<td align="center"> <input type="text" name="d5" size="7"> </td>
						<td align="center"> <input type="text" name="d13" size="7"> </td>
					</tr>
					<tr>
						<th class='mix'> D7S820 </th>
						<th class='mix'> D16S539 </th>
						<th class='mix'> D8S1179 </th>
						<th class='mix'> D21S11 </th>
						<th class='mix'> D18S51 </th>
						<th class='mix'> D2S1338 </th>
						<th class='mix'> D19S433 </th>
						<th class='mix'> Penta E </th>
						<th class='mix'> Penta D </th>
					</tr>
					<tr>
						<td align="center"> <input type="text" name="d7" size='7'> </td>
						<td align="center"> <input type="text" name="d16" size='7'> </td>
						<td align="center"> <input type="text" name="d8" size='7'> </td>
						<td align="center"> <input type="text" name="d21" size='7'> </td>
						<td align="center"> <input type="text" name="d18" size='7'> </td>
						<td align="center"> <input type="text" name="d2" size='7'> </td>
						<td align="center"> <input type="text" name="d19" size='7'> </td>
						<td align="center"> <input type="text" name="penE" size='7'> </td>
						<td align="center"> <input type="text" name="penD" size='7'> </td>
					</tr>
					<tr>
						<td colspan= '9'><input type="submit" value="Upload"></td>
					</tr>
				</table>
				</form>
			</div> 
		<div class="story">
			
			 <h3>CSV File Upload </h3> 
			 Please upload your files (Save as text (tab delimited) .txt file from excel) 
			 <a href = "upload_sample.txt" title="sample format"> Sample File </a> 
			 <a href = "./sample.xlsm">
				<img src = "image/excelimg.jpg" alt="download a file" width="20" height="20" border="0">
			</a>
			  <form method="POST" action="fileUploadResult.php" enctype="multipart/form-data">	
			  <p>			  
			  <input type="file" name="SubmitFile" size="20">
			  <input type="submit" value="Upload"> 
              </p>
			</form>
			<hr>

		
		<!-- Y-STR DATABASE �Է� -->
		<!-- Y-filer �������Է� -->
		<h3>Register your Y-STR profile</h3>
		<form method="POST" action="ystrSubmitResult.php" name="sfrm">
		<b>Y-STR kit : </b>
		<input type="radio" name="YstrKit" value="1" checked onclick="fnLayer()">Y-filer</input>
		<input type="radio" name="YstrKit" value="2" onclick="fnLayer()">PowerPlex Y23 </input>
		 &emsp;&emsp;&emsp; <b>(Use comma(',') at DYS385)</b>
		<table id="yfiler" style="display:block">
			<tr>
				<td colspan='3'><b>DNA_number : </b> <input type="text" name="ystrdna" size='40'></td>
				<td colspan='5'><b>comment : </b> <input type="textarea" name="comment" size='70'></td>
			</tr>
			<tr>
				<th class='y'> DYS456 </th>
				<th class='y'> DYS389I </th>
				<th class='y'> DYS390 </th>
				<th class='y'> DYS389II </th>
				<th class='y'> DYS458 </th>
				<th class='y'> DYS19 </th>
				<th class='y'> DYS385 </th>
				<th class='y'> DYS393 </th>
				
			</tr>
			<tr>
				<td align="center"> <input type="text" name="y456" size="7"> </td>
				<td align="center"> <input type="text" name="y389i" size="7"> </td>
				<td align="center"> <input type="text" name="y390" size="7"> </td>
				<td align="center"> <input type="text" name="y389ii" size="7"> </td>
				<td align="center"> <input type="text" name="y458" size="7"> </td>
				<td align="center"> <input type="text" name="y19" size="7"> </td>
				<td align="center"> <input type="text" name="y385" size="7"> </td>
				<td align="center"> <input type="text" name="y393" size="7"> </td>
			</tr>
			<tr>
				<th class='y'> DYS391 </th>
				<th class='y'> DYS439 </th>
				<th class='y'> DYS635 </th>
				<th class='y'> DYS392 </th>
				<th class='y'> Y_GATA_H4 </th>
				<th class='y'> DYS437 </th>
				<th class='y'> DYS438 </th>
				<th class='y'> DYS448 </th>
			</tr>
			<tr>
				<td align="center"> <input type="text" name="y391" size="7"> </td>
				<td align="center"> <input type="text" name="y439" size='7'> </td>
				<td align="center"> <input type="text" name="y635" size='7'> </td>
				<td align="center"> <input type="text" name="y392" size='7'> </td>
				<td align="center"> <input type="text" name="ygata" size='7'> </td>
				<td align="center"> <input type="text" name="y437" size='7'> </td>
				<td align="center"> <input type="text" name="y438" size='7'> </td>
				<td align="center"> <input type="text" name="y448" size='7'> </td>
			</tr>
			<tr>
				<td colspan= '8'><input type="submit" value="Upload"></td>
			</tr>
		</table>
		<!-- Y23 �������Է� -->
		<table id="y23" style="display:none">
			<tr>
				<td colspan='4'><b>DNA_number : </b> <input type="text" name="y23_ystrdna" size='40'></td>
				<td colspan='7'><b>comment : </b> <input type="textarea" name="y23_comment" size='70'></td>
			</tr>
			<tr>
				<th class='y'> DYS576 </th>
				<th class='y'> DYS389I </th>
				<th class='y'> DYS448 </th>
				<th class='y'> DYS389II </th>
				<th class='y'> DYS19 </th>
				<th class='y'> DYS391 </th>
				<th class='y'> DYS481 </th>
				<th class='y'> DYS549 </th>
				<th class='y'> DYS533 </th>
				<th class='y'> DYS438 </th>
				<th class='y'> DYS437 </th>
			</tr>
			<tr>
				<td align="center"> <input type="text" name="y23_y576" size="7"> </td>
				<td align="center"> <input type="text" name="y23_y389i" size="7"> </td>
				<td align="center"> <input type="text" name="y23_y448" size="7"> </td>
				<td align="center"> <input type="text" name="y23_y389ii" size="7"> </td>
				<td align="center"> <input type="text" name="y23_y19" size="7"> </td>
				<td align="center"> <input type="text" name="y23_y391" size="7"> </td>
				<td align="center"> <input type="text" name="y23_y481" size="7"> </td>
				<td align="center"> <input type="text" name="y23_y549" size="7"> </td>
				<td align="center"> <input type="text" name="y23_y533" size="7"> </td>
				<td align="center"> <input type="text" name="y23_y438" size="7"> </td>
				<td align="center"> <input type="text" name="y23_y437" size="7"> </td>
			</tr>
			<tr>
				<th class='y'> DYS570 </th>
				<th class='y'> DYS635 </th>
				<th class='y'> DYS390 </th>
				<th class='y'> DYS439 </th>
				<th class='y'> DYS392 </th>
				<th class='y'> DYS643 </th>
				<th class='y'> DYS393 </th>
				<th class='y'> DYS458 </th>
				<th class='y'> DYS385 </th>
				<th class='y'> DYS456 </th>
				<th class='y'> Y_GATA_H4 </th>
			</tr>
			<tr>
				<td align="center"> <input type="text" name="y23_y570" size="7"> </td>
				<td align="center"> <input type="text" name="y23_y635" size='7'> </td>
				<td align="center"> <input type="text" name="y23_y390" size='7'> </td>
				<td align="center"> <input type="text" name="y23_y439" size='7'> </td>
				<td align="center"> <input type="text" name="y23_y392" size='7'> </td>
				<td align="center"> <input type="text" name="y23_y643" size='7'> </td>
				<td align="center"> <input type="text" name="y23_y393" size='7'> </td>
				<td align="center"> <input type="text" name="y23_y458" size='7'> </td>
				<td align="center"> <input type="text" name="y23_y385" size='7'> </td>
				<td align="center"> <input type="text" name="y23_y456" size='7'> </td>
				<td align="center"> <input type="text" name="y23_ygata" size='7'> </td>
			</tr>
			<tr>
				<td colspan= '11'><input type="submit" value="Upload"></td>
			</tr>
		</table>
		
		</form>
		</div> 
	 </div> 
	  <!--end col2 --> 
	  <?php
		require ('left.php')
	  ?>
	  <!--end col1 div --> 
	  <?php
		require ('footer.php')
	  ?>
</div> 
	<!--end pagecell1--> 
<br /> 
</body>
</html>

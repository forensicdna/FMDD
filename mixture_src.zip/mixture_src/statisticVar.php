<?php
require('frequency.php');

//$_POST ============================
$th011=$_POST['th011'];
$th012=$_POST['th012'];

$th01a=$_POST['th01a'];
$th01b=$_POST['th01b'];
$th01c=$_POST['th01c'];
$th01d=$_POST['th01d'];

$th01_a=$_POST['th01_a'];
$th01_b=$_POST['th01_b'];
$th01_c=$_POST['th01_c'];
$th01_d=$_POST['th01_d'];
$th01_e=$_POST['th01_e'];
$th01_f=$_POST['th01_f'];
$vic_th01a=$_POST['vic_th01a'];
$vic_th01b=$_POST['vic_th01b'];
$sus_th01a=$_POST['sus_th01a'];
$sus_th01b=$_POST['sus_th01b'];
$sus_th01c=$_POST['sus_th01c'];
$sus_th01d=$_POST['sus_th01d'];

$tpox1=$_POST['tpox1'];
$tpox2=$_POST['tpox2'];

$tpoxa=$_POST['tpoxa'];
$tpoxb=$_POST['tpoxb'];
$tpoxc=$_POST['tpoxc'];
$tpoxd=$_POST['tpoxd'];

$tpox_a=$_POST['tpox_a'];
$tpox_b=$_POST['tpox_b'];
$tpox_c=$_POST['tpox_c'];
$tpox_d=$_POST['tpox_d'];
$tpox_e=$_POST['tpox_e'];
$tpox_f=$_POST['tpox_f'];
$vic_tpoxa=$_POST['vic_tpoxa'];
$vic_tpoxb=$_POST['vic_tpoxb'];
$sus_tpoxa=$_POST['sus_tpoxa'];
$sus_tpoxb=$_POST['sus_tpoxb'];
$sus_tpoxc=$_POST['sus_tpoxc'];
$sus_tpoxd=$_POST['sus_tpoxd'];

$csf1po1=$_POST['csf1po1'];
$csf1po2=$_POST['csf1po2'];

$csf1poa=$_POST['csf1poa'];
$csf1pob=$_POST['csf1pob'];
$csf1poc=$_POST['csf1poc'];
$csf1pod=$_POST['csf1pod'];

$csf1po_a=$_POST['csf1po_a'];
$csf1po_b=$_POST['csf1po_b'];
$csf1po_c=$_POST['csf1po_c'];
$csf1po_d=$_POST['csf1po_d'];
$csf1po_e=$_POST['csf1po_e'];
$csf1po_f=$_POST['csf1po_f'];
$vic_csf1poa=$_POST['vic_csf1poa'];
$vic_csf1pob=$_POST['vic_csf1pob'];
$sus_csf1poa=$_POST['sus_csf1poa'];
$sus_csf1pob=$_POST['sus_csf1pob'];
$sus_csf1poc=$_POST['sus_csf1poc'];
$sus_csf1pod=$_POST['sus_csf1pod'];

$d31=$_POST['d31'];
$d32=$_POST['d32'];

$d3a=$_POST['d3a'];
$d3b=$_POST['d3b'];
$d3c=$_POST['d3c'];
$d3d=$_POST['d3d'];

$d3_a=$_POST['d3_a'];
$d3_b=$_POST['d3_b'];
$d3_c=$_POST['d3_c'];
$d3_d=$_POST['d3_d'];
$d3_e=$_POST['d3_e'];
$d3_f=$_POST['d3_f'];
$vic_d3a=$_POST['vic_d3a'];
$vic_d3b=$_POST['vic_d3b'];
$sus_d3a=$_POST['sus_d3a'];
$sus_d3b=$_POST['sus_d3b'];
$sus_d3c=$_POST['sus_d3c'];
$sus_d3d=$_POST['sus_d3d'];

$vwa1=$_POST['vwa1'];
$vwa2=$_POST['vwa2'];

$vwaa=$_POST['vwaa'];
$vwab=$_POST['vwab'];
$vwac=$_POST['vwac'];
$vwad=$_POST['vwad'];

$vwa_a=$_POST['vwa_a'];
$vwa_b=$_POST['vwa_b'];
$vwa_c=$_POST['vwa_c'];
$vwa_d=$_POST['vwa_d'];
$vwa_e=$_POST['vwa_e'];
$vwa_f=$_POST['vwa_f'];
$vic_vwaa=$_POST['vic_vwaa'];
$vic_vwab=$_POST['vic_vwab'];
$sus_vwaa=$_POST['sus_vwaa'];
$sus_vwab=$_POST['sus_vwab'];
$sus_vwac=$_POST['sus_vwac'];
$sus_vwad=$_POST['sus_vwad'];

$fga1=$_POST['fga1'];
$fga2=$_POST['fga2'];

$fgaa=$_POST['fgaa'];
$fgab=$_POST['fgab'];
$fgac=$_POST['fgac'];
$fgad=$_POST['fgad'];

$fga_a=$_POST['fga_a'];
$fga_b=$_POST['fga_b'];
$fga_c=$_POST['fga_c'];
$fga_d=$_POST['fga_d'];
$fga_e=$_POST['fga_e'];
$fga_f=$_POST['fga_f'];
$vic_fgaa=$_POST['vic_fgaa'];
$vic_fgab=$_POST['vic_fgab'];
$sus_fgaa=$_POST['sus_fgaa'];
$sus_fgab=$_POST['sus_fgab'];
$sus_fgac=$_POST['sus_fgac'];
$sus_fgad=$_POST['sus_fgad'];

$d51=$_POST['d51'];
$d52=$_POST['d52'];

$d5a=$_POST['d5a'];
$d5b=$_POST['d5b'];
$d5c=$_POST['d5c'];
$d5d=$_POST['d5d'];

$d5_a=$_POST['d5_a'];
$d5_b=$_POST['d5_b'];
$d5_c=$_POST['d5_c'];
$d5_d=$_POST['d5_d'];
$d5_e=$_POST['d5_e'];
$d5_f=$_POST['d5_f'];
$vic_d5a=$_POST['vic_d5a'];
$vic_d5b=$_POST['vic_d5b'];
$sus_d5a=$_POST['sus_d5a'];
$sus_d5b=$_POST['sus_d5b'];
$sus_d5c=$_POST['sus_d5c'];
$sus_d5d=$_POST['sus_d5d'];

$d131=$_POST['d131'];
$d132=$_POST['d132'];

$d13a=$_POST['d13a'];
$d13b=$_POST['d13b'];
$d13c=$_POST['d13c'];
$d13d=$_POST['d13d'];

$d13_a=$_POST['d13_a'];
$d13_b=$_POST['d13_b'];
$d13_c=$_POST['d13_c'];
$d13_d=$_POST['d13_d'];
$d13_e=$_POST['d13_e'];
$d13_f=$_POST['d13_f'];
$vic_d13a=$_POST['vic_d13a'];
$vic_d13b=$_POST['vic_d13b'];
$sus_d13a=$_POST['sus_d13a'];
$sus_d13b=$_POST['sus_d13b'];
$sus_d13c=$_POST['sus_d13c'];
$sus_d13d=$_POST['sus_d13d'];

$d71=$_POST['d71'];
$d72=$_POST['d72'];

$d7a=$_POST['d7a'];
$d7b=$_POST['d7b'];
$d7c=$_POST['d7c'];
$d7d=$_POST['d7d'];

$d7_a=$_POST['d7_a'];
$d7_b=$_POST['d7_b'];
$d7_c=$_POST['d7_c'];
$d7_d=$_POST['d7_d'];
$d7_e=$_POST['d7_e'];
$d7_f=$_POST['d7_f'];
$vic_d7a=$_POST['vic_d7a'];
$vic_d7b=$_POST['vic_d7b'];
$sus_d7a=$_POST['sus_d7a'];
$sus_d7b=$_POST['sus_d7b'];
$sus_d7c=$_POST['sus_d7c'];
$sus_d7d=$_POST['sus_d7d'];

$d161=$_POST['d161'];
$d162=$_POST['d162'];

$d16a=$_POST['d16a'];
$d16b=$_POST['d16b'];
$d16c=$_POST['d16c'];
$d16d=$_POST['d16d'];

$d16_a=$_POST['d16_a'];
$d16_b=$_POST['d16_b'];
$d16_c=$_POST['d16_c'];
$d16_d=$_POST['d16_d'];
$d16_e=$_POST['d16_e'];
$d16_f=$_POST['d16_f'];
$vic_d16a=$_POST['vic_d16a'];
$vic_d16b=$_POST['vic_d16b'];
$sus_d16a=$_POST['sus_d16a'];
$sus_d16b=$_POST['sus_d16b'];
$sus_d16c=$_POST['sus_d16c'];
$sus_d16d=$_POST['sus_d16d'];

$d81=$_POST['d81'];
$d82=$_POST['d82'];

$d8a=$_POST['d8a'];
$d8b=$_POST['d8b'];
$d8c=$_POST['d8c'];
$d8d=$_POST['d8d'];

$d8_a=$_POST['d8_a'];
$d8_b=$_POST['d8_b'];
$d8_c=$_POST['d8_c'];
$d8_d=$_POST['d8_d'];
$d8_e=$_POST['d8_e'];
$d8_f=$_POST['d8_f'];
$vic_d8a=$_POST['vic_d8a'];
$vic_d8b=$_POST['vic_d8b'];
$sus_d8a=$_POST['sus_d8a'];
$sus_d8b=$_POST['sus_d8b'];
$sus_d8c=$_POST['sus_d8c'];
$sus_d8d=$_POST['sus_d8d'];

$d211=$_POST['d211'];
$d212=$_POST['d212'];

$d21a=$_POST['d21a'];
$d21b=$_POST['d21b'];
$d21c=$_POST['d21c'];
$d21d=$_POST['d21d'];

$d21_a=$_POST['d21_a'];
$d21_b=$_POST['d21_b'];
$d21_c=$_POST['d21_c'];
$d21_d=$_POST['d21_d'];
$d21_e=$_POST['d21_e'];
$d21_f=$_POST['d21_f'];
$vic_d21a=$_POST['vic_d21a'];
$vic_d21b=$_POST['vic_d21b'];
$sus_d21a=$_POST['sus_d21a'];
$sus_d21b=$_POST['sus_d21b'];
$sus_d21c=$_POST['sus_d21c'];
$sus_d21d=$_POST['sus_d21d'];

$d181=$_POST['d181'];
$d182=$_POST['d182'];

$d18a=$_POST['d18a'];
$d18b=$_POST['d18b'];
$d18c=$_POST['d18c'];
$d18d=$_POST['d18d'];

$d18_a=$_POST['d18_a'];
$d18_b=$_POST['d18_b'];
$d18_c=$_POST['d18_c'];
$d18_d=$_POST['d18_d'];
$d18_e=$_POST['d18_e'];
$d18_f=$_POST['d18_f'];
$vic_d18a=$_POST['vic_d18a'];
$vic_d18b=$_POST['vic_d18b'];
$sus_d18a=$_POST['sus_d18a'];
$sus_d18b=$_POST['sus_d18b'];
$sus_d18c=$_POST['sus_d18c'];
$sus_d18d=$_POST['sus_d18d'];

$d21=$_POST['d21'];
$d22=$_POST['d22'];

$d2a=$_POST['d2a'];
$d2b=$_POST['d2b'];
$d2c=$_POST['d2c'];
$d2d=$_POST['d2d'];

$d2_a=$_POST['d2_a'];
$d2_b=$_POST['d2_b'];
$d2_c=$_POST['d2_c'];
$d2_d=$_POST['d2_d'];
$d2_e=$_POST['d2_e'];
$d2_f=$_POST['d2_f'];
$vic_d2a=$_POST['vic_d2a'];
$vic_d2b=$_POST['vic_d2b'];
$sus_d2a=$_POST['sus_d2a'];
$sus_d2b=$_POST['sus_d2b'];
$sus_d2c=$_POST['sus_d2c'];
$sus_d2d=$_POST['sus_d2d'];

$d191=$_POST['d191'];
$d192=$_POST['d192'];

$d19a=$_POST['d19a'];
$d19b=$_POST['d19b'];
$d19c=$_POST['d19c'];
$d19d=$_POST['d19d'];

$d19_a=$_POST['d19_a'];
$d19_b=$_POST['d19_b'];
$d19_c=$_POST['d19_c'];
$d19_d=$_POST['d19_d'];
$d19_e=$_POST['d19_e'];
$d19_f=$_POST['d19_f'];
$vic_d19a=$_POST['vic_d19a'];
$vic_d19b=$_POST['vic_d19b'];
$sus_d19a=$_POST['sus_d19a'];
$sus_d19b=$_POST['sus_d19b'];
$sus_d19c=$_POST['sus_d19c'];
$sus_d19d=$_POST['sus_d19d'];

$contributor=$_POST['contributor'];
$likelihood=$_POST['likelihood'];
$victim=$_POST['victim'];
$suspect=$_POST['suspect'];
$pop=$_POST['pop'];
$save=$_POST['save'];
$rd=$_POST['rd'];
$dropout=$_POST['dropout'];
// trim ===================================================================================
$th01a=trim($th01a);
$th01b=trim($th01b);
$th01c=trim($th01c);
$th01d=trim($th01d);
$th01e=trim($th01e);
$th01f=trim($th01f);

$tpoxa=trim($tpoxa);
$tpoxb=trim($tpoxb);
$tpoxc=trim($tpoxc);
$tpoxd=trim($tpoxd);
$tpoxe=trim($tpoxe);
$tpoxf=trim($tpoxf);

$csf1poa=trim($csf1poa);
$csf1pob=trim($csf1pob);
$csf1poc=trim($csf1poc);
$csf1pod=trim($csf1pod);
$csf1poe=trim($csf1poe);
$csf1pof=trim($csf1pof);

$th01a=trim($th01a);
$th01b=trim($th01b);
$th01c=trim($th01c);
$th01d=trim($th01d);
$th01e=trim($th01e);
$th01f=trim($th01f);

$d3a=trim($d3a);
$d3b=trim($d3b);
$d3c=trim($d3c);
$d3d=trim($d3d);
$d3e=trim($d3e);
$d3f=trim($d3f);

$vwaa=trim($vwaa);
$vwab=trim($vwab);
$vwac=trim($vwac);
$vwad=trim($vwad);
$vwae=trim($vwae);
$vwaf=trim($vwaf);

$fgaa=trim($fgaa);
$fgab=trim($fgab);
$fgac=trim($fgac);
$fgad=trim($fgad);
$fgae=trim($fgae);
$fgaf=trim($fgaf);

$d5a=trim($d5a);
$d5b=trim($d5b);
$d5c=trim($d5c);
$d5d=trim($d5d);
$d5e=trim($d5e);
$d5f=trim($d5f);

$d13a=trim($d13a);
$d13b=trim($d13b);
$d13c=trim($d13c);
$d13d=trim($d13d);
$d13e=trim($d13e);
$d13f=trim($d13f);

$d7a=trim($d7a);
$d7b=trim($d7b);
$d7c=trim($d7c);
$d7d=trim($d7d);
$d7e=trim($d7e);
$d7f=trim($d7f);

$d16a=trim($d16a);
$d16b=trim($d16b);
$d16c=trim($d16c);
$d16d=trim($d16d);
$d16e=trim($d16e);
$d16f=trim($d16f);

$d8a=trim($d8a);
$d8b=trim($d8b);
$d8c=trim($d8c);
$d8d=trim($d8d);
$d8e=trim($d8e);
$d8f=trim($d8f);

$d21a=trim($d21a);
$d21b=trim($d21b);
$d21c=trim($d21c);
$d21d=trim($d21d);
$d21e=trim($d21e);
$d21f=trim($d21f);

$d18a=trim($d18a);
$d18b=trim($d18b);
$d18c=trim($d18c);
$d18d=trim($d18d);
$d18e=trim($d18e);
$d18f=trim($d18f);

$d2a=trim($d2a);
$d2b=trim($d2b);
$d2c=trim($d2c);
$d2d=trim($d2d);
$d2e=trim($d2e);
$d2f=trim($d2f);

$d19a=trim($d19a);
$d19b=trim($d19b);
$d19c=trim($d19c);
$d19d=trim($d19d);
$d19e=trim($d19e);
$d19f=trim($d19f);

?>
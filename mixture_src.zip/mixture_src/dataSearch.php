<html>
<head>
	<title> FMDD </title>
	<style type="text/css">
	body {
		font-family : sans-serif;
		
	}
	table {
		border : thin solid black;
		border-collapse : collapse; 
		font-family : sans-serif;
		font-size : 12 px;
		color: black;
		border-spacing: 0px;
		table-layout: 500px; 
	}
	th {
		border: 1px solid gray;
		text-align: center;
		vertical-align: top;
		padding-right: 10px;
		background-color: EDE2E9;  

	}
	td {
		border: 1px solid gray;
		vertical-align: top;
		padding-bottom: 5px;
		padding-top: 5px;
	}

	
	</style>
</head>
<body>

<?php 
require('dbConnect.php');
require('head.php');
$dnaName=$_REQUEST['dnaName'];
$inputDate=$_REQUEST['inputDate'];
if(!get_magic_quotes_gpc())
{
	$dnaName=addslashes($dnaName);
	$inputDate=addslashes($inputDate);
}
$dnaName=trim($dnaName);
$inputDate=trim($inputDate);

?>
<div id="pagecell1"> 
  <!--pagecell1--> 
	  <img alt="" src="tl_curve_white.gif" height="6" width="6" id="tl" /> 
	  <img alt="" src="tr_curve_white.gif" height="6" width="6" id="tr" /> 
	  
	  <div id="pageName"> 
	    &nbsp;
		<h2>Mixed DB </h2> 
	  </div> 
	  <div id="col2"> 
		<div class="feature"> 
	  <form action="" method="post" onsubmit="return check(form)">
	  <table><b>Search keyword</b>
				<td>DNA ��ȣ : <input name="dnaName" type="text"> </td>
				<td>�Է³�¥ <input name="inputDate" type="text"> ���� (YYYY-MM-DD) </td>
	  </table>
	<p>
	<input type="submit" value="search">
	</form>
	<hr>
<?php



	if (!$dnaName && !$inputDate){
		$sql = "select DNA_no,inputDate from profile order by inputDate desc, DNA_no desc";
		$result = mysql_query($sql);
		$numRow=mysql_num_rows($result);
		echo '<table>';
		echo '<th width=50> ���� </th>';
		echo '<th> DNA ��ȣ </th>';
		echo '<th> Y-STR </th>';
		echo '<th> �Է³�¥ </th>';
			for ($i=0; $i<$numRow; $i++){
			$row=mysql_fetch_array($result);
			echo '	<tr>';
			echo '		<td align=center>'.($i+1).'</td>';
			echo '		<td><a href="resultView.php?DNA_no='.$row[DNA_no].'" target="_blank" onClick="window.open(this.href,\'\',\'width=700, height=800\'); 
						return false;">'.$row[DNA_no].'</a></td>';
				$match = "select DNA from profile, ystr where ystr.DNA ='".$row[DNA_no]."' and profile.DNA_no='".$row[DNA_no]."'";
				$matchResult = mysql_query($match);
				$matchRow=mysql_fetch_array($matchResult);
				if ($matchRow[DNA]){echo ' <td align=center> O </td>';} else {echo ' <td align=center> X </td>';}
			echo '		<td>'.$row[inputDate].'</td>';
			echo '  </tr>';
			
			}
		echo '</table>';
	}elseif ($dnaName && !$inputDate){
		$sql = "select DNA_no,inputDate from profile where DNA_no like '%$dnaName%' order by inputDate desc";
		$result = mysql_query($sql);
		$numRow=mysql_num_rows($result);
		echo '<table>';
		echo '<th width=50> ���� </th>';
		echo '<th> DNA ��ȣ </th>';
		echo '<th> Y-STR </th>';
		echo '<th> �Է³�¥ </th>';
			for ($i=0; $i<$numRow; $i++){
			$row=mysql_fetch_array($result);
			echo '	<tr>';
			echo '		<td align=center>'.($i+1).'</td>';
			echo '		<td><a href="resultView.php?DNA_no='.$row[DNA_no].'" target="_blank" onClick="window.open(this.href,\'\',\'width=700, height=800\'); 
						return false;">'.$row[DNA_no].'</a></td>';
				$match = "select DNA from profile, ystr where ystr.DNA ='".$row[DNA_no]."' and profile.DNA_no='".$row[DNA_no]."'";
				$matchResult = mysql_query($match);
				$matchRow=mysql_fetch_array($matchResult);
				if ($matchRow[DNA]){echo ' <td align=center> O </td>';} else {echo ' <td align=center> X </td>';}
			echo '		<td>'.$row[inputDate].'</td>';
			echo '  </tr>';
			
			}
		echo '</table>';
	}elseif (!$dnaName && $inputDate){
		$sql = "select DNA_no,inputDate from profile where inputDate = '$inputDate' order by inputDate desc";
		$result = mysql_query($sql);
		$numRow=mysql_num_rows($result);
		echo '<table>';
		echo '<th width=50> ���� </th>';
		echo '<th> DNA ��ȣ </th>';
		echo '<th> Y-STR </th>';
		echo '<th> �Է³�¥ </th>';
			for ($i=0; $i<$numRow; $i++){
			$row=mysql_fetch_array($result);
			echo '	<tr>';
			echo '		<td align=center>'.($i+1).'</td>';
			echo '		<td><a href="resultView.php?DNA_no='.$row[DNA_no].'" target="_blank" onClick="window.open(this.href,\'\',\'width=700, height=800\'); 
						return false;">'.$row[DNA_no].'</a></td>';
				$match = "select DNA from profile, ystr where ystr.DNA ='".$row[DNA_no]."' and profile.DNA_no='".$row[DNA_no]."'";
				$matchResult = mysql_query($match);
				$matchRow=mysql_fetch_array($matchResult);
				if ($matchRow[DNA]){echo ' <td align=center> O </td>';} else {echo ' <td align=center> X </td>';}
			echo '		<td>'.$row[inputDate].'</td>';
			echo '  </tr>';
			
			}
		echo '</table>';
	}elseif ($dnaName && $inputDate){
		$sql = "select DNA_no,inputDate from profile where DNA_no like '%$dnaName%' and inputDate = '$inputDate'";
		$result = mysql_query($sql);
		$numRow=mysql_num_rows($result);
		echo '<table>';
		echo '<th width=50> ���� </th>';
		echo '<th> DNA ��ȣ </th>';
		echo '<th> Y-STR </th>';
		echo '<th> �Է³�¥ </th>';
			for ($i=0; $i<$numRow; $i++){
			$row=mysql_fetch_array($result);
			echo '	<tr>';
			echo '		<td align=center>'.($i+1).'</td>';
			echo '		<td><a href="resultView.php?DNA_no='.$row[DNA_no].'" target="_blank" onClick="window.open(this.href,\'\',\'width=700, height=800\'); 
						return false;">'.$row[DNA_no].'</a></td>';
				$match = "select DNA from profile, ystr where ystr.DNA ='".$row[DNA_no]."' and profile.DNA_no='".$row[DNA_no]."'";
				$matchResult = mysql_query($match);
				$matchRow=mysql_fetch_array($matchResult);
				if ($matchRow[DNA]){echo ' <td align=center> O </td>';} else {echo ' <td align=center> X </td>';}
			echo '		<td>'.$row[inputDate].'</td>';
			echo '  </tr>';
			
			}
		echo '</table>';
}
?>
</div> 
	 </div> 
	  <!--end col2 --> 
	  <?php
		require ('left.php')
	  ?>
	  <!--end col1 div --> 
	  <?php
		require ('footer.php')
	  ?>
</body>
</html>

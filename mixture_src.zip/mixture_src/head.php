
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- DW6 -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr" />
<title>Forensic Mixed DNA Database</title>
<link rel="stylesheet" href="emx_nav_left.css" type="text/css" />
<script type="text/javascript">
<!--
var time = 3000;
var numofitems = 7;
/*
//menu constructor

function menu(allitems,thisitem,startstate){ 
  callname= "gl"+thisitem;
  divname="subglobal"+thisitem;  
  this.numberofmenuitems = 7;
  this.caller = document.getElementById(callname);
  this.thediv = document.getElementById(divname);
  this.thediv.style.visibility = startstate;
}

//menu methods
function ehandler(event,theobj){
  for (var i=1; i<= theobj.numberofmenuitems; i++){
    var shutdiv =eval( "menuitem"+i+".thediv");
    shutdiv.style.visibility="hidden";
  }
  theobj.thediv.style.visibility="visible";
}
				
function closesubnav(event){
  if ((event.clientY <26)||(event.clientY > 85)){
    for (var i=1; i<= numofitems; i++){
      var shutdiv =eval('menuitem'+i+'.thediv');
      shutdiv.style.visibility='hidden';
    }
  }
} 

// -->*/
</script>
</head>
<!-- ��� �� -->
<!-- body ���� -->
<!-- body �� �κ� -->
<body> 
<div id="masthead"> 
  <h1 id="siteName">Forensic Mixed DNA Database <i>(FMDD)</i></h1> 
  
  <div id="globalNav"> 
    <img alt="" src="gblnav_left.gif" height="32" width="4" id="gnl" /> 
	<img alt="" src="glbnav_right.gif" height="32" width="4" id="gnr" /> 
	<div id="globalLink"> 
		<a href="index.php" id="gl1" class="glink">Home</a>
		<a href="dataSearch.php" id="gl1" class="glink">�����Ͱ���</a>
		<a href="search.php" target="_top" class="glink" id="gl2">�˻� (reference)</a>
		<a href="search2reference.php" target="_top" class="glink" id="gl2">�˻� (mixture)</a>
		<a href="submit.php" id="gl3" class="glink">��� (Mix&Y)</a>
		<a href="refSubmit.php" id="gl3" class="glink">��� (reference)</a>
		<a href="statistic.php" id="gl4" class="glink">�м�</a>
    </div> 
    <!--end globalLinks--> 
   </div> 
</div> 
<!-- end masthead --> 
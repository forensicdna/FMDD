<html>
<head>
	<title> FMDD </title>
	<style type="text/css">
	body {
		font-family : sans-serif;
	/*	font-size : 10 px; */
	}
	table {
		border : thin solid black;
		border-collapse : collapse; 
		font-family : sans-serif;
		font-size : 11 px;
		border-spacing: 0px;
		table-layout: fixed; 
		vertical-align: center;

	}
	th {
		border: 1px solid gray;
		text-align: center;
		vertical-align: center;
		padding-right: 1px;
		height: auto;
		background-color: #fcba7a;
	}
	td {
		border: 1px solid gray;
		text-align: center;
		vertical-align: center;
		padding-bottom: 15px;
		word-break: break-all;
		height: auto;
	}
	
	</style>
</head>
<body>

<?php
	require('dbConnect.php');
	require('alleleVar.php');
	require('head.php');
	require('frequency.php');
	
?>	


<div id="pagecell1"> 
  <!--pagecell1--> 
	  <img alt="" src="tl_curve_white.gif" height="6" width="6" id="tl" /> 
	  <img alt="" src="tr_curve_white.gif" height="6" width="6" id="tr" /> 
	  <div> 
		&nbsp;
	  </div> 
	  <div id="pageName"> 
		<h2>Search Results </h2> 
	  </div> 
	   <input type="button" value="Go Search" title="Go back to Search Page" onclick="window.location='search.php'">
	  <div class="story">
	
<?php

	if (!$amelo_a && !$amelo_b && !$th01_a && !$th01_b && !$th01_b && !$tpox_a && !$tpox_a && !$tpox_b && !$csf1po_a && !$csf1po_b && !$d3_a && !$d3_b && !$vwa_a && !$vwa_b && !$fga_a && !$fga_b && !$d5_a && !$d5_b && !$d13_a && !$d13_b && !$d7_a && !$d7_b && !$d16_a && !$d16_b && !$d8_a && !$d8_b && !$d21_a && !$d21_b && !$d18_a && !$d18_b && !$d2_a && !$d2_b && !$d19_a && !$d19_b && !$penE_a && !$penE_b && !$penD_a && !$penD_b)
		{
				echo 'You have not entered any profiles'.'<p>';
				exit;
		}
?>	 

	 <table align="center" width='95.8%'>
					<tr>
						<th>  </th>
						<th width='120'> DNA <br>Number </th>
						<th> Amel </th>
						<th> TH01 </th>
						<th> TPOX </th>
						<th> CSF1PO </th>
						<th> D3S1358 </th>
						<th> vWA </th>
						<th> FGA </th>
						<th> D5S818 </th>
						<th> D13S317 </th>
						<th> D7S820 </th>
						<th> D16S539 </th>
						<th> D8S1179 </th>
						<th> D21S11 </th>
						<th> D18S51 </th>
						<th> D2S1338 </th>
						<th> D19S433 </th>
						<th> Penta E </th>
						<th> Penta D </th>
						<th> Y-STR profile </th>
					</tr>
					<tr>
						<td> Query </td>
						<td> Mannual </td>
						<td> <?php if ($amelo_a && !$amelo_b){
										echo $amelo_a;
									} elseif ($amelo_a && $amelo_b){
										echo $amelo_a.",".$amelo_b;
									} 
							?> 
						</td>
						<td> <?php if ($th01_a && !$th01_b) {
										echo $th01_a; 
									} elseif ($th01_a && $th01_b){
										echo $th01_a.",".$th01_b;
									}
							?> 
						</td>
						<td> <?php if ($tpox_a && !$tpox_b) {
										echo $tpox_a;
									} elseif ($tpox_a && $tpox_b){
										echo $tpox_a.",".$tpox_b;	
									}
							?>
						</td>
						<td> <?php if ($csf1po_a && !$csf1po_b) {
										echo $csf1po_a;
									} elseif ($csf1po_a && $csf1po_b){
										echo $csf1po_a.",".$csf1po_b;
									} 
							?> 
						</td>
						<td> <?php if ($d3_a && !$d3_b) {
										echo $d3_a;
									} elseif ($d3_a && $d3_b){
										echo $d3_a.",".$d3_b;
									} 
							?> 
						</td>
						<td> <?php if ($vwa_a && !$vwa_b) {
										echo $vwa_a;
									} elseif ($vwa_a && $vwa_b){
										echo $vwa_a.",".$vwa_b;
									} 
							?> 
						</td>
						<td> <?php if ($fga_a && !$fga_b) {
										echo $fga_a;
									} elseif ($fga_a && $fga_b) {
										echo $fga_a.",".$fga_b;
									} 
							?> 
						</td>
						<td> <?php if ($d5_a && !$d5_b) {
										echo $d5_a;
									} elseif ($d5_a && $d5_b) {
										echo $d5_a.",".$d5_b;
									} 
							?> 
						</td>
						<td> <?php if ($d13_a && !$d13_b) {
										echo $d13_a;
									} elseif ($d13_a && $d13_b) {
										echo $d13_a.",".$d13_b;
									} 
							?> 
						</td>
						<td> <?php if ($d7_a && !$d7_b) {
										echo $d7_a;
									} elseif ($d7_a && $d7_b) {
										echo $d7_a.",".$d7_b;
									} 
							?> 
						</td>
						<td> <?php if ($d16_a && !$d16_b) {
										echo $d16_a; 
									} elseif ($d16_a && $d16_b) {
										echo $d16_a.",".$d16_b;
									} 
							?> 
						</td>
						<td> <?php if ($d8_a && !$d8_b) {
										echo $d8_a;
									} elseif ($d8_a && $d8_b) {
										echo $d8_a.",".$d8_b;
									} 
							?> 
						</td>
						<td> <?php if ($d21_a && !$d21_b) {
										echo $d21_a;
									} elseif ($d8_a && $d8_b) {
										echo $d21_a.",".$d21_b;
									} 
							?> 
						</td>
						<td> <?php if ($d18_a && !$d18_b) {
										echo $d18_a;
									} elseif ($d18_a && $d18_b) {
										echo $d18_a.",".$d18_b;
									} 
							?> 
						</td>
						<td> <?php if ($d2_a && !$d2_b) {
										echo $d2_a;
									} elseif ($d2_a && $d2_b) {
										echo $d2_a.",".$d2_b;
									} 
							?> 
						</td>
						<td> <?php if ($d19_a && !$d19_b) {
										echo $d19_a;
									} elseif ($d19_a && $d19_b) {
										echo $d19_a.",".$d19_b;
									} 
							?> 
						</td>
						<td> <?php if ($penE_a && !$penE_b) {
										echo $penE_a;
									} elseif ($penE_a && $penE_b) {
										echo $penE_a.",".$penE_b;
									} 
							?> 
						</td>
						<td> <?php if ($penD_a && !$penD_b) {
										echo $penD_a;
									} elseif ($penD_a && $penD_b) {
										echo $penD_a.",".$penD_b;
									} 
							?> 
						</td>
					</tr>


<?php

$sql = "SELECT * FROM profile WHERE  (amel  LIKE '%$amelo_a%$amelo_b%' or amel LIKE '') AND
      (th01 LIKE '%$th01_a%$th01_b%' or th01 LIKE '') AND 
      (tpox  LIKE '%$tpox_a%$tpox_b%' or tpox LIKE '') AND
      (csf1po  LIKE '%$csf1po_a%$csf1po_b%' or csf1po LIKE '') AND
      (d3  LIKE '%$d3_a%$d3_b%' or d3 LIKE '') AND
      (vwa  LIKE '%$vwa_a%$vwa_b%' or vwa LIKE '') AND
      (fga  LIKE '%$fga_a%$fga_b%' or fga LIKE '') AND 
      (d5  LIKE '%$d5_a%$d5_b%' or d5 LIKE '') AND 
      (d13  LIKE '%$d13_a%$d13_b%' or d13 LIKE '') AND 
      (d7  LIKE '%$d7_a%$d7_b%' or d7 LIKE '') AND 
      (d16  LIKE '%$d16_a%$d16_b%' or d16 LIKE '') AND 
      (d8  LIKE '%$d8_a%$d8_b%' or d8 LIKE '') AND 
      (d21  LIKE '%$d21_a%$d21_b%' or d21 LIKE '') AND 
      (d18  LIKE '%$d18_a%$d18_b%' or d18 LIKE '') AND 
      (d2  LIKE '%$d2_a%$d2_b%' or d2 LIKE '') AND 
      (d19  LIKE '%$d19_a%$d19_b%' or d19 LIKE '') AND 
      (pentae  LIKE '%$penE_a%$penE_b%' or pentae LIKE '') AND 
      (pentad  LIKE '%$penD_a%$penD_b%' or pentad LIKE '') ";
echo $sql;


	$locus = array($amelo_a, $amelo_b);	
	$locus0 = array($th01_a, $th01_b);
	$locus1 = array($tpox_a, $tpox_b);
	$locus2 = array($csf1po_a, $csf1po_b);
	$locus3 = array($d3_a, $d3_b);
	$locus4 = array($vwa_a, $vwa_b);
	$locus5 = array($fga_a, $fga_b);
	$locus6 = array($d5_a, $d5_b);
	$locus7 = array($d13_a, $d13_b);
	$locus8 = array($d7_a, $d7_b);
	$locus9 = array($d16_a, $d16_b);
	$locus10 = array($d8_a, $d8_b);
	$locus11 = array($d21_a, $d21_b);
	$locus12 = array($d18_a, $d18_b);
	$locus13 = array($d2_a, $d2_b);
	$locus14 = array($d19_a, $d19_b);
	$locus15 = array($penE_a, $penE_b);
	$locus16 = array($penD_a, $penD_b);

	$replace = array('<font color="red">'.$amelo_a.'</font>','<font color="red">'.$amelo_b.'</font>');
	$replace0 = array('<font color="red">'.$th01_a.'</font>','<font color="red">'.$th01_b.'</font>');
	$replace1 = array('<font color="red">'.$tpox_a.'</font>','<font color="red">'.$tpox_b.'</font>');
	$replace2 = array('<font color="red">'.$csf1po_a.'</font>','<font color="red">'.$csf1po_b.'</font>');
	$replace3 = array('<font color="red">'.$d3_a.'</font>','<font color="red">'.$d3_b.'</font>');
	$replace4 = array('<font color="red">'.$vwa_a.'</font>','<font color="red">'.$vwa_b.'</font>');
	$replace5 = array('<font color="red">'.$fga_a.'</font>','<font color="red">'.$fga_b.'</font>');
	$replace6 = array('<font color="red">'.$d5_a.'</font>','<font color="red">'.$d5_b.'</font>');
	$replace7 = array('<font color="red">'.$d13_a.'</font>','<font color="red">'.$d13_b.'</font>');
	$replace8 = array('<font color="red">'.$d7_a.'</font>','<font color="red">'.$d7_b.'</font>');
	$replace9 = array('<font color="red">'.$d16_a.'</font>','<font color="red">'.$d16_b.'</font>');
	$replace10 = array('<font color="red">'.$d8_a.'</font>','<font color="red">'.$d8_b.'</font>');
	$replace11 = array('<font color="red">'.$d21_a.'</font>','<font color="red">'.$d21_b.'</font>');
	$replace12 = array('<font color="red">'.$d18_a.'</font>','<font color="red">'.$d18_b.'</font>');
	$replace13 = array('<font color="red">'.$d2_a.'</font>','<font color="red">'.$d2_b.'</font>');
	$replace14 = array('<font color="red">'.$d19_a.'</font>','<font color="red">'.$d19_b.'</font>');
	$replace15 = array('<font color="red">'.$penE_a.'</font>','<font color="red">'.$penE_b.'</font>');
	$replace16 = array('<font color="red">'.$penD_a.'</font>','<font color="red">'.$penD_b.'</font>');

	$result = mysql_query($sql);
	$numRow=mysql_num_rows($result);

	for ($i=0; $i<$numRow; $i++){
		$row=mysql_fetch_array($result);
				

?>
		<tr>
			
			 <td> Match </td>
			 <?php echo '<td><a href="resultView.php?DNA_no='.$row[DNA_no].'" target="_blank" onClick="window.open(this.href,\'\',\'width=700, height=800\'); return false;">'.$row[DNA_no].'</a></td>'; ?>
			 <td><?php echo str_replace($locus,$replace,$row[amel]); ?></td>
             <td><?php echo str_replace($locus0,$replace0,$row[th01]); ?></td>
			 <td><?php echo str_replace($locus1,$replace1,$row[tpox]); ?></td>
			 <td><?php echo str_replace($locus2,$replace2,$row[csf1po]); ?></td>
			 <td><?php echo str_replace($locus3,$replace3,$row[d3]); ?></td>
			 <td><?php echo str_replace($locus4,$replace4,$row[vwa]); ?></td>
			 <td><?php echo str_replace($locus5,$replace5,$row[fga]); ?></td>
			 <td><?php echo str_replace($locus6,$replace6,$row[d5]); ?></td>
			 <td><?php echo str_replace($locus7,$replace7,$row[d13]); ?></td>
			 <td><?php echo str_replace($locus8,$replace8,$row[d7]); ?></td>
			 <td><?php echo str_replace($locus9,$replace9,$row[d16]); ?></td>
			 <td><?php echo str_replace($locus10,$replace10,$row[d8]); ?></td>
			 <td><?php echo str_replace($locus11,$replace11,$row[d21]); ?></td>
			 <td><?php echo str_replace($locus12,$replace12,$row[d18]); ?></td>
			 <td><?php echo str_replace($locus13,$replace13,$row[d2]); ?></td>
			 <td><?php echo str_replace($locus14,$replace14,$row[d19]); ?></td>
			 <td><?php echo str_replace($locus15,$replace15,$row[pentae]); ?></td>
			 <td><?php echo str_replace($locus16,$replace16,$row[pentad]); ?></td>
			 <td><?php $match = "select DNA from profile, ystr where ystr.DNA ='".$row[DNA_no]."' and profile.DNA_no='".$row[DNA_no]."'";
				$matchResult = mysql_query($match);
				$matchRow=mysql_fetch_array($matchResult);
				if ($matchRow[DNA]){echo O;} else {echo X;}
				  ?>
			 </td>

		</tr>
	

<?php
	} // for


// RMP (Random Match Probability) ��� ����================================================
	if ($th01_a && $th01_b){
		// 2pq;
		$th01_cal = 2*$arr['korea']['th01'][$th01_a]*$arr['korea']['th01'][$th01_b];
	}elseif ($th01_a){
		// p^2
		$th01_cal = pow($arr['korea']['th01'][$th01_a],2) + $arr['korea']['th01'][$th01_a]*(1-$arr['korea']['th01'][$th01_a])*0.01;
		
	}elseif (!$th01_a && !$th01_b){
		$th01_cal = 1;
	}

	if ($tpox_a && $tpox_b){
		$tpox_cal = 2*$arr['korea']['tpox'][$tpox_a]*$arr['korea']['tpox'][$tpox_b];
	}elseif ($tpox_a){
		// p^2
		$tpox_cal = pow($arr['korea']['tpox'][$tpox_a],2) + $arr['korea']['tpox'][$tpox_a]*(1-$arr['korea']['tpox'][$tpox_a])*0.01;
	}elseif (!$tpox_a && !$tpox_b){
		$tpox_cal = 1;
	}

	if ($csf1po_a && $csf1po_b){
		//2pq;
		$csf1po_cal = 2*$arr['korea']['csf1po'][$csf1po_a]*$arr['korea']['csf1po'][$csf1po_b];
	}elseif ($csf1po_a){
		// p^2
		$csf1po_cal = pow($arr['korea']['csf1po'][$csf1po_a],2) + $arr['korea']['csf1po'][$csf1po_a]*(1-$arr['korea']['csf1po'][$csf1po_a])*0.01;
	}elseif (!$csf1po_a && !$csf1po_b){
		$csf1po_cal = 1;
	}

	if ($d3_a && $d3_b){
		//2pq;
		$d3_cal = 2*$arr['korea']['d3'][$d3_a]*$arr['korea']['d3'][$d3_b];
	}elseif ($d3_a){
		// p^2
		$d3_cal = pow($arr['korea']['d3'][$d3_a],2) + $arr['korea']['d3'][$d3_a]*(1-$arr['korea']['d3'][$d3_a])*0.01;
	}elseif (!$d3_a && !$d3_b){
		$d3_cal = 1;
	}
	
	if ($vwa_a && $vwa_b){
		//2pq
		$vwa_cal = 2*$arr['korea']['vwa'][$vwa_a]*$arr['korea']['vwa'][$vwa_b];
	}elseif ($vwa_a){
		// p^2
		$vwa_cal = pow($arr['korea']['vwa'][$vwa_a],2) + $arr['korea']['vwa'][$vwa_a]*(1-$arr['korea']['vwa'][$vwa_a])*0.01;
	}elseif (!$vwa_a && !$vwa_b){
		$vwa_cal = 1;
	}

	if ($fga_a && $fga_b){
		//2pq
		$fga_cal = 2*$arr['korea']['fga'][$fga_a]*$arr['korea']['fga'][$fga_b];
	}elseif ($fga_a){
		// p^2
		$fga_cal = pow($arr['korea']['fga'][$fga_a],2) + $arr['korea']['fga'][$fga_a]*(1-$arr['korea']['fga'][$fga_a])*0.01;
	}elseif (!$fga_a && !$fga_b){
		$fga_cal = 1;
	}

	if ($d5_a && $d5_b){
		//2pq
		$d5_cal = 2*$arr['korea']['d5'][$d5_a]*$arr['korea']['d5'][$d5_b];
	}elseif ($d5_a){
		// p^2
		$d5_cal = pow($arr['korea']['d5'][$d5_a],2) + $arr['korea']['d5'][$d5_a]*(1-$arr['korea']['d5'][$d5_a])*0.01;
	}elseif (!$d5_a && !$d5_b){
		$d5_cal = 1;
	}

	if ($d13_a && $d13_b){
		//2pq
		$d13_cal = 2*$arr['korea']['d13'][$d13_a]*$arr['korea']['d13'][$d13_b];
	}elseif ($d13_a){
		// p^2
		$d13_cal = pow($arr['korea']['d13'][$d13_a],2) + $arr['korea']['d13'][$d13_a] * (1-$arr['korea']['d13'][$d13_a])*0.01;
	}elseif (!$d13_a && !$d13_b){
		$d13_cal = 1;
	}

	if ($d7_a && $d7_b){
		//2pq
		$d7_cal = 2*$arr['korea']['d7'][$d7_a]*$arr['korea']['d7'][$d7_b];
	}elseif ($d7_a){
		// p^2
		$d7_cal = pow($arr['korea']['d7'][$d7_a],2) + $arr['korea']['d7'][$d7_a] * (1-$arr['korea']['d7'][$d7_a])*0.01;
	}elseif (!$d7_a && !$d7_b){
		$d7_cal = 1;
	}

	if ($d16_a && $d16_b){
		//2pq
		$d16_cal = 2*$arr['korea']['d16'][$d16_a]*$arr['korea']['d16'][$d16_b];
	}elseif ($d16_a){
		// p^2
		$d16_cal = pow($arr['korea']['d16'][$d16_a],2) + $arr['korea']['d16'][$d16_a]*(1-$arr['korea']['d16'][$d16_a])*0.01;
	}elseif (!$d16_a && !$d16_b){
		$d16_cal = 1;
	}

	if ($d8_a && $d8_b){
		//2pq
		$d8_cal = 2*$arr['korea']['d8'][$d8_a]*$arr['korea']['d8'][$d8_b];
	}elseif ($d8_a){
		// p^2
		$d8_cal = pow($arr['korea']['d8'][$d8_a],2) + $arr['korea']['d8'][$d8_a]*(1-$arr['korea']['d8'][$d8_a])*0.01;
	}elseif (!$d8_a && !$d8_b){
		$d8_cal = 1;
	}
	
	if ($d21_a && $d21_b){
		//2pq
		$d21_cal = 2*$arr['korea']['d21'][$d21_a]*$arr['korea']['d21'][$d21_b];
	}elseif ($d21_a){
		// p^2
		$d21_cal = pow($arr['korea']['d21'][$d21_a],2) + $arr['korea']['d21'][$d21_a]*(1-$arr['korea']['d21'][$d21_a])*0.01;
	}elseif (!$d21_a && !$d21_b){
		$d21_cal = 1;
	}

	if ($d18_a && $d18_b){
		//2pq
		$d18_cal = 2*$arr['korea']['d18'][$d18_a]*$arr['korea']['d18'][$d18_b];
	}elseif ($d18_a){
		// p^2
		$d18_cal = pow($arr['korea']['d18'][$d18_a],2) + $arr['korea']['d18'][$d18_a]*(1-$arr['korea']['d18'][$d18_a])*0.01;
	}elseif (!$d18_a && !$d18_b){
		$d18_cal = 1;
	}

	if ($d2_a && $d2_b){
		//2pq
		$d2_cal = 2*$arr['korea']['d2'][$d2_a]*$arr['korea']['d2'][$d2_b];
	}elseif ($d2_a){
		// p^2
		$d2_cal = pow($arr['korea']['d2'][$d2_a],2) + $arr['korea']['d2'][$d2_a]*(1-$arr['korea']['d2'][$d2_a])*0.01;
	}elseif (!$d2_a && !$d2_b){
		$d2_cal = 1;
	}
	
	if ($d19_a && $d19_b){
		$d19_cal = 2*$arr['korea']['d19'][$d19_a]*$arr['korea']['d19'][$d19_b];
	}elseif ($d19_a){
		// p^2
		$d19_cal = pow($arr['korea']['d19'][$d19_a],2) + $arr['korea']['d19'][$d19_a]*(1-$arr['korea']['d19'][$d19_a])*0.01;
	}elseif (!$d19_a && !$d19_b){
		$d19_cal = 1;
	}


		list($th,$tp,$csf,$d3,$vwa,$fga,$d5,$d13,$d7,$d16,$d8,$d21,$d18,$d2,$d19) = array($th01_cal, $tpox_cal,$csf1po_cal,$d3_cal,$vwa_cal,$fga_cal,$d5_cal,$d13_cal,$d7_cal,$d16_cal,$d8_cal,$d21_cal,$d18_cal,$d2_cal,$d19_cal);
		
		$rmp = $th*$tp*$csf*$d3*$vwa*$fga*$d5*$d13*$d7*$d16*$d8*$d21*$d8*$d21*$d18*$d2*$d19;
		$rever_rmp = (1/$th)*(1/$tp)*(1/$csf)*(1/$d3)*(1/$vwa)*(1/$fga)*(1/$d5)*(1/$d13)*(1/$d7)*(1/$d16)*(1/$d8)*(1/$d21)*(1/$d18)*(1/$d2)*(1/$d19);
// RMP (Random Match Probability) ��� ��================================================
		
?>


</table>
	<div>
	<p>
		<h4> Random Match Probability (RMP) :  <?php echo $rmp; ?> </h4><br />
		<h4> Likelihood Ratio (LR): <?php echo $rever_rmp; ?> </h4><br />
	<?php
		require ('footer.php');
	?>

	</div>

</div>


</body>
</html>
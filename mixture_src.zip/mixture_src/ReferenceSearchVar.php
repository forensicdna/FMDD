<?php
$D8S_a=$_POST['D8S_a'];
$D8S_b=$_POST['D8S_b'];
$D8S_c=$_POST['D8S_c'];
$D8S_d=$_POST['D8S_d'];

$D21S_a=$_POST['D21S_a']; 
$D21S_b=$_POST['D21S_b'];
$D21S_c=$_POST['D21S_c'];
$D21S_d=$_POST['D21S_d'];

$D7S_a=$_POST['D7S_a']; 
$D7S_b=$_POST['D7S_b'];
$D7S_c=$_POST['D7S_c'];
$D7S_d=$_POST['D7S_d'];

$CSF1PO_a=$_POST['CSF1PO_a']; 
$CSF1PO_b=$_POST['CSF1PO_b'];
$CSF1PO_c=$_POST['CSF1PO_c'];
$CSF1PO_d=$_POST['CSF1PO_d'];

$D3S_a=$_POST['D3S_a']; 
$D3S_b=$_POST['D3S_b'];
$D3S_c=$_POST['D3S_c'];
$D3S_d=$_POST['D3S_d'];

$TH01_a=$_POST['TH01_a']; 
$TH01_b=$_POST['TH01_b'];
$TH01_c=$_POST['TH01_c'];
$TH01_d=$_POST['TH01_d'];

$D13S_a=$_POST['D13S_a']; 
$D13S_b=$_POST['D13S_b'];
$D13S_c=$_POST['D13S_c'];
$D13S_d=$_POST['D13S_d'];

$D16S_a=$_POST['D16S_a']; 
$D16S_b=$_POST['D16S_b'];
$D16S_c=$_POST['D16S_c'];
$D16S_d=$_POST['D16S_d'];

$D2S_a=$_POST['D2S_a']; 
$D2S_b=$_POST['D2S_b'];
$D2S_c=$_POST['D2S_c'];
$D2S_d=$_POST['D2S_d'];

$D19S_a=$_POST['D19S_a']; 
$D19S_b=$_POST['D19S_b'];
$D19S_c=$_POST['D19S_c'];
$D19S_d=$_POST['D19S_d'];

$vWA_a=$_POST['vWA_a']; 
$vWA_b=$_POST['vWA_b'];
$vWA_c=$_POST['vWA_c'];
$vWA_d=$_POST['vWA_d'];

$TPOX_a=$_POST['TPOX_a']; 
$TPOX_b=$_POST['TPOX_b'];
$TPOX_c=$_POST['TPOX_c'];
$TPOX_d=$_POST['TPOX_d'];

$D18S_a=$_POST['D18S_a']; 
$D18S_b=$_POST['D18S_b'];
$D18S_c=$_POST['D18S_c'];
$D18S_d=$_POST['D18S_d'];

$AMEL_a=$_POST['AMEL_a']; 
$AMEL_b=$_POST['AMEL_b'];
$AMEL_c=$_POST['AMEL_c'];
$AMEL_d=$_POST['AMEL_d'];

$D5S_a=$_POST['D5S_a']; 
$D5S_b=$_POST['D5S_b'];
$D5S_c=$_POST['D5S_c'];
$D5S_d=$_POST['D5S_d'];

$FGA_a=$_POST['FGA_a']; 
$FGA_b=$_POST['FGA_b'];
$FGA_c=$_POST['FGA_c'];
$FGA_d=$_POST['FGA_d'];
				

// trim
$D8S_a=trim($D8S_a);
$D8S_b=trim($D8S_b);
$D8S_c=trim($D8S_c);
$D8S_d=trim($D8S_d);

$D21S_a=trim($D21S_a); 
$D21S_b=trim($D21S_b);
$D21S_c=trim($D21S_c);
$D21S_d=trim($D21S_d);

$D7S_a=trim($D7S_a); 
$D7S_b=trim($D7S_b);
$D7S_c=trim($D7S_c);
$D7S_d=trim($D7S_d);

$CSF1PO_a=trim($CSF1PO_a); 
$CSF1PO_b=trim($CSF1PO_b);
$CSF1PO_c=trim($CSF1PO_c);
$CSF1PO_d=trim($CSF1PO_d);

$D3S_a=trim($D3S_a); 
$D3S_b=trim($D3S_b);
$D3S_c=trim($D3S_c);
$D3S_d=trim($D3S_d);

$TH01_a=trim($TH01_a); 
$TH01_b=trim($TH01_b);
$TH01_c=trim($TH01_c);
$TH01_d=trim($TH01_d);

$D13S_a=trim($D13S_a); 
$D13S_b=trim($D13S_b);
$D13S_c=trim($D13S_c);
$D13S_d=trim($D13S_d);

$D16S_a=trim($D16S_a); 
$D16S_b=trim($D16S_b);
$D16S_c=trim($D16S_c);
$D16S_d=trim($D16S_d);

$D2S_a=trim($D2S_a); 
$D2S_b=trim($D2S_b);
$D2S_c=trim($D2S_c);
$D2S_d=trim($D2S_d);

$D19S_a=trim($D19S_a); 
$D19S_b=trim($D19S_b);
$D19S_c=trim($D19S_c);
$D19S_d=trim($D19S_d);

$vWA_a=trim($vWA_a); 
$vWA_b=trim($vWA_b);
$vWA_c=trim($vWA_c);
$vWA_d=trim($vWA_d);

$TPOX_a=trim($TPOX_a); 
$TPOX_b=trim($TPOX_b);
$TPOX_c=trim($TPOX_c);
$TPOX_d=trim($TPOX_d);

$D18S_a=trim($D18S_a); 
$D18S_b=trim($D18S_b);
$D18S_c=trim($D18S_c);
$D18S_d=trim($D18S_d);

$AMEL_a=trim($AMEL_a); 
$AMEL_b=trim($AMEL_b);
$AMEL_c=trim($AMEL_c);
$AMEL_d=trim($AMEL_d);

$D5S_a=trim($D5S_a); 
$D5S_b=trim($D5S_b);
$D5S_c=trim($D5S_c);
$D5S_d=trim($D5S_d);

$FGA_a=trim($FGA_a); 
$FGA_b=trim($FGA_b);
$FGA_c=trim($FGA_c);
$FGA_d=trim($FGA_d);
?>

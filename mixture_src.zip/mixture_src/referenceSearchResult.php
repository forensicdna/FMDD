<html>
<head>
	<title> FMDD </title>
	<style type="text/css">
	body {
		font-family : sans-serif;
	/*	font-size : 10 px; */
	}
	table {
		border : thin solid black;
		border-collapse : collapse; 
		font-family : sans-serif;
		font-size : 11 px;
		border-spacing: 0px;
		table-layout: fixed; 
		vertical-align: center;

	}
	th {
		border: 1px solid gray;
		text-align: center;
		vertical-align: center;
		padding-right: 1px;
		height: auto;
		background-color: #fcba7a;
	}
	td {
		border: 1px solid gray;
		text-align: center;
		vertical-align: center;
		padding-bottom: 13px;
		word-break: break-all;
		height: auto;
	}
	
	</style>
</head>
<body>

<?php
	require('dbConnect.php');
	require('ReferenceSearchVar.php');
	require('head.php');
	include('STRfunction/D8S1179STR.php');
	include('STRfunction/D21S11STR.php');
	include('STRfunction/D7S820STR.php');
	include('STRfunction/CSF1POSTR.php');
	include('STRfunction/D3S1358STR.php');
	include('STRfunction/TH01STR.php');
	include('STRfunction/D13S317STR.php');
	include('STRfunction/D16S539STR.php');
	include('STRfunction/D2S1338STR.php');
	include('STRfunction/D19S433STR.php');
	include('STRfunction/VWASTR.php');
	include('STRfunction/TPOXSTR.php');
	include('STRfunction/D18S51STR.php');
	include('STRfunction/AMELSTR.php');
	include('STRfunction/D5S818STR.php');
	include('STRfunction/FGASTR.php');
	
?>	


<div id="pagecell1"> 
  <!--pagecell1--> 
	  <img alt="" src="tl_curve_white.gif" height="6" width="6" id="tl" /> 
	  <img alt="" src="tr_curve_white.gif" height="6" width="6" id="tr" /> 
	  <div> 
		&nbsp;
	  </div> 
	  <div id="pageName"> 
		<h2>Search Results </h2> 
	  </div> 
	   <input type="button" value="Go Search" title="Go back to Search Page" onclick="window.location='search2reference.php'">
	  <div class="story">
	
<?php

	if (!$D8S_a && !$D8S_b && !$D8S_c && !$D8S_d && 
!$D21S_a && !$D21S_b && !$D21S_c && !$D21S_d && 
!$D7S_a && !$D7S_b && !$D7S_c && !$D7S_d && 
!$CSF1PO_a && !$CSF1PO_b && !$CSF1PO_c && !$CSF1PO_d && 
!$D3S_a && !$D3S_b && !$D3S_c && !$D3S_d && 
!$TH01_a && !$TH01_b && !$TH01_c && !$TH01_d && 
!$D13S_a && !$D13S_b && !$D13S_c && !$D13S_d && 
!$D16S_a && !$D16S_b && !$D16S_c && !$D16S_d && 
!$D2S_a && !$D2S_b && !$D2S_c && !$D2S_d && 
!$D19S_a && !$D19S_b && !$D19S_c && !$D19S_d && 
!$vWA_a && !$vWA_b && !$vWA_c && !$vWA_d && 
!$TPOX_a && !$TPOX_b && !$TPOX_c && !$TPOX_d && 
!$D18S_a && !$D18S_b && !$D18S_c && !$D18S_d && 
!$AMEL_a && !$AMEL_b && !$AMEL_c && !$AMEL_d && 
!$D5S_a && !$D5S_b && !$D5S_c && !$D5S_d && 
!$FGA_a && !$FGA_b && !$FGA_c && !$FGA_d)
		{
				echo 'You have not entered any profiles'.'<p>';
				exit;
		}
?>	 

	 <table align="center" width='95.8%'>
					<tr>
						<th>  </th>
						<th> DNA <br>Number </th>
						<th> D8S1179</th>
						<th> D21S11</th>
						<th> D7S820</th>
						<th> CSF1PO </th>
						<th> D3S1358 </th>
						<th> TH01</th>
						<th> D13S317</th>
						<th> D16S539</th>
						<th> D2S1338</th>
						<th> D19S433</th>
						<th> vWA</th>
						<th> TPOX</th>
						<th> D18S51</th>
						<th> Amel</th>
						<th> D5S818</th>
						<th> FGA</th>
					</tr>
					<tr>
						<td> Query </td>
						<td> Mannual </td>
						<td> <?php if ($D8S_a && !$D8S_b && !$D8S_c && !$D8S_d){
										echo $D8S_a;
									} elseif ($D8S_a && $D8S_b && !$D8S_c && !$D8S_d){
										echo $D8S_a.",".$D8S_b;
									} elseif ($D8S_a && $D8S_b && $D8S_c && !$D8S_d){
										echo $D8S_a.",".$D8S_b.","."<br>".$D8S_c;
									} elseif ($D8S_a && $D8S_b && $D8S_c && $D8S_d){
										echo $D8S_a.",".$D8S_b.","."<br>".$D8S_c.",".$D8S_d;
									}
							?> 
						</td>
						<td> <?php if ($D21S_a && !$D21S_b && !$D21S_c && !$D21S_d){
										echo $D21S_a;
									} elseif ($D21S_a && $D21S_b && !$D21S_c && !$D21S_d){
										echo $D21S_a.",".$D21S_b;
									} elseif ($D21S_a && $D21S_b && $D21S_c && !$D21S_d){
										echo $D21S_a.",".$D21S_b.","."<br>".$D21S_c;
									} elseif ($D21S_a && $D21S_b && $D21S_c && $D21S_d){
										echo $D21S_a.",".$D21S_b.","."<br>".$D21S_c.",".$D21S_d;
									}
							?> 
						</td>
						<td> <?php if ($D7S_a && !$D7S_b && !$D7S_c && !$D7S_d){
										echo $D7S_a;
									} elseif ($D7S_a && $D7S_b && !$D7S_c && !$D7S_d){
										echo $D7S_a.",".$D7S_b;
									} elseif ($D7S_a && $D7S_b && $D7S_c && !$D7S_d){
										echo $D7S_a.",".$D7S_b.","."<br>".$D7S_c;
									} elseif ($D7S_a && $D7S_b && $D7S_c && $D7S_d){
										echo $D7S_a.",".$D7S_b.","."<br>".$D7S_c.",".$D7S_d;
									}
							?>
						</td>
						<td> <?php if ($CSF1PO_a && !$CSF1PO_b && !$CSF1PO_c && !$CSF1PO_d){
										echo $CSF1PO_a;
									} elseif ($CSF1PO_a && $CSF1PO_b && !$CSF1PO_c && !$CSF1PO_d){
										echo $CSF1PO_a.",".$CSF1PO_b;
									} elseif ($CSF1PO_a && $CSF1PO_b && $CSF1PO_c && !$CSF1PO_d){
										echo $CSF1PO_a.",".$CSF1PO_b.","."<br>".$CSF1PO_c;
									} elseif ($CSF1PO_a && $CSF1PO_b && $CSF1PO_c && $CSF1PO_d){
										echo $CSF1PO_a.",".$CSF1PO_b.","."<br>".$CSF1PO_c.",".$CSF1PO_d;
									}
							?> 
						</td>
						<td> <?php if ($D3S_a && !$D3S_b && !$D3S_c && !$D3S_d){
										echo $D3S_a;
									} elseif ($D3S_a && $D3S_b && !$D3S_c && !$D3S_d){
										echo $D3S_a.",".$D3S_b;
									} elseif ($D3S_a && $D3S_b && $D3S_c && !$D3S_d){
										echo $D3S_a.",".$D3S_b.","."<br>".$D3S_c;
									} elseif ($D3S_a && $D3S_b && $D3S_c && $D3S_d){
										echo $D3S_a.",".$D3S_b.","."<br>".$D3S_c.",".$D3S_d;
									}
							?>  
						</td>
						<td> <?php if ($TH01_a && !$TH01_b && !$TH01_c && !$TH01_d){
										echo $TH01_a;
									} elseif ($TH01_a && $TH01_b && !$TH01_c && !$TH01_d){
										echo $TH01_a.",".$TH01_b;
									} elseif ($TH01_a && $TH01_b && $TH01_c && !$TH01_d){
										echo $TH01_a.",".$TH01_b.","."<br>".$TH01_c;
									} elseif ($TH01_a && $TH01_b && $TH01_c && $TH01_d){
										echo $TH01_a.",".$TH01_b.","."<br>".$TH01_c.",".$TH01_d;
									}
							?> 
						</td>
						<td> <?php if ($D13S_a && !$D13S_b && !$D13S_c && !$D13S_d){
										echo $D13S_a;
									} elseif ($D13S_a && $D13S_b && !$D13S_c && !$D13S_d){
										echo $D13S_a.",".$D13S_b;
									} elseif ($D13S_a && $D13S_b && $D13S_c && !$D13S_d){
										echo $D13S_a.",".$D13S_b.","."<br>".$D13S_c;
									} elseif ($D13S_a && $D13S_b && $D13S_c && $D13S_d){
										echo $D13S_a.",".$D13S_b.","."<br>".$D13S_c.",".$D13S_d;
									}
							?>  
						</td>
						<td> <?php if ($D16S_a && !$D16S_b && !$D16S_c && !$D16S_d){
										echo $D16S_a;
									} elseif ($D16S_a && $D16S_b && !$D16S_c && !$D16S_d){
										echo $D16S_a.",".$D16S_b;
									} elseif ($D16S_a && $D16S_b && $D16S_c && !$D16S_d){
										echo $D16S_a.",".$D16S_b.","."<br>".$D16S_c;
									} elseif ($D16S_a && $D16S_b && $D16S_c && $D16S_d){
										echo $D16S_a.",".$D16S_b.","."<br>".$D16S_c.",".$D16S_d;
									}
							?> 
						</td>
						<td> <?php if ($D2S_a && !$D2S_b && !$D2S_c && !$D2S_d){
										echo $D2S_a;
									} elseif ($D2S_a && $D2S_b && !$D2S_c && !$D2S_d){
										echo $D2S_a.",".$D2S_b;
									} elseif ($D2S_a && $D2S_b && $D2S_c && !$D2S_d){
										echo $D2S_a.",".$D2S_b.","."<br>".$D2S_c;
									} elseif ($D2S_a && $D2S_b && $D2S_c && $D2S_d){
										echo $D2S_a.",".$D2S_b.","."<br>".$D2S_c.",".$D2S_d;
									}
							?> 
						</td>
						<td> <?php if ($D19S_a && !$D19S_b && !$D19S_c && !$D19S_d){
										echo $D19S_a;
									} elseif ($D19S_a && $D19S_b && !$D19S_c && !$D19S_d){
										echo $D19S_a.",".$D19S_b;
									} elseif ($D19S_a && $D19S_b && $D19S_c && !$D19S_d){
										echo $D19S_a.",".$D19S_b.","."<br>".$D19S_c;
									} elseif ($D19S_a && $D19S_b && $D19S_c && $D19S_d){
										echo $D19S_a.",".$D19S_b.","."<br>".$D19S_c.",".$D19S_d;
									}
							?> 
						</td>
						<td> <?php if ($vWA_a && !$vWA_b && !$vWA_c && !$vWA_d){
										echo $vWA_a;
									} elseif ($vWA_a && $vWA_b && !$vWA_c && !$vWA_d){
										echo $vWA_a.",".$vWA_b;
									} elseif ($vWA_a && $vWA_b && $vWA_c && !$vWA_d){
										echo $vWA_a.",".$vWA_b.","."<br>".$vWA_c;
									} elseif ($vWA_a && $vWA_b && $vWA_c && $vWA_d){
										echo $vWA_a.",".$vWA_b.","."<br>".$vWA_c.",".$vWA_d;
									}
							?> 
						</td>
						<td> <?php if ($TPOX_a && !$TPOX_b && !$TPOX_c && !$TPOX_d){
										echo $TPOX_a;
									} elseif ($TPOX_a && $TPOX_b && !$TPOX_c && !$TPOX_d){
										echo $TPOX_a.",".$TPOX_b;
									} elseif ($TPOX_a && $TPOX_b && $TPOX_c && !$TPOX_d){
										echo $TPOX_a.",".$TPOX_b.","."<br>".$TPOX_c;
									} elseif ($TPOX_a && $TPOX_b && $TPOX_c && $TPOX_d){
										echo $TPOX_a.",".$TPOX_b.","."<br>".$TPOX_c.",".$TPOX_d;
									}
							?> 
						</td>
						<td> <?php if ($D18S_a && !$D18S_b && !$D18S_c && !$D18S_d){
										echo $D18S_a;
									} elseif ($D18S_a && $D18S_b && !$D18S_c && !$D18S_d){
										echo $D18S_a.",".$D18S_b;
									} elseif ($D18S_a && $D18S_b && $D18S_c && !$D18S_d){
										echo $D18S_a.",".$D18S_b.","."<br>".$D18S_c;
									} elseif ($D18S_a && $D18S_b && $D18S_c && $D18S_d){
										echo $D18S_a.",".$D18S_b.","."<br>".$D18S_c.",".$D18S_d;
									}
							?> 
						</td>
						<td> <?php if ($AMEL_a && !$AMEL_b && !$AMEL_c && !$AMEL_d){
										echo $AMEL_a;
									} elseif ($AMEL_a && $AMEL_b && !$AMEL_c && !$AMEL_d){
										echo $AMEL_a.",".$AMEL_b;
									} elseif ($AMEL_a && $AMEL_b && $AMEL_c && !$AMEL_d){
										echo $AMEL_a.",".$AMEL_b.","."<br>".$AMEL_c;
									} elseif ($AMEL_a && $AMEL_b && $AMEL_c && $AMEL_d){
										echo $AMEL_a.",".$AMEL_b.","."<br>".$AMEL_c.",".$AMEL_d;
									}
							?> 
						</td>
						<td> <?php if ($D5S_a && !$D5S_b && !$D5S_c && !$D5S_d){
										echo $D5S_a;
									} elseif ($D5S_a && $D5S_b && !$D5S_c && !$D5S_d){
										echo $D5S_a.",".$D5S_b;
									} elseif ($D5S_a && $D5S_b && $D5S_c && !$D5S_d){
										echo $D5S_a.",".$D5S_b.","."<br>".$D5S_c;
									} elseif ($D5S_a && $D5S_b && $D5S_c && $D5S_d){
										echo $D5S_a.",".$D5S_b.","."<br>".$D5S_c.",".$D5S_d;
									}
							?> 
						</td>
						<td> <?php if ($FGA_a && !$FGA_b && !$FGA_c && !$FGA_d){
										echo $FGA_a;
									} elseif ($FGA_a && $FGA_b && !$FGA_c && !$FGA_d){
										echo $FGA_a.",".$FGA_b;
									} elseif ($FGA_a && $FGA_b && $FGA_c && !$FGA_d){
										echo $FGA_a.",".$FGA_b.","."<br>".$FGA_c;
									} elseif ($FGA_a && $FGA_b && $FGA_c && $FGA_d){
										echo $FGA_a.",".$FGA_b.","."<br>".$FGA_c.",".$FGA_d;
									}
							?> 
						</td>
					</tr>


<?php
//D8S1179 �� ȥ���� �˻�
if ($D8S_a && $D8S_b && $D8S_c && $D8S_d){
	$sql1=D8all($D8S_a, $D8S_b, $D8S_c, $D8S_d);
} elseif ($D8S_a && $D8S_b && $D8S_c && !$D8S_d){
	$sql1=D8three($D8S_a, $D8S_b, $D8S_c);
} elseif ($D8S_a && $D8S_b && !$D8S_c && !$D8S_d){
	$sql1=D8two($D8S_a, $D8S_b);
} elseif ($D8S_a && !$D8S_b && !$D8S_c && !$D8S_d){
	$sql1=D8one($D8S_a);
} elseif (!$D8S_a && !$D8S_b && !$D8S_c && !$D8S_d){
	$sql1="((D8S1179_1 like '%$D8S_a%$D8S_b%$D8S_c%$D8S_d%' AND D8S1179_2 like '%$D8S_a%$D8S_b%$D8S_c%$D8S_d%'))";
}

//D21S11 �� ȥ���� �˻�
if ($D21S_a && $D21S_b && $D21S_c && $D21S_d){
	$sql2=D21all($D21S_a, $D21S_b, $D21S_c, $D21S_d);
} elseif ($D21S_a && $D21S_b && $D21S_c && !$D21S_d){
	$sql2=D21three($D21S_a, $D21S_b, $D21S_c);
} elseif ($D21S_a && $D21S_b && !$D21S_c && !$D21S_d){
	$sql2=D21two($D21S_a, $D21S_b);
} elseif ($D21S_a && !$D21S_b && !$D21S_c && !$D21S_d){
	$sql2=D21one($D21S_a);
} elseif (!$D21S_a && !$D21S_b && !$D21S_c && !$D21S_d){
	$sql2="((D21S11_1 like '%$D21S_a%$D21S_b%$D21S_c%$D21S_d%' and D21S11_2 like '%$D21S_a%$D21S_b%$D21S_c%$D21S_d%'))";
}

//D7S820 �� ȥ���� �˻�
if ($D7S_a && $D7S_b && $D7S_c && $D7S_d){
	$sql3=D7all($D7S_a, $D7S_b, $D7S_c, $D7S_d);
} elseif ($D7S_a && $D7S_b && $D7S_c && !$D7S_d){
	$sql3=D7three($D7S_a, $D7S_b, $D7S_c);
} elseif ($D7S_a && $D7S_b && !$D7S_c && !$D7S_d){
	$sql3=D7two($D7S_a, $D7S_b);
} elseif ($D7S_a && !$D7S_b && !$D7S_c && !$D7S_d){
	$sql3=D7one($D7S_a);
} elseif (!$D7S_a && !$D7S_b && !$D7S_c && !$D7S_d){
	$sql3="((D7S820_1 like '%$D7S_a%$D7S_b%$D7S_c%$D7S_d%' and D7S820_2 like '%$D7S_a%$D7S_b%$D7S_c%$D7S_d%'))";
}

//CSF1PO �� ȥ���� �˻�
if ($CSF1PO_a && $CSF1PO_b && $CSF1PO_c && $CSF1PO_d){
	$sql4=CSF1POall($CSF1PO_a, $CSF1PO_b, $CSF1PO_c, $CSF1PO_d);
} elseif ($CSF1PO_a && $CSF1PO_b && $CSF1PO_c && !$CSF1PO_d){
	$sql4=CSF1POthree($CSF1PO_a, $CSF1PO_b, $CSF1PO_c);
} elseif ($CSF1PO_a && $CSF1PO_b && !$CSF1PO_c && !$CSF1PO_d){
	$sql4=CSF1POtwo($CSF1PO_a, $CSF1PO_b);
} elseif ($CSF1PO_a && !$CSF1PO_b && !$CSF1PO_c && !$CSF1PO_d){
	$sql4=CSF1POone($CSF1PO_a);
} elseif (!$CSF1PO_a && !$CSF1PO_b && !$CSF1PO_c && !$CSF1PO_d){
	$sql4="((CSF1PO_1 like '%$CSF1PO_a%$CSF1PO_b%$CSF1PO_c%$CSF1PO_d%' and CSF1PO_2 like '%$CSF1PO_a%$CSF1PO_b%$CSF1PO_c%$CSF1PO_d%'))";
}

//D3S1358 �� ȥ���� �˻�
if ($D3S_a && $D3S_b && $D3S_c && $D3S_d){
	$sql5=D3all($D3S_a, $D3S_b, $D3S_c, $D3S_d);
} elseif ($D3S_a && $D3S_b && $D3S_c && !$D3S_d){
	$sql5=D3three($D3S_a, $D3S_b, $D3S_c);
} elseif ($D3S_a && $D3S_b && !$D3S_c && !$D3S_d){
	$sql5=D3two($D3S_a, $D3S_b);
} elseif ($D3S_a && !$D3S_b && !$D3S_c && !$D3S_d){
	$sql5=D3one($D3S_a);
} elseif (!$D3S_a && !$D3S_b && !$D3S_c && !$D3S_d){
	$sql5="((D3S1358_1 like '%$D3S_a%$D3S_b%$D3S_c%$D3S_d%' and D3S1358_2 like '%$D3S_a%$D3S_b%$D3S_c%$D3S_d%'))";
}

//TH01 �� ȥ���� �˻�
if ($TH01_a && $TH01_b && $TH01_c && $TH01_d){
	$sql6=TH01all($TH01_a, $TH01_b, $TH01_c, $TH01_d);
} elseif ($TH01_a && $TH01_b && $TH01_c && !$TH01_d){
	$sql6=TH01three($TH01_a, $TH01_b, $TH01_c);
} elseif ($TH01_a && $TH01_b && !$TH01_c && !$TH01_d){
	$sql6=TH01two($TH01_a, $TH01_b);
} elseif ($TH01_a && !$TH01_b && !$TH01_c && !$TH01_d){
	$sql6=TH01one($TH01_a);
} elseif (!$TH01_a && !$TH01_b && !$TH01_c && !$TH01_d){
	$sql6="((TH01_1 like '%$TH01_a%$TH01_b%$TH01_c%$TH01_d%' and TH01_2 like '%$TH01_a%$TH01_b%$TH01_c%$TH01_d%'))";
}

//D13S317 �� ȥ���� �˻�
if ($D13S_a && $D13S_b && $D13S_c && $D13S_d){
	$sql7=D13all($D13S_a, $D13S_b, $D13S_c, $D13S_d);
} elseif ($D13S_a && $D13S_b && $D13S_c && !$D13S_d){
	$sql7=D13three($D13S_a, $D13S_b, $D13S_c);
} elseif ($D13S_a && $D13S_b && !$D13S_c && !$D13S_d){
	$sql7=D13two($D13S_a, $D13S_b);
} elseif ($D13S_a && !$D13S_b && !$D13S_c && !$D13S_d){
	$sql7=D13one($D13S_a);
} elseif (!$D13S_a && !$D13S_b && !$D13S_c && !$D13S_d){
	$sql7="((D13S317_1 like '%$D13S_a%$D13S_b%$D13S_c%$D13S_d%' and D13S317_2 like '%$D13S_a%$D13S_b%$D13S_c%$D13S_d%'))";
}

//D16S539 �� ȥ���� �˻�
if ($D16S_a && $D16S_b && $D16S_c && $D16S_d){
	$sql8=D16all($D16S_a, $D16S_b, $D16S_c, $D16S_d);
} elseif ($D16S_a && $D16S_b && $D16S_c && !$D16S_d){
	$sql8=D16three($D16S_a, $D16S_b, $D16S_c);
} elseif ($D16S_a && $D16S_b && !$D16S_c && !$D16S_d){
	$sql8=D16two($D16S_a, $D16S_b);
} elseif ($D16S_a && !$D16S_b && !$D16S_c && !$D16S_d){
	$sql8=D16one($D16S_a);
} elseif (!$D16S_a && !$D16S_b && !$D16S_c && !$D16S_d){
	$sql8="((D16S539_1 like '%$D16S_a%$D16S_b%$D16S_c%$D16S_d%' and D16S539_2 like '%$D16S_a%$D16S_b%$D16S_c%$D16S_d%'))";
}

//D2S1338 �� ȥ���� �˻�
if ($D2S_a && $D2S_b && $D2S_c && $D2S_d){
	$sql9=D2all($D2S_a, $D2S_b, $D2S_c, $D2S_d);
} elseif ($D2S_a && $D2S_b && $D2S_c && !$D2S_d){
	$sql9=D2three($D2S_a, $D2S_b, $D2S_c);
} elseif ($D2S_a && $D2S_b && !$D2S_c && !$D2S_d){
	$sql9=D2two($D2S_a, $D2S_b);
} elseif ($D2S_a && !$D2S_b && !$D2S_c && !$D2S_d){
	$sql9=D2one($D2S_a);
} elseif (!$D2S_a && !$D2S_b && !$D2S_c && !$D2S_d){
	$sql9="((D2S1338_1 like '%$D2S_a%$D2S_b%$D2S_c%$D2S_d%' and D2S1338_2 like '%$D2S_a%$D2S_b%$D2S_c%$D2S_d%'))";
}

//D19S433 �� ȥ���� �˻�
if ($D19S_a && $D19S_b && $D19S_c && $D19S_d){
	$sql10=D19all($D19S_a, $D19S_b, $D19S_c, $D19S_d);
} elseif ($D19S_a && $D19S_b && $D19S_c && !$D19S_d){
	$sql10=D19three($D19S_a, $D19S_b, $D19S_c);
} elseif ($D19S_a && $D19S_b && !$D19S_c && !$D19S_d){
	$sql10=D19two($D19S_a, $D19S_b);
} elseif ($D19S_a && !$D19S_b && !$D19S_c && !$D19S_d){
	$sql10=D19one($D19S_a);
} elseif (!$D19S_a && !$D19S_b && !$D19S_c && !$D19S_d){
	$sql10="((D19S433_1 like '%$D19S_a%$D19S_b%$D19S_c%$D19S_d%' and D19S433_2 like '%$D19S_a%$D19S_b%$D19S_c%$D19S_d%'))";
}

//vWA�� ȥ���� �˻�
if ($vWA_a && $vWA_b && $vWA_c && $vWA_d){
	$sql11=vWAall($vWA_a, $vWA_b, $vWA_c, $vWA_d);
} elseif ($vWA_a && $vWA_b && $vWA_c && !$vWA_d){
	$sql11=vWAthree($vWA_a, $vWA_b, $vWA_c);
} elseif ($vWA_a && $vWA_b && !$vWA_c && !$vWA_d){
	$sql11=vWAtwo($vWA_a, $vWA_b);
} elseif ($vWA_a && !$vWA_b && !$vWA_c && !$vWA_d){
	$sql11=vWAone($vWA_a);
} elseif (!$vWA_a && !$vWA_b && !$vWA_c && !$vWA_d){
	$sql11="((VWA_1 like '%$vWA_a%$vWA_b%$vWA_c%$vWA_d%' and VWA_2 like '%$vWA_a%$vWA_b%$vWA_c%$vWA_d%'))";
}

//TPOX�� ȥ���� �˻�
if ($TPOX_a && $TPOX_b && $TPOX_c && $TPOX_d){
	$sql12=TPOXall($TPOX_a, $TPOX_b, $TPOX_c, $TPOX_d);
} elseif ($TPOX_a && $TPOX_b && $TPOX_c && !$TPOX_d){
	$sql12=TPOXthree($TPOX_a, $TPOX_b, $TPOX_c);
} elseif ($TPOX_a && $TPOX_b && !$TPOX_c && !$TPOX_d){
	$sql12=TPOXtwo($TPOX_a, $TPOX_b);
} elseif ($TPOX_a && !$TPOX_b && !$TPOX_c && !$TPOX_d){
	$sql12=TPOXone($TPOX_a);
} elseif (!$TPOX_a && !$TPOX_b && !$TPOX_c && !$TPOX_d){
	$sql12="((TPOX_1 like '%$TPOX_a%$TPOX_b%$TPOX_c%$TPOX_d%' and TPOX_2 like '%$TPOX_a%$TPOX_b%$TPOX_c%$TPOX_d%'))";
}


//D18S51�� ȥ���� �˻�
if ($D18S_a && $D18S_b && $D18S_c && $D18S_d){
	$sql13=D18all($D18S_a, $D18S_b, $D18S_c, $D18S_d);
} elseif ($D18S_a && $D18S_b && $D18S_c && !$D18S_d){
	$sql13=D18three($D18S_a, $D18S_b, $D18S_c);
} elseif ($D18S_a && $D18S_b && !$D18S_c && !$D18S_d){
	$sql13=D18two($D18S_a, $D18S_b);
} elseif ($D18S_a && !$D18S_b && !$D18S_c && !$D18S_d){
	$sql13=D18one($D18S_a);
} elseif (!$D18S_a && !$D18S_b && !$D18S_c && !$D18S_d){
	$sql13="((D18S51_1 like '%$D18S_a%$D18S_b%$D18S_c%$D18S_d%' and D18S51_2 like '%$D18S_a%$D18S_b%$D18S_c%$D18S_d%'))";
}

//AMEL�� ȥ���� �˻�
if ($AMEL_a && $AMEL_b && $AMEL_c && $AMEL_d){
	$sql14=AMELall($AMEL_a, $AMEL_b, $AMEL_c, $AMEL_d);
} elseif ($AMEL_a && $AMEL_b && $AMEL_c && !$AMEL_d){
	$sql14=AMELthree($AMEL_a, $AMEL_b, $AMEL_c);
} elseif ($AMEL_a && $AMEL_b && !$AMEL_c && !$AMEL_d){
	$sql14=AMELtwo($AMEL_a, $AMEL_b);
} elseif ($AMEL_a && !$AMEL_b && !$AMEL_c && !$AMEL_d){
	$sql14=AMELone($AMEL_a);
} elseif (!$AMEL_a && !$AMEL_b && !$AMEL_c && !$AMEL_d){
	$sql14="((AMEL_1 like '%$AMEL_a%$AMEL_b%$AMEL_c%$AMEL_d%' and AMEL_2 like '%$AMEL_a%$AMEL_b%$AMEL_c%$AMEL_d%'))";
}


//D5S818�� ȥ���� �˻�
if ($D5S_a && $D5S_b && $D5S_c && $D5S_d){
	$sql15=D5all($D5S_a, $D5S_b, $D5S_c, $D5S_d);
} elseif ($D5S_a && $D5S_b && $D5S_c && !$D5S_d){
	$sql15=D5three($D5S_a, $D5S_b, $D5S_c);
} elseif ($D5S_a && $D5S_b && !$D5S_c && !$D5S_d){
	$sql15=D5two($D5S_a, $D5S_b);
} elseif ($D5S_a && !$D5S_b && !$D5S_c && !$D5S_d){
	$sql15=D5one($D5S_a);
} elseif (!$D5S_a && !$D5S_b && !$D5S_c && !$D5S_d){
	$sql15="((D5S818_1 like '%$D5S_a%$D5S_b%$D5S_c%$D5S_d%' and D5S818_2 like '%$D5S_a%$D5S_b%$D5S_c%$D5S_d%'))";
}

//FGA�� ȥ���� �˻�
if ($FGA_a && $FGA_b && $FGA_c && $FGA_d){
	$sql16=FGAall($FGA_a, $FGA_b, $FGA_c, $FGA_d);
} elseif ($FGA_a && $FGA_b && $FGA_c && !$FGA_d){
	$sql16=FGAthree($FGA_a, $FGA_b, $FGA_c);
} elseif ($FGA_a && $FGA_b && !$FGA_c && !$FGA_d){
	$sql16=FGAtwo($FGA_a, $FGA_b);
} elseif ($FGA_a && !$FGA_b && !$FGA_c && !$FGA_d){
	$sql16=FGAone($FGA_a);
} elseif (!$FGA_a && !$FGA_b && !$FGA_c && !$FGA_d){
	$sql16="((FGA_1 like '%$FGA_a%$FGA_b%$FGA_c%$FGA_d%' and FGA_2 like '%$FGA_a%$FGA_b%$FGA_c%$FGA_d%'))";
}

//���� SQL�� �ϼ�
$sql= "SELECT * FROM reference where".$sql1.' and '.$sql2.' and '.$sql3.' and '.$sql4.' and '.$sql5.' and '.$sql6.' and '.$sql7.' and '.$sql8.' and '.$sql9.' and '.$sql10.' and '.$sql11.' and '.$sql12.' and '.$sql13.' and '.$sql14.' and '.$sql15.' and '.$sql16;
//echo $sql;

	$result = mysql_query($sql);
	$numRow=mysql_num_rows($result);

	for ($i=0; $i<$numRow; $i++){
		$row=mysql_fetch_array($result);

?>

		<tr>
			 <td> Match </td>
			 <td><?php echo $row[dna]; ?></td>
			 <td><?php echo str_replace($locus,$replace,$row[D8S1179_1].'-'.$row[D8S1179_2]); ?></td>
             <td><?php echo str_replace($locus0,$replace0,$row[D21S11_1].'-'.$row[D21S11_2]); ?></td>
			 <td><?php echo str_replace($locus1,$replace1,$row[D7S820_1].'-'.$row[D7S820_2]); ?></td>
			 <td><?php echo str_replace($locus2,$replace2,$row[CSF1PO_1].'-'.$row[CSF1PO_2]); ?></td>
			 <td><?php echo str_replace($locus3,$replace3,$row[D3S1358_1].'-'.$row[D3S1358_2]); ?></td>
			 <td><?php echo str_replace($locus4,$replace4,$row[TH01_1].'-'.$row[TH01_2]); ?></td>
			 <td><?php echo str_replace($locus5,$replace5,$row[D13S317_1].'-'.$row[D13S317_2]); ?></td>
			 <td><?php echo str_replace($locus6,$replace6,$row[D16S539_1].'-'.$row[D16S539_2]); ?></td>
			 <td><?php echo str_replace($locus7,$replace7,$row[D2S1338_1].'-'.$row[D2S1338_2]); ?></td>
			 <td><?php echo str_replace($locus8,$replace8,$row[D19S433_1].'-'.$row[D19S433_2]); ?></td>
			 <td><?php echo str_replace($locus9,$replace9,$row[VWA_1].'-'.$row[VWA_2]); ?></td>
			 <td><?php echo str_replace($locus10,$replace10,$row[TPOX_1].'-'.$row[TPOX_2]); ?></td>
			 <td><?php echo str_replace($locus11,$replace11,$row[D18S51_1].'-'.$row[D18S51_2]); ?></td>
			 <td><?php echo str_replace($locus12,$replace12,$row[AMEL_1].'-'.$row[AMEL_2]); ?></td>
			 <td><?php echo str_replace($locus13,$replace13,$row[D5S818_1].'-'.$row[D5S818_2]); ?></td>
			 <td><?php echo str_replace($locus14,$replace14,$row[FGA_1].'-'.$row[FGA_2]); ?></td>
		</tr>
	

<?php
	} // for
?>

</table>
	<div>
	<p>
	
	<?php
		require ('footer.php');
	?>

	</div>

</div>


</body>
</html>
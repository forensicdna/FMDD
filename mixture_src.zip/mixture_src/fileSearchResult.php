<html>
<head>
	<title> FMDD </title>
	<style type="text/css">
	body {
		font-family : sans-serif;
	/*	font-size : 10 px; */
	}
	table {
		border : thin solid black;
		border-collapse : collapse; 
		font-family : sans-serif;
		font-size : 11 px;
		border-spacing: 0px;
		table-layout: fixed; 
	}
	th {
		border: 1px solid gray;
		text-align: center;
		vertical-align: center;
		padding-right: 1px;
		height: auto;
		background-color: #fcba7a;
	}
	td {
		border: 1px solid gray;
		text-align: center;
		vertical-align: center;
		padding-bottom: 10px;
		word-break: break-all;
		height: auto;
	}
	
	</style>
</head>
<body>


<?php
	require('dbConnect.php');
	require('alleleVar.php');
	require('head.php');
?>
<div id="pagecell1"> 
  <!--pagecell1--> 
	  <img alt="" src="tl_curve_white.gif" height="6" width="6" id="tl" /> 
	  <img alt="" src="tr_curve_white.gif" height="6" width="6" id="tr" /> 
	  <div> 
		&nbsp;
	  </div> 
	  <div id="pageName"> 
		<h2>File Search Results </h2> 
	  </div> 
	  <input type="button" value="Go Search" title="Go back to Search Page" onclick="window.location='search.php'">
	  <div class="story">
 <?php
// upload ���� ���� �˻�
		if ($_FILES['FileName']['error'] > 0){
			echo 'Problem: ';
			switch ($_FILES['FileName']['error']){
				case 1: echo 'File exceeded upload_max_filesize'; break;
				case 2: echo 'File exceeded max_file_size'; break;
				case 3: echo 'File only partially upload'; break;
				case 4: echo 'No File upload'; break;
			}
			exit;
		}
// upload ���� search������ �Űܼ� ���� �۾� ����
	$file ='./search/'.$_FILES['FileName']['name'];

	if (is_uploaded_file($_FILES['FileName']['tmp_name'])){
		if (!move_uploaded_file($_FILES['FileName']['tmp_name'],$file)){
			echo 'Problem: Could not move file to destination directory';
			exit;
		}
	}

	if (!$file){
		echo '<p><strong> No file. Please try again.</strong></p>';
		
	}elseif ($file){
	$line = file($file);
	
	$number_of_file=count($line);
	
/*	if ($number_of_file==1){
		echo '<p><strong> No file. Please try again.</strong></p>';
	}
*/	

	for ($i=1; $i<$number_of_file;$i++){

		$column = explode("\t",$line[$i]);

		$dna=$column[0];
		$amelo = $column[1];
		$th01 =$column[2];
		$tpox = $column[3];
		$csf1po=$column[4];
		$d3=$column[5];
		$vwa=$column[6];
		$fga=$column[7];
		$d5=$column[8];	
		$d13=$column[9];
		$d7=$column[10];
		$d16=$column[11];
		$d8=$column[12];
		$d21=$column[13];
		$d18=$column[14];
		$d2=$column[15];
		$d19=$column[16];
		$penE=$column[17];
		$penD=$column[18];
//==============================================
		$amelo=str_replace("/",",",$amelo);
		$th01=str_replace("/", ",",$th01);
		$tpox=str_replace("/",",",$tpox);
		$csf1po=str_replace("/",",",$csf1po);
		$d3=str_replace("/",",",$d3);
		$vwa=str_replace("/",",",$vwa);
		$fga=str_replace("/",",",$fga);
		$d5=str_replace("/",",",$d5);
		$d13=str_replace("/",",",$d13);
		$d7=str_replace("/",",",$d7);
		$d16=str_replace("/",",",$d16);
		$d8=str_replace("/",",",$d8);
		$d21=str_replace("/",",",$d21);
		$d18=str_replace("/",",",$d18);
		$d2=str_replace("/",",",$d2);
		$d19=str_replace("/",",",$d19);
		$penE=str_replace("/",",",$penE);
		$penD=str_replace("/",",",$penD);

		$amelo=str_replace("-",",",$amelo);
		$th01=str_replace("-", ",",$th01);
		$tpox=str_replace("-",",",$tpox);
		$csf1po=str_replace("-",",",$csf1po);
		$d3=str_replace("-",",",$d3);
		$vwa=str_replace("-",",",$vwa);
		$fga=str_replace("-",",",$fga);
		$d5=str_replace("-",",",$d5);
		$d13=str_replace("-",",",$d13);
		$d7=str_replace("-",",",$d7);
		$d16=str_replace("-",",",$d16);
		$d8=str_replace("-",",",$d8);
		$d21=str_replace("-",",",$d21);
		$d18=str_replace("-",",",$d18);
		$d2=str_replace("-",",",$d2);
		$d19=str_replace("-",",",$d19);
		$penE=str_replace("-",",",$penE);
		$penD=str_replace("-",",",$penD);

		$amelo=str_replace(",","%",$amelo);
		$th01=str_replace(",", "%",$th01);
		$tpox=str_replace(",","%",$tpox);
		$csf1po=str_replace(",","%",$csf1po);
		$d3=str_replace(",","%",$d3);
		$vwa=str_replace(",","%",$vwa);
		$fga=str_replace(",","%",$fga);
		$d5=str_replace(",","%",$d5);
		$d13=str_replace(",","%",$d13);
		$d7=str_replace(",","%",$d7);
		$d16=str_replace(",","%",$d16);
		$d8=str_replace(",","%",$d8);
		$d21=str_replace(",","%",$d21);
		$d18=str_replace(",","%",$d18);
		$d2=str_replace(",","%",$d2);
		$d19=str_replace(",","%",$d19);
		$penE=str_replace(",","%",$penE);
		$penD=str_replace(",","%",$penD);

		$amelo=trim($amelo);
		$th01=trim($th01);
		$tpox=trim($tpox);						
		$csf1po=trim($csf1po);
		$d3=trim($d3);
		$vwa=trim($vwa);
		$fga=trim($fga);
		$d5=trim($d5);
		$d13=trim($d13);
		$d7=trim($d7);
		$d16=trim($d16);
		$d8=trim($d8);
		$d21=trim($d21);
		$d18=trim($d18);
		$d2=trim($d2);
		$d19=trim($d19);
		$penE=trim($penE);
		$penD=trim($penD);
		

		
//====================================================

		$sql="SELECT * FROM profile WHERE (amel like '%$amelo%' or amel like '') AND (th01 like '%$th01%' or th01 like '') AND (tpox like '%$tpox%' or tpox like '') AND (csf1po like '%$csf1po%' or csf1po like '') AND (d3 like '%$d3%' or d3 like '') AND (vwa like '%$vwa%' or vwa like '') AND (fga like '%$fga%' or fga like '') AND (d5 like '%$d5%' or d5 like '') AND (d13 like '%$d13%' or d13 like '') AND (d7 like '%$d7%' or d7 like '') AND (d16 like '%$d16%' or d16 like '') AND (d8 like '%$d8%' or d8 like '') AND (d21 like '%$d21%' or d21 like '') AND (d18 like '%$d18%' or d18 like '') AND (d2 like '%$d2%' or d2 like '') AND (d19 like '%$d19%' or d19 like '') AND (pentae like '%$penE%' or pentae like '') AND (pentad like '%$penD%' or pentad like '')";
		
	echo $sql;
		$result = mysql_query ($sql);
		$numRow=mysql_num_rows($result);
		
				echo '<table align="center" width="95%" border="1">';
				echo '<tr>';
				echo '<th> </th>';
				echo '<th>'.'DNA_NO'.'</th>';
				echo '<th>'.'AMEL'.'</th>';
				echo '<th>'.'TH01'.'</th>';
				echo '<th>'.'TPOX'.'</th>';
				echo '<th>'.'CSF1PO'.'</th>';
				echo '<th>'.'D3'.'</th>';
				echo '<th>'.'vWA'.'</th>';
				echo '<th>'.'FGA'.'</th>';
				echo '<th>'.'D5'.'</th>';
				echo '<th>'.'D13'.'</th>';
				echo '<th>'.'D7'.'</th>';
				echo '<th>'.'D16'.'</th>';
				echo '<th>'.'D8'.'</th>';
				echo '<th>'.'D21'.'</th>';
				echo '<th>'.'D18'.'</th>';
				echo '<th>'.'D2'.'</th>';
				echo '<th>'.'D19'.'</th>';
				echo '<th>'.'Penta E'.'</th>';
				echo '<th>'.'Penta D'.'</th>';
				echo '</tr>';
				
					$amelo=str_replace("%",",",$amelo);
					$th01=str_replace("%",",",$th01);
					$tpox=str_replace("%",",",$tpox);
					$csf1po=str_replace("%",",",$csf1po);
					$d3=str_replace("%",",",$d3);
					$vwa=str_replace("%",",",$vwa);
					$fga=str_replace("%",",",$fga);
					$d5=str_replace("%",",",$d5);
					$d13=str_replace("%",",",$d13);
					$d7=str_replace("%",",",$d7);
					$d16=str_replace("%",",",$d16);
					$d8=str_replace("%",",",$d8);
					$d21=str_replace("%",",",$d21);
					$d18=str_replace("%",",",$d18);
					$d2=str_replace("%",",",$d2);
					$d19=str_replace("%",",",$d19);
					$penE=str_replace("%",",",$penE);
					$penD=str_replace("%",",",$penD);	

				echo '<tr>';
				echo '<td> Query </td>';
				echo '<td>'.$dna.'</td>';
				echo '<td>'.$amelo.'</td>';
				echo '<td>'.$th01.'</td>';
				echo '<td>'.$tpox.'</td>';
				echo '<td>'.$csf1po.'</td>';
				echo '<td>'.$d3.'</td>';
				echo '<td>'.$vwa.'</td>';
				echo '<td>'.$fga.'</td>';
				echo '<td>'.$d5.'</td>';
				echo '<td>'.$d13.'</td>';
				echo '<td>'.$d7.'</td>';
				echo '<td>'.$d16.'</td>';
				echo '<td>'.$d8.'</td>';
				echo '<td>'.$d21.'</td>';
				echo '<td>'.$d18.'</td>';
				echo '<td>'.$d2.'</td>';
				echo '<td>'.$d19.'</td>';
				echo '<td>'.$penE.'</td>';
				echo '<td>'.$penD.'</td>';
				echo '</tr>';
				
	
				for ($j=0; $j<=$numRow-1; $j++){
					$row=mysql_fetch_array($result);
					
					echo '<tr>';
					echo '<td> Match </td>';
					echo '<td>'. $row['DNA_no'].'</td>';
					echo '<td>'. $row['amel'].'<br>';
					echo '<td>'. $row['th01'].'<br>';
					echo '<td>'. $row['tpox'].'<br>';
					echo '<td>'. $row['csf1po'].'<br>';
					echo '<td>'. $row['d3'].'<br>';
					echo '<td>'. $row['vwa'].'<br>';
					echo '<td>'. $row['fga'].'<br>';
					echo '<td>'. $row['d5'].'<br>';
					echo '<td>'. $row['d13'].'<br>';
					echo '<td>'. $row['d7'].'<br>';
					echo '<td>'. $row['d16'].'<br>';
					echo '<td>'. $row['d8'].'<br>';
					echo '<td>'. $row['d21'].'<br>';
					echo '<td>'. $row['d18'].'<br>';
					echo '<td>'. $row['d2'].'<br>';
					echo '<td>'. $row['d19'].'<br>';
					echo '<td>'. $row['pentae'].'<br>';
					echo '<td>'. $row['pentad'].'<br>';
					echo '</tr>';
					} // for
					
					echo '<hr>';
					echo 'Result ',$i;

	
	} //for
}//elseif


	

?>
	</table>
	<div>
		  <p>&nbsp;</p>
		  <p>&nbsp;</p>
		  <p>&nbsp;</p>
		  <p>&nbsp;</p>
	</div>
<?php
	require ('footer.php');
?>
</div>
	
</body>
</html>
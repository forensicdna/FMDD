<html>
<head>
	<title> FMDD </title>
	<style type="text/css">
	body {
		font-family : sans-serif;
	/*	font-size : 10 px; */
	}
	table {
		border : thin solid black;
		border-collapse : collapse; 
		font-family : sans-serif;
		font-size : 11 px;
		border-spacing: 0px;
		table-layout: fixed; 
	}
	th {
		border: 1px solid gray;
		text-align: center;
		vertical-align: center;
		padding-right: 1px;
		height: auto;
		background-color: #fcba7a;
	}
	td {
		border: 1px solid gray;
		text-align: center;
		vertical-align: center;
		padding-bottom: 10px;
		word-break: break-all;
		height: auto;
	}
	
	</style>
</head>
<body>
<?php
	include "dbConnect.php";
	include "XMLparse.php";
	require ('head.php');
?>
<div id="pagecell1"> 
  <!--pagecell1--> 
	  <img alt="" src="tl_curve_white.gif" height="6" width="6" id="tl" /> 
	  <img alt="" src="tr_curve_white.gif" height="6" width="6" id="tr" /> 
	  <div> 
		&nbsp;
	  </div> 
	  <div id="pageName"> 
		<h2>File Search Results </h2> 
	  </div> 
	  <input type="button" value="Go Search" title="Go back to Search Page" onclick="window.location='search.php'">
	  <div class="story">
<?php
// upload ���� ���� �˻�
		if ($_FILES['xmlFileName']['error'] > 0){
			echo 'Problem: ';
			switch ($_FILES['xmlFileName']['error']){
				case 1: echo 'File exceeded upload_max_filesize'; break;
				case 2: echo 'File exceeded max_file_size'; break;
				case 3: echo 'File only partially upload'; break;
				case 4: echo 'No File upload'; break;
			}
			exit;
		}
// upload ���� search������ �Űܼ� ���� �۾� ����
	$file ='./xmlSearch/'.$_FILES['xmlFileName']['name'];

	if (is_uploaded_file($_FILES['xmlFileName']['tmp_name'])){
		if (!move_uploaded_file($_FILES['xmlFileName']['tmp_name'],$file)){
			echo 'Problem: Could not move file to destination directory';
			exit;
		}
	}

	if (!$file){
		echo '<p><strong> No file. Please try again.</strong></p>';
		
	}elseif ($file){
	$dom = new DOMDocument;
	$dom -> load($file);
	$specimens = $dom->getElementsByTagName('SPECIMEN');
	$count = $specimens->length;

	$xml= file_get_contents($file);
	$parser = new XMLParser($xml);
	$parser -> Parse();
	$test = $parser->document;


	
	for ($i=0 ; $i<$count; $i++){
	$sql = "select * from profile where (d8 like '%".$test->specimen[$i]->locus[0]->allele[0]->allelevalue[0]->tagData."%".
													$test->specimen[$i]->locus[0]->allele[1]->allelevalue[0]->tagData."%' or d8 like '') AND
							          (d21 like '%".$test->specimen[$i]->locus[1]->allele[0]->allelevalue[0]->tagData."%".
										            $test->specimen[$i]->locus[1]->allele[1]->allelevalue[0]->tagData."%' or d21 like '') AND
									   (d7 like '%".$test->specimen[$i]->locus[2]->allele[0]->allelevalue[0]->tagData."%".
										            $test->specimen[$i]->locus[2]->allele[1]->allelevalue[0]->tagData."%' or d7 like '') AND
								   (csf1po like '%".$test->specimen[$i]->locus[3]->allele[0]->allelevalue[0]->tagData."%".
										            $test->specimen[$i]->locus[3]->allele[1]->allelevalue[0]->tagData."%' or csf1po like '') AND
									   (d3 like '%".$test->specimen[$i]->locus[4]->allele[0]->allelevalue[0]->tagData."%".
										            $test->specimen[$i]->locus[4]->allele[1]->allelevalue[0]->tagData."%' or d3 like '') AND
									 (th01 like '%".$test->specimen[$i]->locus[5]->allele[0]->allelevalue[0]->tagData."%".
										            $test->specimen[$i]->locus[5]->allele[1]->allelevalue[0]->tagData."%' or th01 like '') AND
									  (d13 like '%".$test->specimen[$i]->locus[6]->allele[0]->allelevalue[0]->tagData."%".
										            $test->specimen[$i]->locus[6]->allele[1]->allelevalue[0]->tagData."%' or d13 like '') AND
									  (d16 like '%".$test->specimen[$i]->locus[7]->allele[0]->allelevalue[0]->tagData."%".
										            $test->specimen[$i]->locus[7]->allele[1]->allelevalue[0]->tagData."%' or d16 like '') AND
									   (d2 like '%".$test->specimen[$i]->locus[8]->allele[0]->allelevalue[0]->tagData."%".
										            $test->specimen[$i]->locus[8]->allele[1]->allelevalue[0]->tagData."%' or d2 like '') AND
									  (d19 like '%".$test->specimen[$i]->locus[9]->allele[0]->allelevalue[0]->tagData."%".
										            $test->specimen[$i]->locus[9]->allele[1]->allelevalue[0]->tagData."%' or d19 like '') AND
									  (vwa like '%".$test->specimen[$i]->locus[10]->allele[0]->allelevalue[0]->tagData."%".
										            $test->specimen[$i]->locus[10]->allele[1]->allelevalue[0]->tagData."%' or vwa like '') AND
									 (tpox like '%".$test->specimen[$i]->locus[11]->allele[0]->allelevalue[0]->tagData."%".
										            $test->specimen[$i]->locus[11]->allele[1]->allelevalue[0]->tagData."%' or tpox like '') AND
									  (d18 like '%".$test->specimen[$i]->locus[12]->allele[0]->allelevalue[0]->tagData."%".
										            $test->specimen[$i]->locus[12]->allele[1]->allelevalue[0]->tagData."%' or d18 like '') AND
									 (amel like '%".$test->specimen[$i]->locus[13]->allele[0]->allelevalue[0]->tagData."%".
										            $test->specimen[$i]->locus[13]->allele[1]->allelevalue[0]->tagData."%' or amel like '') AND
									   (d5 like '%".$test->specimen[$i]->locus[14]->allele[0]->allelevalue[0]->tagData."%".
										            $test->specimen[$i]->locus[14]->allele[1]->allelevalue[0]->tagData."%' or d5 like '') AND
									  (fga like '%".$test->specimen[$i]->locus[15]->allele[0]->allelevalue[0]->tagData."%".
										            $test->specimen[$i]->locus[15]->allele[1]->allelevalue[0]->tagData."%' or fga like '');"; 
	    echo '<table align="center" width="95%" border="1">';
		echo '<tr>';
		echo '<th> </th>';
		echo '<th width=\'120\'>'.'DNA_NO'.'</th>';
		echo '<th>'.'D8S1179'.'</th>';
		echo '<th>'.'D21S11'.'</th>';
		echo '<th>'.'D7S820'.'</th>';
		echo '<th>'.'CSF1PO'.'</th>';
		echo '<th>'.'D3S1358'.'</th>';
		echo '<th>'.'TH01'.'</th>';
		echo '<th>'.'D13S317'.'</th>';
		echo '<th>'.'D16S539'.'</th>';
		echo '<th>'.'D2S1338'.'</th>';
		echo '<th>'.'D19S433'.'</th>';
		echo '<th>'.'vWA'.'</th>';
		echo '<th>'.'TPOX'.'</th>';
		echo '<th>'.'D18S51'.'</th>';
		echo '<th>'.'Amelogenin'.'</th>';
		echo '<th>'.'D5S818'.'</th>';
		echo '<th>'.'FGA'.'</th>';
		echo '<th>'.'Penta E'.'</th>';
		echo '<th>'.'Penta D'.'</th>';
		echo '<th>'.'Y-STR'.'</th>';
		echo '</tr>';
			
		echo '<tr>';
		echo '<td> Query </td>';
		echo '<td>'.$test->specimen[$i]->specimenid[0]->tagData.'</td>';
	 	
		for ($k=0; $k<16; $k++){
		if(!$test->specimen[$i]->locus[$k]->allele[1]->allelevalue[0]->tagData){
		echo '<td>'.$test->specimen[$i]->locus[$k]->allele[0]->allelevalue[0]->tagData.'-'.$test->specimen[$i]->locus[$k]->allele[0]->allelevalue[0]->tagData.'</td>';
		}else{
		echo '<td>'.$test->specimen[$i]->locus[$k]->allele[0]->allelevalue[0]->tagData.'-'.$test->specimen[$i]->locus[$k]->allele[1]->allelevalue[0]->tagData.'</td>';
			} //else
		} // for ($k=0 ..)
		echo '<td></td>';
		echo '<td></td>';
		echo '</tr>';							
	$result = mysql_query($sql);
	$numRow=mysql_num_rows($result);
	 for ($j=0; $j<=$numRow-1; $j++){
		$row=mysql_fetch_array($result);
		
					echo '<tr>';
					echo '<td> Match </td>';
					echo '<td><a href="resultView.php?DNA_no='.$row[DNA_no].'" target="_blank" onClick="window.open(this.href,\'\',\'width=700, height=900\'); return false;">'.$row[DNA_no].'</a></td>';
					echo '<td>'. $row['d8'].'<br>';
					echo '<td>'. $row['d21'].'<br>';
					echo '<td>'. $row['d7'].'<br>';
					echo '<td>'. $row['csf1po'].'<br>';
					echo '<td>'. $row['d3'].'<br>';
					echo '<td>'. $row['th01'].'<br>';
					echo '<td>'. $row['d13'].'<br>';
					echo '<td>'. $row['d16'].'<br>';
					echo '<td>'. $row['d2'].'<br>';
					echo '<td>'. $row['d19'].'<br>';
					echo '<td>'. $row['vwa'].'<br>';
					echo '<td>'. $row['tpox'].'<br>';
					echo '<td>'. $row['d18'].'<br>';
   				    echo '<td>'. $row['amel'].'<br>';
					echo '<td>'. $row['d5'].'<br>';					
					echo '<td>'. $row['fga'].'<br>';					
					echo '<td>'. $row['pentae'].'<br>';
					echo '<td>'. $row['pentad'].'<br>';
?>
                          <td><?php         
								$match = "select DNA from profile, ystr where ystr.DNA ='".$row[DNA_no]."' and profile.DNA_no='".$row[DNA_no]."'";
								$matchResult = mysql_query($match);
								$matchRow=mysql_fetch_array($matchResult);
								if ($matchRow[DNA]){echo O;} else {echo X;}
								?>
						  </td>
<?php
					echo '</tr>'; 
			
		} // for ($j=0 ..)
		
	} // for ($i=0 ..)
} // elseif ($file){ .. }
?>

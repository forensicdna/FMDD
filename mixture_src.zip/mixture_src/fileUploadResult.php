<html>
<head>
	<title> FMDD </title>
	<style type="text/css">
	body {
		font-family : sans-serif;
	/*	font-size : 10 px; */
	}
	table {
		border : thin solid black;
		border-collapse : collapse; 
		font-family : sans-serif;
		font-size : 11 px;
		border-spacing: 0px;
		table-layout: fixed; 
	}
	th {
		border: 1px solid gray;
		text-align: center;
		vertical-align: center;
		padding-right: 1px;
		height: auto;
		background-color: #fcba7a;
	}
	td {
		border: 1px solid gray;
		text-align: center;
		vertical-align: center;
		padding-bottom: 15px;
		word-break: break-all;
		height: auto;
	}
	
	</style>
	
</head>
<body>

<?php
	require ('dbConnect.php');
	require ('uploadVar.php');
	require ('head.php');
?>
<div id="pagecell1"> 
  <!--pagecell1--> 
	  <img alt="" src="tl_curve_white.gif" height="6" width="6" id="tl" /> 
	  <img alt="" src="tr_curve_white.gif" height="6" width="6" id="tr" /> 
	  <div> 
		&nbsp;
	  </div> 
	  <div id="pageName"> 
		<h2>File Upload Results </h2> 
	  </div> 
	  <input type="button" value="Go Submit" title="Go back to Submit Page" onclick="window.location='submit.php'">
	  <div class="story">
<?php
// Submit�� ���� ���� �˻�
		if ($_FILES['SubmitFile']['error'] > 0){
			echo 'Problem: ';
			switch ($_FILES['SubmitFile']['error']){
				case 1: echo 'File exceeded upload_max_filesize'; break;
				case 2: echo 'File exceeded max_file_size'; break;
				case 3: echo 'File only partially upload'; break;
				case 4: echo 'No File upload'; break;
			}
			exit;
		}
// Submit�� ���� upload������ �Űܼ� ���� �۾� ����
	$file ='./upload/'.$_FILES['SubmitFile']['name'];

	if (is_uploaded_file($_FILES['SubmitFile']['tmp_name'])){
		if (!move_uploaded_file($_FILES['SubmitFile']['tmp_name'],$file)){
			echo 'Problem: Could not move file to destination directory';
			exit;
		}
	}

	if (!$file) {
		echo '<p><strong> No file. Please try again.</strong></p>';
	} elseif ($file) {

		$line = file($file);// file�� �迭�� $line�� ����
		$number_of_file=count($line);
			if ($number_of_file==0){
				echo '<p><strong> No file. Please try again.</strong></p>';
			} // $number_of_file if �� �ݱ�
		


	for ($i=1; $i<$number_of_file;$i++){
		$column = explode("\t",$line[$i]);

		$dna=$column[0];
		$amelo = $column[1];
		$th01 =$column[2];
		$tpox = $column[3];
		$csf1po=$column[4];
		$d3=$column[5];
		$vwa=$column[6];
		$fga=$column[7];
		$d5=$column[8];	
		$d13=$column[9];
		$d7=$column[10];
		$d16=$column[11];
		$d8=$column[12];
		$d21=$column[13];
		$d18=$column[14];
		$d2=$column[15];
		$d19=$column[16];
		$penE=$column[17];
		$penD=$column[18];

		$amelo=str_replace("/",",",$amelo);
		$th01=str_replace("/", ",",$th01);
		$tpox=str_replace("/",",",$tpox);
		$csf1po=str_replace("/",",",$csf1po);
		$d3=str_replace("/",",",$d3);
		$vwa=str_replace("/",",",$vwa);
		$fga=str_replace("/",",",$fga);
		$d5=str_replace("/",",",$d5);
		$d13=str_replace("/",",",$d13);
		$d7=str_replace("/",",",$d7);
		$d16=str_replace("/",",",$d16);
		$d8=str_replace("/",",",$d8);
		$d21=str_replace("/",",",$d21);
		$d18=str_replace("/",",",$d18);
		$d2=str_replace("/",",",$d2);
		$d19=str_replace("/",",",$d19);
		$penE=str_replace("/",",",$penE);
		$penD=str_replace("/",",",$penD);

		$amelo=str_replace("-",",",$amelo);
		$th01=str_replace("-", ",",$th01);
		$tpox=str_replace("-",",",$tpox);
		$csf1po=str_replace("-",",",$csf1po);
		$d3=str_replace("-",",",$d3);
		$vwa=str_replace("-",",",$vwa);
		$fga=str_replace("-",",",$fga);
		$d5=str_replace("-",",",$d5);
		$d13=str_replace("-",",",$d13);
		$d7=str_replace("-",",",$d7);
		$d16=str_replace("-",",",$d16);
		$d8=str_replace("-",",",$d8);
		$d21=str_replace("-",",",$d21);
		$d18=str_replace("-",",",$d18);
		$d2=str_replace("-",",",$d2);
		$d19=str_replace("-",",",$d19);
		$penE=str_replace("-",",",$penE);
		$penD=str_replace("-",",",$penD);

	$sql="insert into profile (DNA_no,amel, th01,tpox,csf1po,d3,vwa,fga,d5,d13,d7,d16,d8,d21,d18,d2,d19,pentae, pentad,inputDate) values ('".$dna."','".$amelo."','".$th01."','".$tpox."','".$csf1po."','".$d3."','".$vwa."','".$fga."','".$d5."','".$d13."','".$d7."','".$d16."'
,'".$d8."','".$d21."','".$d18."','".$d2."','".$d19."','".$penE."','".$penD."','".Date("Y-m-d")."')";

		
 	
				$result = mysql_query ($sql); //|| die ("Same DNA Number exists in the Database");
								
				} // FOR�� �ݱ�
				if ($result){
				?>
					<script type="text/javascript">
					<!--
					alert (" DB upload Complete");
					location.href ='submit.php';
					//-->
					</script> 
		
				<?php
				}elseif (!$result){
				?>
					<script type="text/javascript">
					<!--
					alert ("Same DNA Number exists in the Database");
					location.href ='submit.php';
					//-->
					</script> 
				<?php
						}
					} //elseif
				?>
		
	<div>
		  <p>&nbsp;</p>
		  <p>&nbsp;</p>
		  <p>&nbsp;</p>
		  <p>&nbsp;</p>
	</div>
<?php
	require ('footer.php');
?>
</div>
	
</body>
</html>
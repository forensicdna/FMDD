<html>
 <head>
  <title> FMDD </title>
  <style type="text/css">
	body {

	/*	font-size : 10 px; */
	}
	table.outter {
		border : 0px thin solid white;
		border-collapse : collapse; 
		padding:5px;
		table-layout: fixed;
	}
	table {
		border : thin solid black;
		border-collapse : collapse; 
		font-size : 12 px;
		border-spacing: 0px;
		table-layout: fixed; 
	}
	th {
		border: 1px solid blue;
		text-align: center;
		vertical-align: top;
		padding:5px;
		background-color: blue; 
		font-size : 12px;
		color: yellow;
		font-weight: bold;
	}
	td.locus {

		font-size : 12px; 
		border: 1px solid blue;
		text-align: left;
		vertical-align:center;
		padding-right: 10px;
		background-color: Darkseagreen;
		color:black;
		font-weight: bold;
	}
	th.refer {
		border: 1px solid blue;
		text-align: center;
		vertical-align: top;
		padding:5px;
		background-color: blue; 
		font-size : 12px;
		color: yellow;
		font-weight: bold;
	}
	td.refer {
		font-size : 12 px; 
		border: 1px solid green;
		text-align: center;
		vertical-align: center;
		padding-right: 5px;
		background-color: tan;
		color: black;
		font-weight: bold;
	}
	
	
	td.outter {
		border : thin solid white;
	}
	td {
		border: 1px solid gray;
		text-align: center;
		vertical-align: top;
		padding-bottom: 1px;
		padding-top: 1px;
	}
	.option {
		text-align: left;
		padding:5px 5px 5px 5px;
		border: 2px solid gray;
		vertical-align: center;


	}
	#opt{
		padding:4px;
		border: 2px solid gray;
		vertical-align: center;
	}
	#popFre{
		font-family: sans-serif;
	}

	
	</style>
	<script language="javascript">
	<!--
	
	function fnLayer()
	{
		var contributor_val=0;
		
		for (var i=0; i< sfrm.contributor.length; i++)
		{
			
			if(sfrm.contributor[i].checked==true)
			{
				
				contributor_val = sfrm.contributor[i].value;
				break;
			}
		}
	
		if(contributor_val=="1")
		{
				document.getElementById("one").style.display = "block";
				document.getElementById("two").style.display = "none";
				document.getElementById("three").style.display = "none";
				document.getElementById("likeli").style.display = "none";
				document.getElementById("ref").style.display = "none";
		}
		else if(contributor_val=="2")
		{	
				document.getElementById("one").style.display = "none";
				document.getElementById("two").style.display = "block";
				document.getElementById("three").style.display = "none";
				document.getElementById("likeli").style.display = "block";
				if (sfrm.likelihood.checked==true)
				{
					showMe('ref',sfrm.likelihood);
				}
				
		}
		else if(contributor_val=="3")
		{
			document.getElementById("one").style.display = "none";
			document.getElementById("two").style.display = "none";
			document.getElementById("three").style.display = "block";
			document.getElementById("likeli").style.display = "none";
			document.getElementById("ref").style.display = "none";
		}
	}

	function showMe(ref, box)
	{
		var vis = (box.checked) ? "block":"none";
		document.getElementById("ref").style.display = vis;
	}	


	function victimShow(vic, a)
	{
		var vi = (a.checked) ? "none":"block";
		document.getElementById("vic").style.display =vi;
		document.getElementById("rd").style.display =vi;
	}
	
	-->
	</script> 
 </head>
<body>
<?php 
require('head.php');
?>

<div id="pagecell1"> 
  <!--pagecell1--> 
	  <img alt="" src="tl_curve_white.gif" height="6" width="6" id="tl" /> 
	  <img alt="" src="tr_curve_white.gif" height="6" width="6" id="tr" /> 
	  
	  <div id="pageName"> 
	    &nbsp;
		<h2>Analysis</h2> 
	  </div> 
	  <div id="col2"> 
		<div class="feature"> 
		<form method="POST" action="statisticResult.php" name="sfrm"> 
		<label>Option</label><br />
		<table class="option" width="450px">
			<tr>
			<td class="option" width="150px"> Select population</td>
			<td class="option">
				<select name="pop" id="popFre">
					<option value ='1'> Korean </option>
					<option value ='2'> Caucasian </option>
					<option value ='3'> African Americans </option>
					<option value ='4'> Hispanics </option>
				</select>
			</td>
			<tr>
			<td class="option"  width="150px">Number of contributors </td>
			<td class="option" width="250px">
				<input type="radio" name="contributor" value="1" checked onclick="fnLayer()">Single source</input>
				<input type="radio" name="contributor" value="2" onclick="fnLayer()">2 person </input>
				<input type="radio" name="contributor" value="3" onclick="fnLayer()">3 person </input>
				<span style="display:none" id="likeli"> 
				<input type="checkbox" name="likelihood" value="4" onclick="showMe('ref', this)"><label>Likelihood Ratio </label> </input> <br />
				<input type="checkbox" name="dropout" value="1"></input><label>Drop-Out : </label><input type="text" name="rd"> </input>
			 	</span> 
			</td>
			</tr>
		</table>

							<p>
							<label>Mixture Profile</label>
							<p>
							<table id="one" style="display:block" width="180px">
								<tr>
									<th>Locus </td>
									<th>Allele 1 </td>
									<th>Allele 2 </td>
								</tr>
								<tr>
									<td class="locus"> TH01 </td>
									<td><input type="text" name="th011" size='3'></td>
									<td><input type="text" name="th012" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> TPOX </td>
									<td><input type="text" name="tpox1" size='3'></td>
									<td><input type="text" name="tpox2" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> CSF1PO </td>
									<td><input type="text" name="csf1po1" size='3'></td> 
									<td><input type="text" name="csf1po2" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D3S1358 </td>
									<td><input type="text" name="d31" size='3'></td>
									<td><input type="text" name="d32" size='3'></td>

								</tr>
								<tr>
									<td class="locus"> vWA </td>
									<td><input type="text" name="vwa1" size='3'></td>
									<td><input type="text" name="vwa2" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> FGA </td>
									<td><input type="text" name="fga1" size='3'></td>
									<td><input type="text" name="fga2" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D5S818 </td>
									<td><input type="text" name="d51" size='3'></td>
									<td><input type="text" name="d52" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D13S317 </td>
									<td><input type="text" name="d131" size='3'></td>
									<td><input type="text" name="d132" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D7S820 </td>
									<td><input type="text" name="d71" size='3'></td>
									<td><input type="text" name="d72" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D16S539 </td>
									<td><input type="text" name="d161" size='3'></td>
									<td><input type="text" name="d162" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D8S1179 </td>
									<td><input type="text" name="d81" size='3'></td>
									<td><input type="text" name="d82" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D21S11 </td>
									<td><input type="text" name="d211" size='3'></td>
									<td><input type="text" name="d212" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D18S51 </td>
									<td><input type="text" name="d181" size='3'></td>
									<td><input type="text" name="d182" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D2S1338 </td>
									<td><input type="text" name="d21" size='3'></td>
									<td><input type="text" name="d22" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D19S433 </td>
									<td><input type="text" name="d191" size='3'></td>
									<td><input type="text" name="d192" size='3'></td>
								</tr>
							</table>
							<p>
							<table id="two" style="display:none" width="300px">
								<tr>
									<th>Locus </td>
									<th>Allele 1 </td>
									<th>Allele 2 </td>
									<th>Allele 3</td>
									<th>Allele 4</td>
								</tr>
								<tr>
									<td class="locus"> TH01 </td>
									<td><input type="text" name="th01a" size='3'></td>
									<td><input type="text" name="th01b" size='3'></td>
									<td><input type="text" name="th01c" size='3'></td>
									<td><input type="text" name="th01d" size='3'></td>
								<tr>
									<td class="locus"> TPOX </td>
									<td><input type="text" name="tpoxa" size='3'></td>
									<td><input type="text" name="tpoxb" size='3'></td>
									<td><input type="text" name="tpoxc" size='3'></td>
									<td><input type="text" name="tpoxd" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> CSF1PO </td>
									<td><input type="text" name="csf1poa" size='3'></td> 
									<td><input type="text" name="csf1pob" size='3'></td>
									<td><input type="text" name="csf1poc" size='3'></td> 
									<td><input type="text" name="csf1pod" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D3S1358 </td>
									<td><input type="text" name="d3a" size='3'></td>
									<td><input type="text" name="d3b" size='3'></td>
									<td><input type="text" name="d3c" size='3'></td>
									<td><input type="text" name="d3d" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> vWA </td>
									<td><input type="text" name="vwaa" size='3'></td>
									<td><input type="text" name="vwab" size='3'></td>
									<td><input type="text" name="vwac" size='3'></td>
									<td><input type="text" name="vwad" size='3'></td>
								</tr>
								<tr>
								<td class="locus"> FGA </td>
									<td><input type="text" name="fgaa" size='3'></td>
									<td><input type="text" name="fgab" size='3'></td>
									<td><input type="text" name="fgac" size='3'></td>
									<td><input type="text" name="fgad" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D5S818 </td>
									<td><input type="text" name="d5a" size='3'></td>
									<td><input type="text" name="d5b" size='3'></td>
									<td><input type="text" name="d5c" size='3'></td>
									<td><input type="text" name="d5d" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D13S317 </td>
									<td><input type="text" name="d13a" size='3'></td>
									<td><input type="text" name="d13b" size='3'></td>
									<td><input type="text" name="d13c" size='3'></td>
									<td><input type="text" name="d13d" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D7S820 </td>
									<td><input type="text" name="d7a" size='3'></td>
									<td><input type="text" name="d7b" size='3'></td>
									<td><input type="text" name="d7c" size='3'></td>
									<td><input type="text" name="d7d" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D16S539 </td>
									<td><input type="text" name="d16a" size='3'></td>
									<td><input type="text" name="d16b" size='3'></td>
									<td><input type="text" name="d16c" size='3'></td>
									<td><input type="text" name="d16d" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D8S1179 </td>
									<td><input type="text" name="d8a" size='3'></td>
									<td><input type="text" name="d8b" size='3'></td>
									<td><input type="text" name="d8c" size='3'></td>
									<td><input type="text" name="d8d" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D21S11 </td>
									<td><input type="text" name="d21a" size='3'></td>
									<td><input type="text" name="d21b" size='3'></td>
									<td><input type="text" name="d21c" size='3'></td>
									<td><input type="text" name="d21d" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D18S51 </td>
									<td><input type="text" name="d18a" size='3'></td>
									<td><input type="text" name="d18b" size='3'></td>
									<td><input type="text" name="d18c" size='3'></td>
									<td><input type="text" name="d18d" size='3'></td>
								</tr>
								<tr>	
									<td class="locus"> D2S1338 </td>
									<td><input type="text" name="d2a" size='3'></td>
									<td><input type="text" name="d2b" size='3'></td>
									<td><input type="text" name="d2c" size='3'></td>
									<td><input type="text" name="d2d" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D19S433 </td>
									<td><input type="text" name="d19a" size='3'></td>
									<td><input type="text" name="d19b" size='3'></td>
									<td><input type="text" name="d19c" size='3'></td>
									<td><input type="text" name="d19d" size='3'></td>
								</tr>
							</table>
							<p>
							<table id="three" style="display:none" width="400px">
								<tr>
									<th>Locus </td>
									<th>Allele 1 </td>
									<th>Allele 2 </td>
									<th>Allele 3</td>
									<th>Allele 4</td>
									<th>Allele 5</td>
									<th>Allele 6</td>
								</tr>
								<tr>
									<td class="locus"> TH01 </td>
									<td><input type="text" name="th01_a" size='3'></td>
									<td><input type="text" name="th01_b" size='3'></td>
									<td><input type="text" name="th01_c" size='3'></td>
									<td><input type="text" name="th01_d" size='3'></td>
									<td><input type="text" name="th01_e" size='3'></td>
									<td><input type="text" name="th01_f" size='3'></td>
								<tr>
									<td class="locus"> TPOX </td>
									<td><input type="text" name="tpox_a" size='3'></td>
									<td><input type="text" name="tpox_b" size='3'></td>
									<td><input type="text" name="tpox_c" size='3'></td>
									<td><input type="text" name="tpox_d" size='3'></td>
									<td><input type="text" name="tpox_e" size='3'></td>
									<td><input type="text" name="tpox_f" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> CSF1PO </td>
									<td><input type="text" name="csf1po_a" size='3'></td> 
									<td><input type="text" name="csf1po_b" size='3'></td>
									<td><input type="text" name="csf1po_c" size='3'></td> 
									<td><input type="text" name="csf1po_d" size='3'></td>
									<td><input type="text" name="csf1po_e" size='3'></td> 
									<td><input type="text" name="csf1po_f" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D3S1358 </td>
									<td><input type="text" name="d3_a" size='3'></td>
									<td><input type="text" name="d3_b" size='3'></td>
									<td><input type="text" name="d3_c" size='3'></td>
									<td><input type="text" name="d3_d" size='3'></td>
									<td><input type="text" name="d3_e" size='3'></td>
									<td><input type="text" name="d3_f" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> vWA </td>
									<td><input type="text" name="vwa_a" size='3'></td>
									<td><input type="text" name="vwa_b" size='3'></td>
									<td><input type="text" name="vwa_c" size='3'></td>
									<td><input type="text" name="vwa_d" size='3'></td>
									<td><input type="text" name="vwa_e" size='3'></td>
									<td><input type="text" name="vwa_f" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> FGA </td>
									<td><input type="text" name="fga_a" size='3'></td>
									<td><input type="text" name="fga_b" size='3'></td>
									<td><input type="text" name="fga_c" size='3'></td>
									<td><input type="text" name="fga_d" size='3'></td>
									<td><input type="text" name="fga_e" size='3'></td>
									<td><input type="text" name="fga_f" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D5S818 </td>
									<td><input type="text" name="d5_a" size='3'></td>
									<td><input type="text" name="d5_b" size='3'></td>
									<td><input type="text" name="d5_c" size='3'></td>
									<td><input type="text" name="d5_d" size='3'></td>
									<td><input type="text" name="d5_e" size='3'></td>
									<td><input type="text" name="d5_f" size='3'></td>
								</tr>
								<tr>
								<td class="locus"> D13S317 </td>
									<td><input type="text" name="d13_a" size='3'></td>
									<td><input type="text" name="d13_b" size='3'></td>
									<td><input type="text" name="d13_c" size='3'></td>
									<td><input type="text" name="d13_d" size='3'></td>
									<td><input type="text" name="d13_e" size='3'></td>
									<td><input type="text" name="d13_f" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D7S820 </td>
									<td><input type="text" name="d7_a" size='3'></td>
									<td><input type="text" name="d7_b" size='3'></td>
									<td><input type="text" name="d7_c" size='3'></td>
									<td><input type="text" name="d7_d" size='3'></td>
									<td><input type="text" name="d7_e" size='3'></td>
									<td><input type="text" name="d7_f" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D16S539 </td>
									<td><input type="text" name="d16_a" size='3'></td>
									<td><input type="text" name="d16_b" size='3'></td>
									<td><input type="text" name="d16_c" size='3'></td>
									<td><input type="text" name="d16_d" size='3'></td>
									<td><input type="text" name="d16_f" size='3'></td>
									<td><input type="text" name="d16_f" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D8S1179 </td>
									<td><input type="text" name="d8_a" size='3'></td>
									<td><input type="text" name="d8_b" size='3'></td>
									<td><input type="text" name="d8_c" size='3'></td>
									<td><input type="text" name="d8_d" size='3'></td>
									<td><input type="text" name="d8_e" size='3'></td>
									<td><input type="text" name="d8_f" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D21S11 </td>
									<td><input type="text" name="d21_a" size='3'></td>
									<td><input type="text" name="d21_b" size='3'></td>
									<td><input type="text" name="d21_c" size='3'></td>
									<td><input type="text" name="d21_d" size='3'></td>
									<td><input type="text" name="d21_e" size='3'></td>
									<td><input type="text" name="d21_f" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D18S51 </td>
									<td><input type="text" name="d18_a" size='3'></td>
									<td><input type="text" name="d18_b" size='3'></td>
									<td><input type="text" name="d18_c" size='3'></td>
									<td><input type="text" name="d18_d" size='3'></td>
									<td><input type="text" name="d18_e" size='3'></td>
									<td><input type="text" name="d18_f" size='3'></td>
								</tr>
								<tr>	
									<td class="locus"> D2S1338 </td>
									<td><input type="text" name="d2_a" size='3'></td>
									<td><input type="text" name="d2_b" size='3'></td>
									<td><input type="text" name="d2_c" size='3'></td>
									<td><input type="text" name="d2_d" size='3'></td>
									<td><input type="text" name="d2_e" size='3'></td>
									<td><input type="text" name="d2_f" size='3'></td>
								</tr>
								<tr>
									<td class="locus"> D19S433 </td>
									<td><input type="text" name="d19_a" size='3'></td>
									<td><input type="text" name="d19_b" size='3'></td>
									<td><input type="text" name="d19_c" size='3'></td>
									<td><input type="text" name="d19_d" size='3'></td>
									<td><input type="text" name="d19_e" size='3'></td>
									<td><input type="text" name="d19_f" size='3'></td>
								</tr>
							</table>
					
		
				<div id="right1"> 
				
				<table class="outter" id="ref" style="display:none">
				    <td>Reference<br />
					<input type="checkbox" name="victim" value="5" onclick="victimShow('vic', this)"><label> No Reference</label></input> <br /></td>
					<tr class="outter">
					
  					  <td class="outter"> 
						<table align="center" width="200px">
							   <h5 align="center">Suspect </h5>
							   <br />
								<tr>
									<th class="refer"> Locus </th>
									<th class="refer"> Allele 1 </th>
									<th class="refer"> Allele 2 </th>
								</tr>
								<tr>
									<td class="refer"> TH01 </td>
									<td><input type="text" name="sus_th01a" size='2'></td>
									<td><input type="text" name="sus_th01b" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> TPOX </td>
									<td><input type="text" name="sus_tpoxa" size='2'></td>
									<td><input type="text" name="sus_tpoxb" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> CSF1PO </td>
									<td><input type="text" name="sus_csf1poa" size='2'></td> 
									<td><input type="text" name="sus_csf1pob" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D3S1358 </td>
									<td><input type="text" name="sus_d3a" size='2'></td>
									<td><input type="text" name="sus_d3b" size='2'></td>

								</tr>
								<tr>
									<td class="refer"> vWA </td>
									<td><input type="text" name="sus_vwaa" size='2'></td>
									<td><input type="text" name="sus_vwab" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> FGA </td>
									<td><input type="text" name="sus_fgaa" size='2'></td>
									<td><input type="text" name="sus_fgab" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D5S818 </td>
									<td><input type="text" name="sus_d5a" size='2'></td>
									<td><input type="text" name="sus_d5b" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D13S317 </td>
									<td><input type="text" name="sus_d13a" size='2'></td>
									<td><input type="text" name="sus_d13b" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D7S820 </td>
									<td><input type="text" name="sus_d7a" size='2'></td>
									<td><input type="text" name="sus_d7b" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D16S539 </td>
									<td><input type="text" name="sus_d16a" size='2'></td>
									<td><input type="text" name="sus_d16b" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D8S1179 </td>
									<td><input type="text" name="sus_d8a" size='2'></td>
									<td><input type="text" name="sus_d8b" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D21S11 </td>
									<td><input type="text" name="sus_d21a" size='2'></td>
									<td><input type="text" name="sus_d21b" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D18S51 </td>
									<td><input type="text" name="sus_d18a" size='2'></td>
									<td><input type="text" name="sus_d18b" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D2S1338 </td>
									<td><input type="text" name="sus_d2a" size='2'></td>
									<td><input type="text" name="sus_d2b" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D19S433 </td>
									<td><input type="text" name="sus_d19a" size='2'></td>
									<td><input type="text" name="sus_d19b" size='2'></td>
								</tr>
							</table>
						
						<td class="outter">
							<table align="center" id="vic" style="display:block" width="200px" >
							   <h5 align="center"> Victim (Reference) </h5>
							   <br />
								<tr>
									<th class="refer"> Locus </th>
									<th class="refer"> Allele 1 </th>
									<th class="refer"> Allele 2 </th>
								</tr>
								<tr>
									<td class="refer"> TH01 </td>
									<td><input type="text" name="vic_th01a" size='2'></td>
									<td><input type="text" name="vic_th01b" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> TPOX </td>
									<td><input type="text" name="vic_tpoxa" size='2'></td>
									<td><input type="text" name="vic_tpoxb" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> CSF1PO </td>
									<td><input type="text" name="vic_csf1poa" size='2'></td> 
									<td><input type="text" name="vic_csf1pob" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D3S1358 </td>
									<td><input type="text" name="vic_d3a" size='2'></td>
									<td><input type="text" name="vic_d3b" size='2'></td>

								</tr>
								<tr>
									<td class="refer"> vWA </td>
									<td><input type="text" name="vic_vwaa" size='2'></td>
									<td><input type="text" name="vic_vwab" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> FGA </td>
									<td><input type="text" name="vic_fgaa" size='2'></td>
									<td><input type="text" name="vic_fgab" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D5S818 </td>
									<td><input type="text" name="vic_d5a" size='2'></td>
									<td><input type="text" name="vic_d5b" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D13S317 </td>
									<td><input type="text" name="vic_d13a" size='2'></td>
									<td><input type="text" name="vic_d13b" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D7S820 </td>
									<td><input type="text" name="vic_d7a" size='2'></td>
									<td><input type="text" name="vic_d7b" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D16S539 </td>
									<td><input type="text" name="vic_d16a" size='2'></td>
									<td><input type="text" name="vic_d16b" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D8S1179 </td>
									<td><input type="text" name="vic_d8a" size='2'></td>
									<td><input type="text" name="vic_d8b" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D21S11 </td>
									<td><input type="text" name="vic_d21a" size='2'></td>
									<td><input type="text" name="vic_d21b" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D18S51 </td>
									<td><input type="text" name="vic_d18a" size='2'></td>
									<td><input type="text" name="vic_d18b" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D2S1338 </td>
									<td><input type="text" name="vic_d2a" size='2'></td>
									<td><input type="text" name="vic_d2b" size='2'></td>
								</tr>
								<tr>
									<td class="refer"> D19S433 </td>
									<td><input type="text" name="vic_d19a" size='2'></td>
									<td><input type="text" name="vic_d19b" size='2'></td>
								</tr>
							</table>	
						</td>
					</tr>
				</table>
						
					<!-- //div = right1 �� -->
					</div>
					<p>
					<input type="submit" value="analysis" onclick="new_capture()" />
					</form>
			<!-- //div feature �� -->
			</div>
		
		<!-- //div col2 �� -->
		</div>
		<?php
			require ('left.php');
			require ('footer.php');
		?>
	<!-- //pagecell1 �� -->
   </div>
   </body>
</html>


<html>
<head>
	<title> FMDD </title>
	<style type="text/css">
		body {
		font-family : sans-serif;
	/*	font-size : 10 px; */
	}
	table {
		border : thin solid black;
		border-collapse : collapse; 
		font-family : Arial,sans-serif;
		font-size : 12 px;
		border-spacing: 0px;
		table-layout: fixed;  
	}
	th {
		border: 1px solid gray;
		text-align: center;
		vertical-align: top;
		padding-right: 10px;
		background-color: tan;
		color: darkslategreen;
	}
	td {
		border: 1px solid gray;
		vertical-align: top;
		padding-bottom: 5px;
		padding-top: 5px;
		padding-right: 3px;
		padding-left: 3px;
	}

	A:link {text-decoration:none;
		    color:black;
	}
	A:visited {text-decoration:none;
		    color:black;
	}
	A:hover {text-decoration:none;
		    color:black;
	}
	</style>
</head>

<body>
<?php 
require('head.php');
?>

<div id="pagecell1"> 
  <!--pagecell1--> 
	  <img alt="" src="tl_curve_white.gif" height="6" width="6" id="tl" /> 
	  <img alt="" src="tr_curve_white.gif" height="6" width="6" id="tr" /> 
	 
	  <div id="pageName"> 
	  &nbsp;
		<h2>Submit (Reference) </h2> 
	  </div> 
	  <div id="col2"> 
		<div class="feature"> 
			<h3>Register reference profile </h3> (Homozygote: Input both alleles. e.g. 9,9)
		      <form method="POST" action="referenceSubmitResult.php">
				<table align="center">
					<tr>
						<td colspan='9'><b>DNA_number : </b> <input type="text" name="DNA_no" size='40'></td>
					<tr>
						<th> Amelogenin</th>
						<th> TH01 </th>
						<th> TPOX </th>
						<th> CSF1PO </th>
						<th> D3S1358 </th>
						<th> vWA </th>
						<th> FGA </th>
						<th> D5S818 </th>
						<th> D13S317 </th>
					
					</tr>
					<tr>
						<td align="center"> <input type="text" name="amelo_a" size='3'> <input type="text" name="amelo_b" size='3'></td>
						<td align="center"> <input type="text" name="th01_a" size='3'> <input type="text" name="th01_b" size='3'></td>
						<td align="center"> <input type="text" name="tpox_a" size='3'> <input type="text" name="tpox_b" size='3'></td>
						<td align="center"> <input type="text" name="csf1po_a" size='3'> <input type="text" name="csf1po_b" size='3'></td>
						<td align="center"> <input type="text" name="d3_a" size='3'> <input type="text" name="d3_b" size='3'></td>
						<td align="center"> <input type="text" name="vwa_a" size='3'> <input type="text" name="vwa_b" size='3'></td>
						<td align="center"> <input type="text" name="fga_a" size='3'> <input type="text" name="fga_b" size='3'></td>
						<td align="center"> <input type="text" name="d5_a" size='3'> <input type="text" name="d5_b" size='3'></td>
						<td align="center"> <input type="text" name="d13_a" size='3'> <input type="text" name="d13_b" size='3'></td>
					</tr>
					<tr>
						<th> D7S820 </th>
						<th> D16S539 </th>
						<th> D8S1179 </th>
						<th> D21S11 </th>
						<th> D18S51 </th>
						<th> D2S1338 </th>
						<th> D19S433 </th>
						<th> Penta E </th>
						<th> Penta D </th>
					</tr>
					<tr>
						
						
						<td align="center"> <input type="text" name="d7_a" size='3'> <input type="text" name="d7_b" size='3'></td>
						<td align="center"> <input type="text" name="d16_a" size='3'> <input type="text" name="d16_b" size='3'></td>
						<td align="center"> <input type="text" name="d8_a" size='3'> <input type="text" name="d8_b" size='3'></td>
						<td align="center"> <input type="text" name="d21_a" size='3'> <input type="text" name="d21_b" size='3'></td>
						<td align="center"> <input type="text" name="d18_a" size='3'> <input type="text" name="d18_b" size='3'></td>
						<td align="center"> <input type="text" name="d2_a" size='3'> <input type="text" name="d2_b" size='3'></td>
						<td align="center"> <input type="text" name="d19_a" size='3'> <input type="text" name="d19_b" size='3'></td>
						<td align="center"> <input type="text" name="penE_a" size='3'> <input type="text" name="penE_b" size='3'></td>
						<td align="center"> <input type="text" name="penD_a" size='3'> <input type="text" name="penD_b" size='3'></td>
					</tr>
					<tr>
						<td colspan= '9'><input type="submit" value="Reference Submit"></td>
					</tr>
				</table>
				</form>
			</div> 
		<div class="story">

			 <h3>XML File Upload </h3> 
			 Please upload your XML files (CODIS export file from GMID-X)
			  <form method="POST" action="xmlUploadResult.php" enctype="multipart/form-data">	
			  <p>			  
			  <input type="file" name="xmlSubmitFile" size="20">
			  <input type="submit" value="Upload"> 
              </p>
			</form> 
		
		
		</div> 
	 </div> 
	  <!--end col2 --> 
	  <?php
		require ('left.php')
	  ?>
	  <!--end col1 div --> 
	  <?php
		require ('footer.php')
	  ?>
</div> 
	<!--end pagecell1--> 
<br /> 
</body>
</html>

<html>
<head>
	<title> FMDD </title>
	<style type="text/css">
	body {
		font-family : sans-serif;
		
	/*	font-size : 10 px; */
	}
	table {
		border : thin solid black;
		border-collapse : collapse; 
		font-family : sans-serif;
		font-size : 12 px;
		color: white;
		border-spacing: 0px;
		table-layout: fixed; 
	}
	th {
		border: 1px solid gray;
		text-align: center;
		vertical-align: top;
		padding-right: 10px;
		background-color: #3c5087;
	}
	td {
		color: blue;
		border: 1px solid gray;
		vertical-align: top;
		padding-bottom: 3px;
		padding-top: 3px;
	}

	
	</style>
</head>
<body>

<?php 
require('head.php');
require('dbConnect.php');
?>

<div id="pagecell1"> 
  <!--pagecell1--> 
	  <img alt="" src="tl_curve_white.gif" height="6" width="6" id="tl" /> 
	  <img alt="" src="tr_curve_white.gif" height="6" width="6" id="tr" /> 
	  
	  <div id="pageName"> 
	    &nbsp;
		<h2>Mixed DNA Search </h2> 
	  </div> 
	  <div id="col2"> 
		<div class="feature"> 
			<h3>Enter the mixed DNA profile </h3> (Only enable to search mixed profiles of two persons against arrestee database)
			<form method="POST" action="referenceSearchResult.php"> 
	
				�˻��� DNA ��ȣ : <input type="text" name="dnaNo" size="20">

<?php				
	$DNANO = $_POST['dnaNo'];
	


	$query = "select * from profile where DNA_no='$DNANO'";
	$result = mysql_query($query);
	$numRow=mysql_num_rows($result);
	for ($i=0; $i<$numRow; $i++){
		$row=mysql_fetch_array($result);
		$AMEL=explode(",",$row[amel]);
		$D8=explode(",",$row[d8]);
		$TH01=explode(",",$row[th01]);
		$TPOX=explode(",",$row[tpox]);
		$CSF1PO=explode(",",$row[csf1po]);
		$D3=explode(",",$row[d3]);
		$VWA=explode(",",$row[vwa]);
	echo $AEML[0];
	}
/*	echo '<table align="center">';
	echo '			<tr>';
	echo '				<th> Locus </th>';
	echo '						<th> allele 1 </th>';
	echo '						<th> allele 2 </th>';
	echo '						<th> allele 3 </th>';
	echo '						<th> allele 4 </th>';
	echo '					</tr>';
	echo '					<tr>';
	echo '						<td align="center"> D8S1179</td>';
	echo '						<td align="center"> <input type="text" name="D8S_a" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D8S_b" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D8S_c" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D8S_d" size=5> </td>';
	echo '					</tr>';
	echo '					<tr>';
	echo '						<td align="center"> D21S11</td>';
	echo '						<td align="center"> <input type="text" name="D21S_a" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D21S_b" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D21S_c" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D21S_d" size=5> </td>';
	echo '					</tr>';
	echo '					<tr>';
	echo '						<td align="center"> D7S820</td>';
	echo '						<td align="center"> <input type="text" name="D7S_a" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D7S_b" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D7S_c" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D7S_d" size=5> </td>';
	echo '					</tr>';
	echo '					<tr>';
	echo '						<td align="center"> CSF1PO</td>';
	echo '						<td align="center"> <input type="text" name="CSF1PO_a" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="CSF1PO_b" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="CSF1PO_c" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="CSF1PO_d" size=5> </td>';
	echo '					</tr>';
	echo '					<tr>';
	echo '						<td align="center"> D3S1358</td>';
	echo '						<td align="center"> <input type="text" name="D3S_a" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D3S_b" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D3S_c" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D3S_d" size=5> </td>';
	echo '					</tr>';
	echo '					<tr>';
	echo '						<td align="center"> TH01</td>';
	echo '						<td align="center"> <input type="text" name="TH01_a" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="TH01_b" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="TH01_c" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="TH01_d" size=5> </td>';
	echo '					</tr>';
	echo '						<tr>';
	echo '						<td align="center"> D13S317</td>';
	echo '						<td align="center"> <input type="text" name="D13S_a" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D13S_b" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D13S_c" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D13S_d" size=5> </td>';
	echo '					</tr>';
	echo '					<tr>';
	echo '						<td align="center"> D16S539</td>';
	echo '						<td align="center"> <input type="text" name="D16S_a" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D16S_b" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D16S_c" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D16S_d" size=5> </td>';
	echo '					</tr>';
	echo '					<tr>';
	echo '						<td align="center"> D2S1338</td>';
	echo '						<td align="center"> <input type="text" name="D2S_a" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D2S_b" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D2S_c" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D2S_d" size=5> </td>';
	echo '					</tr>';
	echo '					<tr>';
	echo '						<td align="center"> D19S433</td>';
	echo '						<td align="center"> <input type="text" name="D19S_a" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D19S_b" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D19S_c" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D19S_d" size=5> </td>';
	echo '					</tr>';
	echo '					<tr>';
	echo '						<td align="center"> vWA</td>';
	echo '						<td align="center"> <input type="text" name="vWA_a" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="vWA_b" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="vWA_c" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="vWA_d" size=5> </td>';
	echo '					</tr>';
	echo '					<tr>';
	echo '						<td align="center"> TPOX</td>';
	echo '						<td align="center"> <input type="text" name="TPOX_a" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="TPOX_b" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="TPOX_c" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="TPOX_d" size=5> </td>';
	echo '					</tr>';
	echo '					<tr>';
	echo '						<td align="center"> D18S51</td>';
	echo '						<td align="center"> <input type="text" name="D18S_a" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D18S_b" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D18S_c" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D18S_d" size=5> </td>';
	echo '					</tr>';
	echo '					<tr>';
	echo '						<td align="center"> Amelogenin</td>';
	echo '						<td align="center"> <input type="text" name="AMEL_a" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="AMEL_b" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="AMEL_c" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="AMEL_d" size=5> </td>';
	echo '					</tr>';
	echo '					<tr>';
	echo '						<td align="center"> D5S818</td>';
	echo '						<td align="center"> <input type="text" name="D5S_a" size=5> </td>'; 
	echo '						<td align="center"> <input type="text" name="D5S_b" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D5S_c" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="D5S_d" size=5> </td>';
	echo '					</tr>';
	echo '					<tr>';
	echo '						<td align="center"> FGA</td>';
	echo '						<td align="center"> <input type="text" name="FGA_a" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="FGA_b" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="FGA_c" size=5> </td>';
	echo '						<td align="center"> <input type="text" name="FGA_d" size=5> </td>';
	echo '					</tr>';
	echo '					</table>';

	*/
?>

				
				<table align="center">
					<tr>
						<th> Locus </th>
						<th> allele 1 </th>
						<th> allele 2 </th>
						<th> allele 3 </th>
						<th> allele 4 </th>
					</tr>
					<tr>
						<td align="center"> D8S1179</td>
						<td align="center"> <input type="text" name="D8S_a" size='5'> </td>
						<td align="center"> <input type="text" name="D8S_b" size='5'> </td>
						<td align="center"> <input type="text" name="D8S_c" size='5'> </td>
						<td align="center"> <input type="text" name="D8S_d" size='5'> </td>
					</tr>
					<tr>
						<td align="center"> D21S11</td>
						<td align="center"> <input type="text" name="D21S_a" size='5'> </td> 
						<td align="center"> <input type="text" name="D21S_b" size='5'> </td>
						<td align="center"> <input type="text" name="D21S_c" size='5'> </td>
						<td align="center"> <input type="text" name="D21S_d" size='5'> </td>
					</tr>
					<tr>
						<td align="center"> D7S820</td>
						<td align="center"> <input type="text" name="D7S_a" size='5'> </td> 
						<td align="center"> <input type="text" name="D7S_b" size='5'> </td>
						<td align="center"> <input type="text" name="D7S_c" size='5'> </td>
						<td align="center"> <input type="text" name="D7S_d" size='5'> </td>
					</tr>
					<tr>
						<td align="center"> CSF1PO</td>
						<td align="center"> <input type="text" name="CSF1PO_a" size='5'> </td> 
						<td align="center"> <input type="text" name="CSF1PO_b" size='5'> </td>
						<td align="center"> <input type="text" name="CSF1PO_c" size='5'> </td>
						<td align="center"> <input type="text" name="CSF1PO_d" size='5'> </td>
					</tr>
					<tr>
						<td align="center"> D3S1358</td>
						<td align="center"> <input type="text" name="D3S_a" size='5'> </td> 
						<td align="center"> <input type="text" name="D3S_b" size='5'> </td>
						<td align="center"> <input type="text" name="D3S_c" size='5'> </td>
						<td align="center"> <input type="text" name="D3S_d" size='5'> </td>
					</tr>
					<tr>
						<td align="center"> TH01</td>
						<td align="center"> <input type="text" name="TH01_a" size='5'> </td> 
						<td align="center"> <input type="text" name="TH01_b" size='5'> </td>
						<td align="center"> <input type="text" name="TH01_c" size='5'> </td>
						<td align="center"> <input type="text" name="TH01_d" size='5'> </td>
					</tr>
					<tr>
						<td align="center"> D13S317</td>
						<td align="center"> <input type="text" name="D13S_a" size='5'> </td> 
						<td align="center"> <input type="text" name="D13S_b" size='5'> </td>
						<td align="center"> <input type="text" name="D13S_c" size='5'> </td>
						<td align="center"> <input type="text" name="D13S_d" size='5'> </td>
					</tr>
					<tr>
						<td align="center"> D16S539</td>
						<td align="center"> <input type="text" name="D16S_a" size='5'> </td> 
						<td align="center"> <input type="text" name="D16S_b" size='5'> </td>
						<td align="center"> <input type="text" name="D16S_c" size='5'> </td>
						<td align="center"> <input type="text" name="D16S_d" size='5'> </td>
					</tr>
					<tr>
						<td align="center"> D2S1338</td>
						<td align="center"> <input type="text" name="D2S_a" size='5'> </td> 
						<td align="center"> <input type="text" name="D2S_b" size='5'> </td>
						<td align="center"> <input type="text" name="D2S_c" size='5'> </td>
						<td align="center"> <input type="text" name="D2S_d" size='5'> </td>
					</tr>
					<tr>
						<td align="center"> D19S433</td>
						<td align="center"> <input type="text" name="D19S_a" size='5'> </td> 
						<td align="center"> <input type="text" name="D19S_b" size='5'> </td>
						<td align="center"> <input type="text" name="D19S_c" size='5'> </td>
						<td align="center"> <input type="text" name="D19S_d" size='5'> </td>
					</tr>
					<tr>
						<td align="center"> vWA</td>
						<td align="center"> <input type="text" name="vWA_a" size='5'> </td> 
						<td align="center"> <input type="text" name="vWA_b" size='5'> </td>
						<td align="center"> <input type="text" name="vWA_c" size='5'> </td>
						<td align="center"> <input type="text" name="vWA_d" size='5'> </td>
					</tr>
					<tr>
						<td align="center"> TPOX</td>
						<td align="center"> <input type="text" name="TPOX_a" size='5'> </td> 
						<td align="center"> <input type="text" name="TPOX_b" size='5'> </td>
						<td align="center"> <input type="text" name="TPOX_c" size='5'> </td>
						<td align="center"> <input type="text" name="TPOX_d" size='5'> </td>
					</tr>
					<tr>
						<td align="center"> D18S51</td>
						<td align="center"> <input type="text" name="D18S_a" size='5'> </td> 
						<td align="center"> <input type="text" name="D18S_b" size='5'> </td>
						<td align="center"> <input type="text" name="D18S_c" size='5'> </td>
						<td align="center"> <input type="text" name="D18S_d" size='5'> </td>
					</tr>
					<tr>
						<td align="center"> Amelogenin</td>
						<td align="center"> <input type="text" name="AMEL_a" size='5'> </td> 
						<td align="center"> <input type="text" name="AMEL_b" size='5'> </td>
						<td align="center"> <input type="text" name="AMEL_c" size='5'> </td>
						<td align="center"> <input type="text" name="AMEL_d" size='5'> </td>
					</tr>
					<tr>
						<td align="center"> D5S818</td>
						<td align="center"> <input type="text" name="D5S_a" size='5'> </td> 
						<td align="center"> <input type="text" name="D5S_b" size='5'> </td>
						<td align="center"> <input type="text" name="D5S_c" size='5'> </td>
						<td align="center"> <input type="text" name="D5S_d" size='5'> </td>
					</tr>
					<tr>
						<td align="center"> FGA</td>
						<td align="center"> <input type="text" name="FGA_a" size='5'> </td> 
						<td align="center"> <input type="text" name="FGA_b" size='5'> </td>
						<td align="center"> <input type="text" name="FGA_c" size='5'> </td>
						<td align="center"> <input type="text" name="FGA_d" size='5'> </td>
					</tr>
					<tr>
						<td colspan= '5'><input type="submit" value="Search"></td>
					</tr>
				</table>
				</form>
			<hr>
		</div> 
	  </div> 
	  <!--end col2 --> 
		<?php
			require ('left.php')
		?>
	  <!--end col1 div --> 
		<?php
			require ('footer.php')

		?>
	</div> 

	<!--end pagecell1--> 
	<br /> 
</body>
</html>

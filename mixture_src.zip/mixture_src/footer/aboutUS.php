<html>
<head>
	<title> Home </title>
</head>


<?php 
require('../head.php');
?>


</html>


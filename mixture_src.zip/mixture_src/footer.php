<div id="siteInfo"> 
		<img src="image/NFS_logo/NFS_logo1.gif" width="55" height="40" /> <a href="./footer/aboutNFS.png">About Us</a> | <a href="HTTP://NFS.GO.KR">Site
		Map</a> | <a href=mailto:hcpark79@mospa.go.kr>Contact Us</a> | This system is developed by Hyunchul Park
</div> 
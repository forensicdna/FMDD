<!-- <div id="pageNav"> 
		<div id="sectionLinks"> 
		  <a href="index.php">Home</a> 
		  <a href="search.php">Search</a> 
		  <a href="submit.php">Submit</a> 
		 </div> 
		<div class="relatedLinks"> 
		  <p>&nbsp;</p>
		   <p>&nbsp;</p>
		    <p>&nbsp;</p>
		</div> 
		<div class="relatedLinks"> 
		  <h3>Related Link Category</h3> 
		  <a href="http://hamoni.go.kr">Hamoni</a> 
		  <a href="http://www.nfs.go.kr">National Forensic Service</a> 
		  <a href="http://10.14.4.13/DIMS">DIMS</a> 
		  <a href="http://lims.nisi.go.kr">NFS LIMS</a> 
		  <a href="http://10.60.50.8:8080">DNA-LIMS</a>  
	 	</div>
</div> -->

<div id="pageNav"> 
		<div id="sectionLinks"> 
		  <a href="index.php">Home</a> 
		  <a href="dataSearch.php">�����Ͱ���</a> 
		  <a href="search.php">�˻� (reference)</a>
		  <a href="search2reference.php">�˻� (mixture)</a> 
		  <a href="submit.php">��� (Mix&Y)</a>
		  <a href="refSubmit.php">��� (Reference)</a>
          <a href="statistic.php">�м�</a> 
	 	</div>
</div>
